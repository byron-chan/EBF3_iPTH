clc; close all hidden; fclose('all'); clear; clearvars;


%% User Input

% Folder name input with multi-channel images
UI.Img_FoldernameString = '/Users/byronchan/Documents/MATLAB/DistAnalysisEbf3/IN/Veh742_01/';  % End w/ "/"

% Output Folder
OutputFolder = '/Users/byronchan/Documents/MATLAB/DistAnalysisEbf3/OUT/DistEbf3';

% Channel color; R=1; G=2; B=3; W=4
UI.XY_PxLength_umpx = 1.8872; % From Byron, 20241124

% Distance Step used for plotting
UI.PlotDistStep_um = 10; 

% Channel color; R=1; G=2; B=3; W=4
% % % UI.ChColor = [4,2,1,3]; % 20250123: CH1: W; CH2: G; CH3: R; CH4: B
% % % UI.ChColor = [1,3]; % 20250804: CH1: R; CH2: B [No Dist Target]
% % % UI.ChColor = [4,2,1] % use this for regular DAPI imaging
UI.ChColor = [4,2,1]; % 20250804: CH1: R; CH2: B [No Dist Target]

% Channel label; Nuclei=1; Ebf3=2; 
% BoneStruct/Dye to which distance from Ebf3 is measured=3
% (Osteocalcein OCN, TRAP etc) 
% Must have only 1 nuclei channel and 1 EBf3 channel
% % % UI.ChLbl = [3,3,2,1];  % 20250123: CH1: TRAP; CH2: OCN; CH3: Ebf3; CH4: DAPI
% % % UI.ChLbl = [2,1];  % 20250804: CH1: Ebf3; CH2: DAPI [No Dist Target]
% % % UI.ChLbl = [1,3,2]; % use this for regular DAPI imaging
UI.ChLbl = [1,3,2];  % 20250804: CH1: Ebf3; CH2: DAPI [No Dist Target]

% ImgCheck RGB Color Designation
% Nuclei (N); Dist-Measure Source (S) (=Ebf3); Dist-Measure Target (T) (Code will include all targets into one color)
% R = 1; G = 2; B = 3;
UI.ImgCheck_NSTColor = [3 1 2]; % 20250123: Nuclei in B, Ebf3 in R, targets in G

% 20250626: Bone Front Only Option
% 1 for Bone Front Only (No Dist-Measure Target: OCN, TRAP etc)
% 0 for Dist-measure targets supplied
UI.BoneFrontOnly_Option = 1;  % 20250804: [No Dist Target]

% Smoothing option for Marrow Mask
% 0 for do not smooth; 1 for smooth
UI.MrwMask_SmOption = 0; 

% Patch marrow space divisions
UI.TearEst_Option = 1; % 1 to patch; 0 to skip
UI.TearEst_Width_um = 8.5; % Test 8.5/17/25.5/34/42.5

% Quality of Assignment Option
% [1 0]: Ignore only 
% (data in (:,:,1) of output cells from "fAdjustdSAssignEbf3" step onward)
% [1 1]: Ignore & consider 
% (data in (:,:,1), (:,:,2) of output cells from "fAdjustdSAssignEbf3" step onward)
UI.dSAssignQOption = [1 0];

% Quality of Assignment score range to keep
% 20250306: Set in range [0 1], based on silhouette cluster evaluation
UI.dSAssignQScoreRange = [0.10 1.00]; % [llim ulim]


%% Prepare Output Folder

[UI.Img_Filename,~,~] = fileparts(UI.Img_FoldernameString);
UI.Img_Filename = regexp(UI.Img_Filename, '/', 'split');
UI.Img_Filename = UI.Img_Filename{end};

timestamp = string(datetime('now'),'yyMMddHHmm');
UI.timestamp = timestamp;

UI.SaveFilePath = strcat(OutputFolder,'_',UI.Img_Filename,'_',timestamp,'/');
mkdir(UI.SaveFilePath);

clearvars FileName;


%% 20250123: Load both 4-channel image and 3-channel overlay image

% OUTPUT: Img_Org_Cell
% Rows:
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Original Img 

% OUTPUT: ImgCheck_Org_Cell: 
% 1 Row; Columns:
% * Col01: Img_Disp_AllColorRGB (all labels of all visual colors compressed into 3 slices for R-G-B; for display)
% * Col02: Img_Disp_AllColor (each label given 1 color and 1 slice; 20250123 in order RGBW; for display)
% * Col03: Img_Disp_RGB (labels compressed into 3 colors and 3 slices for RGB; for ImgCheck)

% OUTPUT: oEbf3
% Contains records of UI, Image input and crop parameters
% No initiation necessary

[Img_Org_Cell,ImgCheck_Org_Cell,oEbf3] = fLoadImgEbf3(UI,'y');


%% Use Nuclei Channel to create mask of (celullar) marrow space

% OUTPUT: Img_MrwDef_Cell: cell of size(3,6)
% Rows (same as Img_Org_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = MrwMask (logical, Row 1; choice of Col07 or Col09)
% * Col02 = MrwMask_Edge (logical, Row 1; choice of Col08 or Col10)
% * Col03 = MrwMask_Sm (= MrwMask_SmEdgeFill in previous versions; logical, Row 1)
% * Col04 = MrwMask_SmEdge (logical, Row1)
% * Col05 = MrwHoleMask (logical, tears in biopsy slice + appoximate trabecular bone locations; Row 1)
% * Col06 = Mrw image (greyscale; different for Row 1-3, zero image for Row 4)
% * Col07 = MrwMask, no collect & connect broken pieces (logical, Row 1)
% * Col08 = MrwMask_Edge, no collect & connect broken pieces (logical, Row 1)
% * Col09 = MrwMask, w/ collect & connect broken pieces (logical, Row 1)
% * Col10 = MrwMask_Edge, w/ collect & connect broken pieces (logical, Row 1)

% ImgCheck_MrwDef_Cell: 1 row, same columns as Img_MrwDef_Cell:
% Columns:
% * Col01 = <empty, can be filled with Colocalized Image of MrwMask with 'ImgCheck_MaskChoice' in code>
% * Col02 = Colocazed image, MrwMask_Edge, with Img_Mrw and Img of Mrw (B)+ Ebf3 (R) + DistanceTargets (G)
% * Col03 =  <empty, can be filled with Colocalized Image of MrwMask_Sm with 'ImgCheck_MaskChoice' in code>
% * Col04 = Colocazed image, MrwMask_SmEdge, with Img_Mrw and Img of Mrw (B)+ Ebf3 (R) + DistanceTargets (G)
% * Col05 = Colocazed image, MrwHoleMask, with Img_Mrw and Img of Mrw (B)+ Ebf3 (R) + DistanceTargets (G)
% * Col06 = <empty>

[Img_MrwDef_Cell,ImgCheck_MrwDef_Cell] = fDefineMrwEbf3(Img_Org_Cell,ImgCheck_Org_Cell,UI,'y');

% 20250506: Debug DefineMrw Error
% % % figure; imshow(ImgCheck_MrwDef_Cell{1,2});


%% Obtain Bone Edge Masks, epiphysis-growth-plate (eg) and diaphysis-cortical bone (dc) 

% OUTPUT Img_Begdc_Cell: cell of size(3,8):
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = (From MrwMask_Edge) Bone edge *line* mask, epiphysis-growth plate (Beg) (logical, Row1)
% * Col02 = (From MrwMask_Edge)  Bone edge *line* mask, diaphysis-cortical bone (Bdc) (logical, Row1)
% * Col03 = (From MrwMask_SmEdge) Bone edge *line* mask, epiphysis-growth plate (Beg) (logical, Row1)
% * Col04 = (From MrwMask_SmEdge) Bone edge *line* mask, diaphysis-cortical plate (Bdc) (logical, Row1)
% * Col05 = (From MrwMask_Edge) Bone edge *region* mask, epiphysis-growth plate (Beg) (logical, Row1)
% * Col06 = (From MrwMask_Edge)  Bone edge *region* mask, diaphysis-cortical bone (Bdc) (logical, Row1)
% * Col07 = (From MrwMask_SmEdge) Bone edge *region* mask, epiphysis-growth plate (BegMask) (logical, Row1)
% * Col08 = (From MrwMask_SmEdge) Bone edge *region* mask, diaphysis-cortical plate (BegMask) (logical, Row1)

[Img_Begdc_Cell] = fDefineBegdcEbf3(Img_MrwDef_Cell,UI);


%% Distance-Targets assignment to Bone Fronts (eg, dc, tb)

% = Img_DistT_Cell 
% Img of assignment of distance-target blobs to different bone (eg, dc, tb). Cell of size(3,4):
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = Logical Mask, epiphysis-growth plate (eg) (Row 1: Bone Edge Region Mask (Sm or not); Row 3: Distance Target; Row 4: Bone Edge Line mask, mildly dilated, as "hypothetical" staining)
% * Col02 = Logical Mask, diaphysis-cortical bone (dc) (Row 1: Bone Edge Region Mask (Sm or not); Row 3: Distance Target; Row 4: Bone Edge Line mask, mildly dilated, as "hypothetical" staining)
% * Col03 = Logical Mask, trabecular bone (tb) (Row 1: Trabecular Bone Mask cleaned from MrwHole_Mask (Sm or not); Row 3: Distance Target; Row 4: Edge of Trabecular Bone Mask, mildly dilated, as "hypothetical" staining)
% * Col04 = Trabecular Bone ID Label, trabecular bone (tb) (Row 1: Trabecular Bone Mask cleaned from MrwHole_Mask (Sm or not); Row 3: Distance Target; Row 4 = Row 1 for now)


% =  Img_Btb_Cell
% Trabecular Bone Mask only; similar organization as Img_Begdc_Cell. Cell of size(3,1):
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = Trabecular Bone Mask (Btb) (logical, Row 1) 
% * Col02 = Trabecular Bone ID Label, trabecular bone (tb) (logical, Row 1)

% = ImgCheck_DistT_Cell
% 1 Row; 1 Column:
% * Col 01: Label image, logical masks of bone fronts, distance-target blobs, "hypothetical" bone front stain (Beg: yellow; Bdc: teal; Btb: magenta) 
% * Col 02: Label image, trabecular bone distance-target blobs labelled by different trabecular bone

[Img_DistT_Cell,Img_Btb_Cell,ImgCheck_DistT_Cell] = fDefineDistTargetEbf3(Img_MrwDef_Cell,Img_Begdc_Cell,UI);

% 20250506: Debug DefineMrw Error
% % % figure; imshow(ImgCheck_DistT_Cell{1,1,1});


%% Distance-Source Mask (Ebf3)

% = Img_DistS_Cell 
% Img of assignment of distance-target blobs to different bone (eg, dc, tb). Cell of size(3,4):
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Single; Img of Distance-Source, Background corrected (Row 2: Distance Source)
% * Col02 = Logical; Img of Distance-Source, Background corrected (Row 2: Distance Source)
% * Col03 = Logical; Exclusion Mask of Distance-Source based on size and morphlogy (Row 2: Distance Source)
% * Col04 = Single; Img of Distance-Source, Background corrected and size+morphlogy excluded (Row 2: Distance Source)
% * Col05 = Logical; Img of Distance-Source, Background corrected and size+morphlogy excluded (Row 2: Distance Source)
% * Col06 = Logical; Img of Non-trabecular bone marrow holes that are likely tears from biopsy preparation (Row 1)


% = ImgCheck_DistS_Cell 
% 1 Row; Columns:
% * Col01 = Colocalized Img (single), Img_Mrw w/ bone + distance-target @ Beg, Bdc and Btb (pre distance source assignment check)
% * Col02 = Colocalized Img, logical mask of Non-trabecular bone marrow holes w/ Img_Btb_Mask, Img_MrwMask (Sm or not)

[Img_DistS_Cell,ImgCheck_DistS_Cell] = fDefineDistSourceEbf3(Img_MrwDef_Cell,Img_Begdc_Cell,Img_Btb_Cell,Img_DistT_Cell,UI);

% 20250506: Debug DefineMrw Error
% % % figure; imshow(ImgCheck_DistS_Cell{1,1});


%% Geodesic Distance Maps for Distance-Source Assignment to Distance-Targets

% = Img_gDistMap_Cell

% Img of geodesic distance map from distance-target blobs of different bone (eg, dc, tb). 
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Geodesic distance map (single), quasi-euclidean distance from epiphysis-growth plate (eg) distance-target blobs (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)
% * Col02 = Geodesic distance map (single), quasi-euclidean distance from diaphysis-cortical bone (dc) distance-target blobs (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)
% * Col03 = Geodesic distance map (single), quasi-euclidean distance from trabecular bone (tb) distance-target blobs (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)
% * Col04 = Logical Mask of Forbidden Pixels, * input * of bwdistgeodesic() geodesic distance measurement for Row3, Row 4 Col01-03 (1 = permitted pixel; 0 = forbidden pixel for  bwdistgeodesic()) (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)
% * Col05 = Logical Mask of Forbidden Pixels (Final), * output * of bwdistgeodesic() geodesic distance measurement for Row3, Row 4 Col01-03 (1 = permitted pixel; 0 = forbidden pixel for  bwdistgeodesic()) (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)

% = ImgCheck_gDistMap_Cell
% 2 Row; Columns:
% * Col01: Colocalize Image, gDistMap (red) vs dist target blobs (green) 

[Img_gDistMap_Cell,ImgCheck_gDistMap_Cell] = fCreateDistMapEbf3(Img_Begdc_Cell,Img_Btb_Cell,Img_DistT_Cell,Img_DistS_Cell,UI);

% 20250506: Debug DefineMrw Error
% % % figure; imshow(ImgCheck_gDistMap_Cell{2,1,1});


%% Assignment: Pixels & Distance-Source (Ebf3 cells) to Distance Targets

% = Img_DistSAssign_Cell

% Assignment of each pixel and eacn Dist-Source-Blob (Ebf3) (with gDist measurement to) different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Logical Map, all pixels receiving DistT assignment based on final output mask from bwdistgeodesic()
% (Row 3,4; = ~Img_gDistMap_Cell{1,5}, combined result from Row 3, Row 4)
% * Col02 = Assignment Mask by *pixel* (single), to real/hyp dist-Target @ epiphysis-growth plate (Beg), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3 (real), Row 4 (hyp))
% * Col03 = Assignment Mask by *pixel* (single), to real/hyp dist-Target @ diaphysis-cortical bone (Bdc), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3 (real), Row 4 (hyp))
% * Col04 = Assignment Mask by *pixel* (single), to real/hyp dist-Target @ trabecular bone (Btb), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3 (real), Row 4 (hyp))
% * Col05 = Assignment Label Map by *pixel* (uint16), to all real/hyp dist-Target. Same kIdx order as ImgStack_gDist_Temp below (Row 3 (real), Row 4 (hyp))
% * Col06 = Assignment mean-gDist Map by *pixel* (single), to all real/hyp dist-Target (Row 3 (real), Row 4 (hyp))
% * Col07 = Quality of Assignment Map by *pixel* (single, general score range [-1 1], in-code range [0 1]; close to 1 better) (Row 3 (real), Row 4 (hyp))
% * Col08-10 = (empty)

% * Col11 = Logical Map, Dist-Source Blobs receiving assignment based on final output mask from bwdistgeodesic()
% (Row 2; = Img_DistS_Cell{2,5})
% * Col12 = Assignment Mask by *dist source blob* (single), to real/hyp dist-Target @ epiphysis-growth plate (Beg), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3,4)
% * Col13 = Assignment Mask by *dist source blob* (single), to real/hyp dist-Target @ diaphysis-cortical bone (Bdc), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3,4)
% * Col14 = Assignment Mask by *dist source blob* (single), to real/hyp dist-Target @ trabecular bone (Btb), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3,4)
% * Col15 = Assignment Label Map by *dist source blob* (uint16), to all real/hyp dist-Target. Same kIdx order as ImgStack_gDist_Temp below (Row 3 (real), Row 4 (hyp))
% * Col16 = Assignment mean-gDist Map by *dist source blob* (single), to all real/hyp dist-Target (Row 3 (real), Row 4 (hyp))
% * Col17 = Quality of Assignment Map by *dist source blob* (single, general score range [-1 1], in-code range [0 1]; close to 1 better)  (Row 3 (real), Row 4 (hyp))
% * Col18-20 = (empty)


% = ImgCheck_DistSAssign_Cell

% 2 Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Logical Map, all * pixels * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col02 = Label Map (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), all * pixels * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col03 = Quality of assignment map (no colorbar; range [-1 1]), all * pixels * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col04 = Quality of assignment map (w/ colorbar; range [-1 1]), all * pixels * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col05-10 = (empty)

% * Col11 = Logical Map, all * dist-source blob * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col12 = Label Map (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), all * dist-source blob * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col13 = Quality of assignment map (no colorbar; range [-1 1]), all * dist-source blob * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col14 = Quality of assignment map (w/ colorbar; range [-1 1]), all * dist-source blob * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col15-20 = (empty)

[Img_DistSAssign_Cell,ImgCheck_DistSAssign_Cell] = fAssignDistSourceEbf3(Img_gDistMap_Cell,Img_DistS_Cell,Img_Begdc_Cell,UI);

% 20250506: Debug DefineMrw Error
% % % figure; imshow(horzcat(ImgCheck_DistSAssign_Cell{1,2,1},ImgCheck_DistSAssign_Cell{2,2,1}));
% % % figure; imshow(horzcat(ImgCheck_DistSAssign_Cell{1,12,1},ImgCheck_DistSAssign_Cell{2,12,1}));


%% Adjust Assignment of Pixels & Distance-Source (Ebf3 cells) to Distance Targets
% * All pixels of each Distance-Source (Ebf3 cells) Blob must belong to 1 Distance Target
% * Ignore or consider Quality of Assignment (cluster evaluation) Score

% = "Img_dSAssignAdj_Cell"

% Adjusted Assignment of each pixel and each Dist-Source-Blob (Ebf3) (with gDist measurement to) different distance-targets @ different bone fronts (eg, dc, tb). 
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Quality of Assignment KEEP Mask by *pixel* (logical)  (Row 3,4)
% * Col02 = Quality of Assignment REJECT Mask by *pixel* (logical)  (Row 3,4)
% * Col03 = Adjusted (Final) Assignment Mask by *pixel* (single), to dist-Target @ epiphysis-growth plate (Beg) (Row 3,4)
% * Col04 = Adjusted (Final) Assignment Mask by *pixel* (single), to dist-Target @ diaphysis-cortical bone (Bdc) (Row 3,4)
% * Col05 = Adjusted (Final) Assignment Mask by *pixel* (single), to dist-Target @ trabecular bone (Btb) (Row 3,4)
% * Col06-20 (empty)

% * Col21 = Quality of Assignment KEEP Mask by *dist-Source Blob* (logical)  (Row 3,4)
% * Col22 = Quality of Assignment REJECT Mask by *dist-Source Blob* (logical)  (Row 3,4)
% * Col23 = Adjusted (Final) Assignment Mask by *dist-souce blob* (single), to dist-Target @ epiphysis-growth plate (Beg) (Row 3,4)
% * Col24 = Adjusted (Final) Assignment Mask by *dist-souce blob* (single), to dist-Target @ diaphysis-cortical bone (Bdc) (Row 3,4)
% * Col25 = Adjusted (Final) Assignment Mask by *dist-souce blob* (single), to dist-Target @ trabecular bone (Btb) (Row 3,4)
% * Col26-40 (empty)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = "ImgCheck_dSAssignAdj_Cell"

% 2 Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Adjusted (Final) assignment of pixels (left) and dist-source blobs (right) tp dist-Target
% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)

[Img_dSAssignAdj_Cell, ImgCheck_dSAssignAdj_Cell] = fAdjustdSAssignEbf3(Img_DistSAssign_Cell,UI);


%% Create Data Table from Adjusted (Final) Dist-Source (Ebf3) Assignment for Plotting

% = "Tbl_AssignData_Cell"

% Contains data table from final assignments of pixels and distance-source
% blobs to distance-targets

% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = dataTbl (class: 'table'), px & dS-blob final assignments to epiphysis-growth plate (eg) distance-target blobs (Row 3,4: real/hyp Distance Target; cell array of size(1,1,NumDistT), each cell = 1 table)
% * Col02 = dataTbl (class: 'table'), px & dS-blob final assignments to diaphysis-cortical bone (dc) distance-target blobs (Row 3,4: real/hyp Distance Target; cell array of size(1,1,NumDistT), each cell = 1 table)
% * Col03 = dataTbl (class: 'table'), px & dS-blob final assignments to trabecular bone (tb) distance-target blobs (Row 3,4: real/hyp Distance Target; cell array of size(1,1,NumDistT), each cell = 1 table)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)

[Tbl_dSAssignAdj_Cell]  = fCreateDataTblEbf3(Img_DistS_Cell,Img_dSAssignAdj_Cell,Img_gDistMap_Cell,UI);


%% Histograms: distance-source blobs (Ebf3) occupied area vs distance to assigned distance targets

% 3 Cases of describing occupancy of Distance-Source (Ebf3) 
% Case 1): "Hist_dSPxbyD" 
% Multi dist for each dSBlob
% Case 2.1): "Hist_dSPxbyD_Blob" 
% 1 dist for each dSBlob x # px in blob
% Case 2.2): "Hist_dSUtbyD_Blob" 
% 1 dist for each dSBlob x # dSUt in blob

% = PlotData_AreaDHist_Cell

% Plot data from adjusted (final) assignment of distance-source blobs to different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = class "structure", distance source unit (dSUt) area statistics  (Row 3,4)
% * Col02 = class "structure", Case 1) histogram data, dist-source blob pixel distance from nearest dist-target (HistVal = multiple dist val for each dSBlob) (Row 3,4)
% * Col03 = class "structure", Case 2.1) histogram data, dist-source blob pixel distance from nearest dist-target (HistVal = 1 dist val for each dSBlob x # pixels in blob) (Row 3,4)
% * Col04 = class "structure", Case 2.2) histogram data, dist-source blob pixel distance from nearest dist-target (HistVal = 1 dist val for each dSBlob x # dSUt in blob) (Row 3,4)
 
% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)

% = Plot_AreaDHist_Cell

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = Area statistics (Box Plot), distance source unit (dSUt) area 
% * Col02 = Case 1) Histogram
% * Col03 = Case 2.1) Histogram
% * Col04 = Case 2.2)  Histogram

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = ImgCheck_AreaDHist_Cell

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
 % Columns:
% * Col01 = Colocalized Img, dist-source blobs for measuring dSUt properties (Row 3,4; Z 1)
% * Col02 = Label Img (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), pixels and dist-source blobs used in histogram
% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)

[PlotData_AreaDHist_Cell,Plot_AreaDHist_Cell,ImgCheck_AreaDHist_Cell] = ...
    fPlotAreaDHistEbf3(Img_MrwDef_Cell,Img_DistS_Cell,Img_DistT_Cell,Img_Btb_Cell,Img_gDistMap_Cell,Img_dSAssignAdj_Cell,Tbl_dSAssignAdj_Cell,UI);


%% Histograms: distance-source blobs (Ebf3) aspect ratio vs distance to assigned distance targets

% 6 Cases of using skeleton branch length to measure aspect ratio of
% dist-source blobs:

% * Case 1.1): "Hist_skbrL_by_brD"
% Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to 1 HistBin_D
% * Case 1.2): "Hist_skbrL_by_brpxD"
% Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to multiple HistBin_D
% * Case 1.3): "Hist_skbrLS_by_brD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to 1 HistBin_D
% * Case 1.4): "Hist_skbrLS_by_blobD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to 1 HistBin_D
% * Case 1.5): "Hist_skbrLS_by_brpxD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to multiple HistBin_D
% * Case 1.6): "Hist_skbrLS_by_blobpxD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to multiple HistBin_D

% Each case may ignore quality of assignment (q0), or consider quality of assignment (q1)

% = PlotData_ShapeDHist_Cell

% Plot data from adjusted (final) assignment of distance-source blobs to different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = <empty>
% * Col02 = class "structure", histogram data, Case 1.1) (Row 3,4)
% * Col03 = class "structure", histogram data, Case 1.2) (Row 3,4)
% * Col04 = class "structure", histogram data, Case 1.3) (Row 3,4)
% * Col05 = class "structure", histogram data, Case 1.4) (Row 3,4)
% * Col06 = class "structure", histogram data, Case 1.5) (Row 3,4)
% * Col07 = class "structure", histogram data, Case 1.6) (Row 3,4)


% = Plot_ShapeDHist_Cell

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)

% Column (match PlotData above):
% * Col01 = <empty>
% * Col02 = Histogram, Case 1.1) (Row 1,2)
% * Col03 = Histogram, Case 1.2) (Row 1,2)
% * Col04 = Histogram, Case 1.3) (Row 1,2)
% * Col05 = Histogram, Case 1.4) (Row 1,2)
% * Col06 = Histogram, Case 1.5) (Row 1,2)
% * Col07 = Histogram, Case 1.6) (Row 1,2)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = ImgCheck_ShapeDHist_Cell

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Label Img (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), pixels, dist-source blobs and skeleton branches
% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)

 [PlotData_ShapeDHist_Cell,Plot_ShapeDHist_Cell,ImgCheck_ShapeDHist_Cell] = ...
     fPlotShapeDHistEbf3(Img_DistS_Cell,Img_gDistMap_Cell,Img_dSAssignAdj_Cell,UI);


%% Histograms: Combine Area Histograms by Bone Fronts

% 3 Cases of describing occupancy of Distance-Source (Ebf3)
% Case 1): "Hist_dSPxbyD"
% Multi dist for each dSBlob
% Case 2.1): "Hist_dSPxbyD_Blob"
% 1 dist for each dSBlob x # px in blob
% Case 2.2): "Hist_dSUtbyD_Blob"
% 1 dist for each dSBlob x # dSUt in blob

% = PlotData_AreaDHist_BCombo_Cell

% Plot data from adjusted (final) assignment of distance-source blobs to different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = <empty>
% * Col02 = class "structure", histogram data, Case 1.0) (Row 3,4)
% * Col03 = class "structure", histogram data, Case 2.1) (Row 3,4)
% * Col04 = class "structure", histogram data, Case 2.2) (Row 3,4)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = Plot_AreaDHist_BCombo_Cell

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)

% Column (match PlotData above):
% * Col01 = <empty>
% * Col02 = Histogram, Case 1.0) (Row 1,2)
% * Col03 = Histogram, Case 2.1) (Row 1,2)
% * Col04 = Histogram, Case 2.2) (Row 1,2)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)

[PlotData_AreaDHist_BCombo_Cell,Plot_AreaDHist_BCombo_Cell] = fCombineAreaDHistEbf3(PlotData_AreaDHist_Cell,UI);


%% Histograms: Combine Aspect Ratio Histograms by Bone Fronts

% 6 Cases of using skeleton branch length to measure aspect ratio of
% dist-source blobs:

% * Case 1.1): "Hist_skbrL_by_brD"
% Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to 1 HistBin_D
% * Case 1.2): "Hist_skbrL_by_brpxD"
% Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to multiple HistBin_D
% * Case 1.3): "Hist_skbrLS_by_brD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to 1 HistBin_D
% * Case 1.4): "Hist_skbrLS_by_blobD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to 1 HistBin_D
% * Case 1.5): "Hist_skbrLS_by_brpxD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to multiple HistBin_D
% * Case 1.6): "Hist_skbrLS_by_blobpxD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to multiple HistBin_D

% Each case may ignore quality of assignment (q0), or consider quality of assignment (q1)

% = PlotData_ShapeDHist_BCombo_Cell

% Plot data from adjusted (final) assignment of distance-source blobs to different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = <empty>
% * Col02 = class "structure", histogram data, Case 1.1) (Row 3,4)
% * Col03 = class "structure", histogram data, Case 1.2) (Row 3,4)
% * Col04 = class "structure", histogram data, Case 1.3) (Row 3,4)
% * Col05 = class "structure", histogram data, Case 1.4) (Row 3,4)
% * Col06 = class "structure", histogram data, Case 1.5) (Row 3,4)
% * Col07 = class "structure", histogram data, Case 1.6) (Row 3,4)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = Plot_ShapeDHist_BCombo_Cell

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)

% Column (match PlotData above):
% * Col01 = <empty>
% * Col02 = Histogram, Case 1.1) (Row 1,2)
% * Col03 = Histogram, Case 1.2) (Row 1,2)
% * Col04 = Histogram, Case 1.3) (Row 1,2)
% * Col05 = Histogram, Case 1.4) (Row 1,2)
% * Col06 = Histogram, Case 1.5) (Row 1,2)
% * Col07 = Histogram, Case 1.6) (Row 1,2)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)

[PlotData_ShapeDHist_BCombo_Cell,Plot_ShapeDHist_BCombo_Cell] = fCombineShapeDHistEbf3(PlotData_ShapeDHist_Cell,UI);


%% 20250406: Export Selected Output from "Hypothetical Bone Front Stain" Analysis
% i) ImgCheck 

% == ImgCheck files: make sure the code is working as it should
SaveImgCheckFilePath = strcat(UI.SaveFilePath,'ImgCheck/');
if exist(SaveImgCheckFilePath,'dir')==7
    rmdir(SaveImgCheckFilePath,'s'); 
end
mkdir(SaveImgCheckFilePath);

% i) ImgCheck_DistT_Cell
% 1 Row; 1 Column:
% * Col 01: Label image, logical masks of bone fronts, distance-target blobs, "hypothetical" bone front stain (Beg: yellow; Bdc: teal; Btb: magenta) 
% % % figure; imshow(ImgCheck_DistT_Cell{1,1,1});
imwrite(ImgCheck_DistT_Cell{1,1,1},strcat(SaveImgCheckFilePath,'ImgCheck_DistT.tif'));

% ii) ImgCheck_gDistMap_Cell
% 2 Row; Columns:
% * Col01: Colocalize Image, gDistMap (red) vs dist target blobs (green) 
% % % figure; imshow(ImgCheck_gDistMap_Cell{2,1,1});
imwrite(ImgCheck_gDistMap_Cell{2,1,1},strcat(SaveImgCheckFilePath,'ImgCheck_gDistMap_dtSet02.tif'));

% iii) ImgCheck_AreaDHist_Cell
% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
 % Columns:
% * Col02 = Label Img (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), pixels and dist-source blobs used in histogram
% % % figure; imshow(ImgCheck_AreaDHist_Cell{2,2,1});
imwrite(ImgCheck_AreaDHist_Cell{2,2,1},strcat(SaveImgCheckFilePath,'ImgCheck_AreaDHist_dtSet02_q01.tif'));

% iv) ImgCheck_ShapeDHist_Cell
% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Label Img (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), pixels, dist-source blobs and skeleton branches
% % % figure; imshow(ImgCheck_ShapeDHist_Cell{2,1,1});
imwrite(ImgCheck_ShapeDHist_Cell{2,1,1},strcat(SaveImgCheckFilePath,'ImgCheck_ShapeDHist_dtSet02_q01.tif'));

clearvars Save*FilePath;


%% 20250406: Export Selected Output from "Hypothetical Bone Front Stain" Analysis
% i) Histograms

% == Histogram Plots  ("Hypothetical" Bone Front Stain)
SaveHistFilePath = strcat(UI.SaveFilePath,'Hist/');
if exist(SaveHistFilePath,'dir')==7
    rmdir(SaveHistFilePath,'s'); 
end
mkdir(SaveHistFilePath);
SavedtSet01HistFilePath = strcat(SaveHistFilePath,'dtSet01/');
mkdir(SavedtSet01HistFilePath); % "Real" OCN, TRAP etc stain 
SavedtSet02HistFilePath = strcat(SaveHistFilePath,'dtSet02/');
mkdir(SavedtSet02HistFilePath); % "Hypothetical" bone front stain

% Plot_AreaDHist_Cell (dtSet01 only; for checking)
% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col02 = Case 1) Histogram ("Hist_dSPxbyD")
% % % figure; imshow(Plot_AreaDHist_Cell{1,2,1}); % Numerical data: PlotData_AreaDHist_Cell{3,2,1}
imwrite(Plot_AreaDHist_Cell{1,2,1},strcat(SavedtSet01HistFilePath,'AreaDHist_dSPxbyD_dtSet01_q01.tif'));
writetable(PlotData_AreaDHist_Cell{3,2,1}.HistData.HistCt_Tbl,strcat(SavedtSet01HistFilePath,'Data_AreaDHist_dSPxbyD_dtSet01_q01.csv'));

% = Plot_ShapeDHist_Cell (dtSet01 only; for checking)
% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Column (match PlotData above):
% * Col02 = Histogram, Case 1.1) (Row 1,2) ("Hist_skbrL_by_brD")
% * Col04 = Histogram, Case 1.3) (Row 1,2) ("Hist_skbrLS_by_brD")
% % % figure; imshow(Plot_ShapeDHist_Cell{1,2,1}); % Numerical data: PlotData_ShapeDHist_Cell{3,2,1}
% % % figure; imshow(Plot_ShapeDHist_Cell{1,4,1}); % Numerical data: PlotData_ShapeDHist_Cell{3,4,1}
imwrite(Plot_ShapeDHist_Cell{1,2,1},strcat(SavedtSet01HistFilePath,'ShapeDHist_skbrL_by_brD_dtSet01_q01.tif'));
imwrite(Plot_ShapeDHist_Cell{1,4,1},strcat(SavedtSet01HistFilePath,'ShapeDHist_skbrLS_by_brD_dtSet01_q01.tif'));
writetable(PlotData_ShapeDHist_Cell{3,2,1}.HistData.yBox_Tbl,strcat(SavedtSet01HistFilePath,'Data_ShapeDHist_skbrL_by_brD_dtSet01_q01.csv'));
writetable(PlotData_ShapeDHist_Cell{3,4,1}.HistData.yBox_Tbl,strcat(SavedtSet01HistFilePath,'Data_ShapeDHist_skbrLS_by_brD_dtSet01_q01.csv'));

% Plot_AreaDHist_BCombo_Cell (dtSet02 - "Hypothetical" Bone Front" only)
% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Column (match PlotData above):
% * Col01 = <empty>
% * Col02 = Histogram, Case 1.0) (Row 1,2) ("Hist_dSPxbyD")
% % % figure; imshow(Plot_AreaDHist_BCombo_Cell{2,2,1}); % Numerical data: PlotData_AreaDHist_BCombo_Cell{4,2,1}
imwrite(Plot_AreaDHist_BCombo_Cell{2,2,1},strcat(SavedtSet02HistFilePath,'AreaDHistBCombo_dSPxbyD_dtSet02_q01.tif'));
writetable(PlotData_AreaDHist_BCombo_Cell{4,2,1}.HistData.HistCt_Begdctb_Tbl,strcat(SavedtSet02HistFilePath,'Data_AreaDHist_Begdctb_dSPxbyD_dtSet02_q01.csv'));
writetable(PlotData_AreaDHist_BCombo_Cell{4,2,1}.HistData.HistCt_Bdctb_Tbl,strcat(SavedtSet02HistFilePath,'Data_AreaDHist_Bdctb_dSPxbyD_dtSet02_q01.csv'));

% Plot_ShapeDHist_BCombo_Cell (dtSet02 - "Hypothetical" Bone Front" only)
% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Column (match PlotData above):
% * Col02 = Histogram, Case 1.1) (Row 1,2) ("Hist_skbrL_by_brD")
% * Col04 = Histogram, Case 1.3) (Row 1,2) ("Hist_skbrLS_by_brD")
% % % figure; imshow(Plot_ShapeDHist_BCombo_Cell{2,2,1}); % Numerical data: PlotData_ShapeDHist_BCombo_Cell{4,2,1}
% % % figure; imshow(Plot_ShapeDHist_BCombo_Cell{2,4,1}); % Numerical data: PlotData_ShapeDHist_BCombo_Cell{4,4,1}
imwrite(Plot_ShapeDHist_BCombo_Cell{2,2,1},strcat(SavedtSet02HistFilePath,'ShapeDHistBCombo_skbrL_by_brD_dtSet02_q01.tif'));
imwrite(Plot_ShapeDHist_BCombo_Cell{2,4,1},strcat(SavedtSet02HistFilePath,'ShapeDHistBCombo_skbrLS_by_brD_dtSet02_q01.tif'));
writetable(PlotData_ShapeDHist_BCombo_Cell{4,2,1}.HistData.yBox_Begdctb_Tbl,strcat(SavedtSet02HistFilePath,'Data_ShapeDHist_Begdctb_skbrL_by_brD_dtSet02_q01.csv'));
writetable(PlotData_ShapeDHist_BCombo_Cell{4,4,1}.HistData.yBox_Begdctb_Tbl,strcat(SavedtSet02HistFilePath,'Data_ShapeDHist_Begdctb_skbrLS_by_brD_dtSet02_q01.csv'));
writetable(PlotData_ShapeDHist_BCombo_Cell{4,2,1}.HistData.yBox_Bdctb_Tbl,strcat(SavedtSet02HistFilePath,'Data_ShapeDHist_Bdctb_skbrL_by_brD_dtSet02_q01.csv'));
writetable(PlotData_ShapeDHist_BCombo_Cell{4,4,1}.HistData.yBox_Bdctb_Tbl,strcat(SavedtSet02HistFilePath,'Data_ShapeDHist_Bdctb_skbrLS_by_brD_dtSet02_q01.csv'));


%% Save Workspace

fprintf('Saving Workspace...\n');
save(strcat(UI.SaveFilePath,'Workspace_Ebf3_',timestamp,'.mat'));


%% Check dependencies

% % % [fList,pList] = matlab.codetools.requiredFilesAndProducts('J250407_Ebf3DistAnalysis.m');
% % % fList' % functions, FileExhange 
% % % pList.Name % Toolbox


%% Save script in directory
% html format; do not evaulate code or save figures

ScriptName=mfilename;
PublishOptions=struct('format','html','showCode',true,'evalCode',false,'catchError',false,'figureSnapMethod','print','createThumbnail',false,'outputDir',UI.SaveFilePath);
publish(strcat(ScriptName,'.m'),PublishOptions);


%% =================
%% ====== Functions



