% 20250305: Create distance maps to be used for assigning pixels and dist-Source
% blobs (Ebf3) to different distance-Targets (ex. OCN, TRAP, Beg, Bdc, Btb)

function [Img_gDistMap_Cell_Out,ImgCheck_gDistMap_Cell_Out] = fCreateDistMap(Img_Begdc_Cell_In,Img_Btb_Cell_In,Img_DistT_Cell_In,Img_DistS_Cell_In,UI_In)


%% Prepare Outputs

% = Img_gDistMap_Cell

Img_gDistMap_Cell_Out = cell(4,5);

% Img of geodesic distance map from distance-target blobs of different bone (eg, dc, tb). 
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Geodesic distance map (single), quasi-euclidean distance from epiphysis-growth plate (eg) distance-target blobs (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)
% * Col02 = Geodesic distance map (single), quasi-euclidean distance from diaphysis-cortical bone (dc) distance-target blobs (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)
% * Col03 = Geodesic distance map (single), quasi-euclidean distance from trabecular bone (tb) distance-target blobs (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)
% * Col04 = Logical Mask of Forbidden Pixels, * input * of bwdistgeodesic() geodesic distance measurement for Row3, Row 4 Col01-03 (1 = permitted pixel; 0 = forbidden pixel for  bwdistgeodesic()) (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)
% * Col05 = Logical Mask of Forbidden Pixels (Final), * output * of bwdistgeodesic() geodesic distance measurement for Row3, Row 4 Col01-03 (1 = permitted pixel; 0 = forbidden pixel for  bwdistgeodesic()) (Row 3: "real" Distance Target; Row 4: "hypothetical" bone front stain)

% = ImgCheck_gDistMap_Cell

ImgCheck_gDistMap_Cell_Out = cell(2,1);

% 2 Row; Columns:
% * Col01: Colocalize Image, gDistMap (red) vs dist target blobs (green) 



%%

% % % NumDistT = size(Img_DistT_Cell_In{3,1},3); % Number of distance target (OCN, TRAP etc)
% % % NumDistTbf = 1; % Number of "hypothetical" bone front staining = 1
NumDistT_Mtx = [...
    size(Img_DistT_Cell_In{3,1},3); ... % Number of "real" distance target (OCN, TRAP etc); = NumDistT (Row 3)
    size(Img_DistT_Cell_In{4,1},3)... % Number of "hypothetical" bone front staining = 1 = NumDistTbf (Row 4)
    ];

% = Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)
Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;


%% Geodesic distance measurement
% i) Prepare mask as INPUT of bwdistgeodesic() (1: pixels permitted; 0: pixels forbidden)
% Same mask for Row 3 (Distance Targets), Row 4 ("Hypothetical" bone front
% stain) distance measurements

if ~UI_In.MrwMask_SmOption % Not smoothed MrwMask
    Img_Beg_Temp = Img_Begdc_Cell_In{1,1}; % Line Mask
    Img_Bdc_Temp = Img_Begdc_Cell_In{1,2}; % Line Mask
else % Smoothed MrwMask
    Img_Beg_Temp = Img_Begdc_Cell_In{1,3}; % Line Mask
    Img_Bdc_Temp = Img_Begdc_Cell_In{1,4}; % Line Mask
end

% = Forbid Pixels outside bone front
Img_gDist_Mask_Temp = imfill(imdilate(Img_Beg_Temp|Img_Bdc_Temp,strel('square',2)),...
    [1;... % LinIdx of 4 corner pixels as imfill seed locations
    height(Img_Begdc_Cell_In{1,1});...
    height(Img_Begdc_Cell_In{1,1})*width(Img_Begdc_Cell_In{1,1})-height(Img_Begdc_Cell_In{1,1})+1;...
    height(Img_Begdc_Cell_In{1,1})*width(Img_Begdc_Cell_In{1,1})]);

rp_Temp = regionprops(~Img_gDist_Mask_Temp,'MajorAxisLength','PixelIdxList');
FlagID_Temp = cat(1,rp_Temp.MajorAxisLength)<10*Ebf3Sz_llim_px;
Img_gDist_Mask_Temp(cat(1,rp_Temp(FlagID_Temp).PixelIdxList)) = 1;

% = Forbid pixels in trabecular bone
Img_gDist_Mask_Temp = ~(Img_Btb_Cell_In{1,1}|Img_gDist_Mask_Temp);

% = Allow all pixels of distance-source blobs colocalized with bone fronts (Beg, Bdc, Btb) 
LinIdx_BegdctbEdge_Temp = find(Img_Beg_Temp | Img_Bdc_Temp | edge(Img_Btb_Cell_In{1,1}));
rp_dS_Temp = regionprops(Img_DistS_Cell_In{2,5},'PixelIdxList');
KeepID_dS_Temp = zeros(height(rp_dS_Temp),1,'logical');
for dSCt = 1:height(rp_dS_Temp)
    if any(ismember(rp_dS_Temp(dSCt).PixelIdxList,LinIdx_BegdctbEdge_Temp))
        KeepID_dS_Temp(dSCt) = logical(1);
    end
end
Img_dS_Mask_Temp = zeros(size(Img_gDist_Mask_Temp),'logical');
Img_dS_Mask_Temp(cat(1,rp_dS_Temp(KeepID_dS_Temp).PixelIdxList)) = logical(1);
Img_gDist_Mask_Temp = Img_gDist_Mask_Temp | Img_dS_Mask_Temp;

% = Forbid spaces of < 1 cell width
% (Note: do * not * forbid pixels of distance-target blobs)
rp_Temp = regionprops(Img_gDist_Mask_Temp,'MajorAxisLength','MinorAxisLength','PixelIdxList');
FlagID_Temp = cat(1,rp_Temp.MinorAxisLength)<Ebf3Sz_llim_px;
Img_gDist_Mask_Temp(cat(1,rp_Temp(FlagID_Temp).PixelIdxList)) = 0;

% figure; imshow(Img_geodesic_Mask_Temp);

% = Store in output cell
% Same for all rows
% % % Img_gDistMap_Cell_Out{1,4} = Img_gDist_Mask_Temp;
% % % Img_gDistMap_Cell_Out{2,4} = Img_gDist_Mask_Temp;
Img_gDistMap_Cell_Out{3,4} = repmat(Img_gDist_Mask_Temp,1,1,NumDistT_Mtx(1,1));
Img_gDistMap_Cell_Out{4,4} = repmat(Img_gDist_Mask_Temp,1,1,NumDistT_Mtx(2,1));

clearvars *_Temp;


%% Geodesic distance measurement
% ii) Distance Map

% Img_DistT_Cell,  Img_gDistMap_Cell_Out same columns for Beg, Bdc and Btb
% * Col01 = Logical Mask, epiphysis-growth plate (eg) (Row 1: Bone Edge Region Mask (Sm or not); Row 3: Distance Target; Row 4: "hypothetical" bone front stain)
% * Col02 = Logical Mask, diaphysis-cortical bone (dc) (Row 1: Bone Edge Region Mask (Sm or not); Row 3: Distance Target; Row 4: "hypothetical" bone front stain)
% * Col03 = Logical Mask, trabecular bone (tb) (Row 1: Trabecular Bone Mask cleaned from MrwHole_Mask (Sm or not); Row 3: Distance Target; Row 4: "hypothetical" bone front stain)

% Function bwdistgeodesic()
% * Assigns "NaN' to pixels forbidden by mask
% * Assigns "Inf" to pixels with no path to distance-target blobs (affect max() measurement)
% * 20250625 Note: If no DistT blobs, function assign Inf to all pixels

% % % if ~UI_In.MrwMask_SmOption % Not smoothed MrwMask
% % %     Img_Beg_Temp = Img_Begdc_Cell_In{1,5}; % Region Mask
% % % else % Smoothed MrwMask
% % %     Img_Beg_Temp = Img_Begdc_Cell_In{1,7}; % Region Mask
% % % end

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    for bfCt = 1:3 % bone front type count: epiphysis-growth plate (Beg), diaphysis-cortical bone (Bdc), trabecular (Btb)
        for dtCt = 1:NumDistT_Temp % distance target (OCN, TRAP etc) count          
            Img_gDist_Temp = ...
                bwdistgeodesic(Img_gDistMap_Cell_Out{RowIdx_Temp,4}(:,:,1),Img_DistT_Cell_In{RowIdx_Temp,bfCt}(:,:,dtCt),'quasi-euclidean');
            % % % if bfCt<2 % Beg; 20250513
            % % %     Img_NonNaNBegMask_Temp = ~isnan(Img_gDist_Temp);
            % % %     Img_NonNaNBegMask_Temp = Img_NonNaNBegMask_Temp & Img_Beg_Temp; % Pixels in Beg Region and assigned gDist
            % % %     Img_gDist_Temp(find(Img_NonNaNBegMask_Temp)) = 0; % Assign 0 gDist to pixels in Beg region to force assignment of these pixels to Beg
            % % % else % Bdc or Btb; 20250513
            % % %     Img_NonNaNBegMask_Temp = ~isnan(Img_gDist_Temp);
            % % %     Img_NonNaNBegMask_Temp = Img_NonNaNBegMask_Temp & Img_Beg_Temp; % Pixels in Beg Region and assigned gDist
            % % %     Img_gDist_Temp(intersect(find(Img_NonNaNBegMask_Temp),find(Img_gDist_Temp<1.0))) = 1.0; % Assign >0 gDist to pixels in Beg region to force assignment of these pixels to Beg
            % % %     Img_gDist_Temp(find(Img_NonNaNBegMask_Temp)) = 100; % Assign >0 gDist to pixels in Beg region to force assignment of these pixels to Beg
            % % % end
            Img_gDistMap_Cell_Out{RowIdx_Temp,bfCt}(:,:,dtCt) = Img_gDist_Temp;
        end       
    end

end

% % % % Distance measurement for Row 3: Distance Targets (TRAP, OCN) 
% % % for bfCt = 1:3 % bone front type count: epiphysis-growth plate (Beg), diaphysis-cortical bone (Bdc), trabecular (Btb)
% % %     for dtCt = 1:NumDistT % distance target (OCN, TRAP etc) count
% % %          Img_gDist_Temp = ...  
% % %             bwdistgeodesic(Img_gDistMap_Cell_Out{1,4},Img_DistT_Cell_In{3,bfCt}(:,:,dtCt),'quasi-euclidean');
% % %          % Img_gDist_Temp(isinf(Img_gDist_Temp)) = -9999; 
% % %          Img_gDistMap_Cell_Out{3,bfCt}(:,:,dtCt) = Img_gDist_Temp;
% % %     end
% % % end
% % % 
% % % % 20250325: Distance measurement for Row 4: "Hypothetical" bone front stain
% % % for bfCt = 1:3 % bone front type count: epiphysis-growth plate (Beg), diaphysis-cortical bone (Bdc), trabecular (Btb)
% % %     for dtCt = 1:NumDistTbf % 1 "hypothetical" bone front stain
% % %          Img_gDist_Temp = ...  
% % %             bwdistgeodesic(Img_gDistMap_Cell_Out{1,4},Img_DistT_Cell_In{4,bfCt}(:,:,dtCt),'quasi-euclidean');
% % %          % Img_gDist_Temp(isinf(Img_gDist_Temp)) = -9999; 
% % %          Img_gDistMap_Cell_Out{4,bfCt}(:,:,dtCt) = Img_gDist_Temp;
% % %     end
% % % end

clearvars *Temp bfCt dtCt;


%% Geodesic distance measurement
% iii) Mask to exclude from distance measurement analysis (1: pixels permitted; 0: pixels forbidden)
% Includes input logical mask for bwdistgeodesic() (Step i). Col04), plus regions without path (value
% "Inf" in * any * of the geodesic distance maps

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Create ImgStack_gDist_Temp z stack of all gDistMap; determine each k has smallest distance to
    % each pixel --> gDist_minIdx_Temp
    % gDist_minIdx_Temp (1:3*NumDistT):
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT

    ImgStack_gDist_Temp = cell2mat(permute(Img_gDistMap_Cell_Out(RowIdx_Temp,1:3),[1 3 2]));

    % = Create updated mask with forbidden (NaN) or no accss (Inf) pixels
    % "Inf" value is * any * gDistMap (Beg/Bdc/Btb; any dist-target)
    % disqualifies that pixel from further processing
    % Use sum() to ensure for Inf pixel identification
    % 20250320: Do for both gDist from distance-target (Row 3) and from
    % "hypothetical" bone front staining (Row 4)
    Img_gDist_NaNInfMask_Temp = zeros(size(Img_gDistMap_Cell_Out{RowIdx_Temp,4}(:,:,1)),'logical');
    KeepID_Temp = ... % 20250625: identify planes that are not all NaN and Inf (Inf @ All Non-NaN pixels happens if DistT signal not present)
        find(sum(sum(isnan(ImgStack_gDist_Temp)|isinf(ImgStack_gDist_Temp),1),2)<height(ImgStack_gDist_Temp)*width(ImgStack_gDist_Temp));
    Img_gDist_NaNInfMask_Temp(isnan(sum(ImgStack_gDist_Temp(:,:,KeepID_Temp),3)) | isinf(sum(ImgStack_gDist_Temp(:,:,KeepID_Temp),3))) = 1;

    % = Store in output cell
    Img_gDistMap_Cell_Out{RowIdx_Temp,5} = repmat(Img_gDist_NaNInfMask_Temp,1,1,NumDistT_Temp);

end

clearvars *_Temp;


%% Visual Check: Geodesic Distance Maps for "Real" and "Hypothetical" Distance Target (Row 3-4, Col01-03) 

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Display distance map, Row 3, Col01-03
    % 3 columns: Beg, Bdc, Btb

    % Create ImgStack_gDist_Temp z stack of all gDistMap; determine each k has smallest distance to
    % each pixel --> gDist_minIdx_Temp
    % gDist_minIdx_Temp (1:3*NumDistT):
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT

    % Distance Maps
    ImgStack_gDist_Temp_Disp = cell2mat(permute(Img_gDistMap_Cell_Out(RowIdx_Temp,1:3),[1 3 2]));

    % "KeepID_Temp_Disp" for determining max intensity for display
    KeepID_Temp_Disp = ... % 20250625: identify planes that are not all NaN and Inf (Inf @ All Non-NaN pixels happens if DistT signal not present)
        find(sum(sum(isnan(ImgStack_gDist_Temp_Disp)|isinf(ImgStack_gDist_Temp_Disp),1),2)<height(ImgStack_gDist_Temp_Disp)*width(ImgStack_gDist_Temp_Disp));
    KeepID_Temp_Disp(KeepID_Temp_Disp<(NumDistT_Temp+1)) = []; % Exclude Beg k values

    ImgStack_gDist_Temp_Disp(repmat(Img_gDistMap_Cell_Out{RowIdx_Temp,5}(:,:,1),1,1,size(ImgStack_gDist_Temp_Disp,3))) = 0; % Set gDist = NaN and Inf to 0
    ImgStack_gDist_Temp_Disp = ...
        ImgStack_gDist_Temp_Disp./max(ImgStack_gDist_Temp_Disp(:,:,KeepID_Temp_Disp),[],'all'); % Normalize to maxmimum normal distance; Ignore Beg k;
    ImgStack_gDist_Temp_Disp(ImgStack_gDist_Temp_Disp>1) = 1;
    ImgStack_gDist_Temp_Disp = mat2cell(ImgStack_gDist_Temp_Disp,height(ImgStack_gDist_Temp_Disp),width(ImgStack_gDist_Temp_Disp),repmat(1,size(ImgStack_gDist_Temp_Disp,3),1));
    ImgStack_gDist_Temp_Disp = reshape(ImgStack_gDist_Temp_Disp,[],3); % 3 Col: Beg, Bdc, Btb
    ImgStack_gDist_Temp_Disp = cell2mat(ImgStack_gDist_Temp_Disp);

    % Distance Target Blobs
    ImgStack_DistT_Temp_Disp = cell2mat(permute(Img_DistT_Cell_In(RowIdx_Temp,1:3),[1 3 2]));

    ImgStack_DistT_Temp_Disp(repmat(Img_gDistMap_Cell_Out{RowIdx_Temp,5}(:,:,1),1,1,size(ImgStack_DistT_Temp_Disp,3))) = 0; 0; % Set gDist = NaN and Inf to 0
    ImgStack_DistT_Temp_Disp = mat2cell(ImgStack_DistT_Temp_Disp,height(ImgStack_DistT_Temp_Disp),width(ImgStack_DistT_Temp_Disp),repmat(1,size(ImgStack_DistT_Temp_Disp,3),1));
    ImgStack_DistT_Temp_Disp = reshape(ImgStack_DistT_Temp_Disp,[],3); % 3 Col: Beg, Bdc, Btb
    ImgStack_DistT_Temp_Disp = cell2mat(ImgStack_DistT_Temp_Disp);

    % Combine
    Img_Disp = imfuse(ImgStack_gDist_Temp_Disp,ImgStack_DistT_Temp_Disp,'Scaling','none','ColorChannel',[1 2 0]);
    Img_Disp(1:height(Img_gDistMap_Cell_Out{RowIdx_Temp,5}):end,:,:) = 255; % Divider
    Img_Disp(:,1:width(Img_gDistMap_Cell_Out{RowIdx_Temp,5}):end,:) = 255; % Divider

    % Store as output
    ImgCheck_gDistMap_Cell_Out{dtsCt,1} = Img_Disp;
    ImgCheck_gDistMap_Cell_Out{dtsCt,1} = imresize(ImgCheck_gDistMap_Cell_Out{dtsCt,1},[800*NumDistT_Temp NaN]); % OPTIONAL: resize so each image height = 800px

    close all;
    clearvars *_Disp;

end



