% 20250207: Copy from J250202_Temp

function [Img_DistT_Cell_Out,Img_Btb_Cell_Out,ImgCheck_DistT_Cell_Out] = fDefineDistTargetEbf3(Img_MrwDef_Cell_In,Img_Begdc_Cell_In,UI_In)

close all;

%%

NumDistT = size(Img_MrwDef_Cell_In{3,6},3); % Number of "real" distance target (OCN, TRAP etc)
NumDistTbf = 1; % Number of "hypothetical" bone front staining = 1

% = Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)
Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;


%% Prepare Output Cells

% = Img_DistT_Cell 

Img_DistT_Cell_Out  = cell(4,4);

% Img of assignment of distance-target blobs to different bone (eg, dc, tb). Cell of size(3,4):
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = Logical Mask, epiphysis-growth plate (eg) (Row 1: Bone Edge Region Mask (Sm or not); Row 3: Distance Target; Row 4: Bone Edge Line mask, mildly dilated, as "hypothetical" staining)
% * Col02 = Logical Mask, diaphysis-cortical bone (dc) (Row 1: Bone Edge Region Mask (Sm or not); Row 3: Distance Target; Row 4: Bone Edge Line mask, mildly dilated, as "hypothetical" staining)
% * Col03 = Logical Mask, trabecular bone (tb) (Row 1: Trabecular Bone Mask cleaned from MrwHole_Mask (Sm or not); Row 3: Distance Target; Row 4: Edge of Trabecular Bone Mask, mildly dilated, as "hypothetical" staining)
% * Col04 = Trabecular Bone ID Label, trabecular bone (tb) (Row 1: Trabecular Bone Mask cleaned from MrwHole_Mask (Sm or not); Row 3: Distance Target; Row 4 = Row 1 for now)


% = Img_Btb_Cell

Img_Btb_Cell_Out = cell(4,2);

% Trabecular Bone Mask only; similar organization as Img_Begdc_Cell. Cell of size(3,1):
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = Trabecular Bone Mask (Btb) (logical, Row 1) 
% * Col02 = Trabecular Bone ID Label, trabecular bone (tb) (logical, Row 1)


% = ImgCheck_DistT_Cell

ImgCheck_DistT_Cell_Out = cell(1,2);

% 1 Row; 1 Column:
% * Col 01: Label image, logical masks of bone fronts, distance-target blobs, "hypothetical" bone front stain (Beg: yellow; Bdc: teal; Btb: magenta) 
% * Col 02: Label image, trabecular bone distance-target blobs labelled by different trabecular bone



%%  ==== Distance-Target Blobs assignment to Bone Edge, epiphysis-growth plate (eg) and diaphysis-cortical bone (dc)
% Col 01-02

%% Create Distance-Target blobs Masks eg, dc

% = Designate Bone Edge *Region* Masks for eg, dc
% Masks in Img_Begdc_Cell
if ~UI_In.MrwMask_SmOption % Not smoothed MrwMask
    Img_Beg_Temp = Img_Begdc_Cell_In{1,5}; % Choice will be saved as Img_DT_Cell{1,1}
    Img_Bdc_Temp = Img_Begdc_Cell_In{1,6}; % Choice will be saved as Img_DT_Cell{1,2}
else % Smoothed MrwMask
    Img_Beg_Temp = Img_Begdc_Cell_In{1,7}; % Choice will be saved as Img_DT_Cell{1,1}
    Img_Bdc_Temp = Img_Begdc_Cell_In{1,8}; % Choice will be saved as Img_DT_Cell{1,2}
end

rp_Beg_Temp = regionprops(Img_Beg_Temp,'PixelList','PixelIdxList');
rp_Bdc_Temp = regionprops(Img_Bdc_Temp,'PixelList','PixelIdxList');

% = Assign distance target blobs to Bone Edge *Region* Masks eg, dc
ImgStack_dt_eg = zeros(size(Img_MrwDef_Cell_In{3,6}),'logical'); % Outcome will be saved as Img_DT_Cell{3,1}
ImgStack_dt_dc = zeros(size(Img_MrwDef_Cell_In{3,6}),'logical'); % Outcome Will be saved as Img_DT_Cell{3,2}
ImgStack_dt_egdcRmv = zeros(size(Img_MrwDef_Cell_In{3,6}),'logical'); % carry distance-target blobs without eg and dc after this section

if UI_In.BoneFrontOnly_Option==1

    for dtCt = 1:NumDistT % distance target (OCN, TRAP etc) count

        % = Remove distance target staining of less than 0.5*Ebf3 cell size or
        % equivalent diameter < mean Ebg3 cell size
        Img_m_Temp = Img_MrwDef_Cell_In{3,6}(:,:,dtCt); % Img_Mrw

        if max(Img_m_Temp,[],'all')>eps % 20250609: Distance Target Signal Present in Slice

            [thresh_Temp,~] = multithresh(Img_m_Temp(Img_m_Temp>0),1);
            Img_dt_Temp = imbinarize(Img_m_Temp,thresh_Temp);

            rp_dt_Temp = regionprops(Img_dt_Temp,'Area','EquivDiameter','MinFeretProperties','MaxFeretProperties','PixelIdxList');
            FlagID_dt_Temp = zeros(height(rp_dt_Temp),1,'logical');
            for bCt = 1:height(rp_dt_Temp)
                if (rp_dt_Temp(bCt).MinFeretDiameter<0.5*Ebf3Sz_llim_px) | (rp_dt_Temp(bCt).EquivDiameter<0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px))
                    FlagID_dt_Temp(bCt,1) = 1;
                end
            end
            rp_dt_Temp(FlagID_dt_Temp) = [];

            Img_dt_Temp = zeros(size(Img_dt_Temp),'logical'); % update
            Img_dt_Temp(cat(1,rp_dt_Temp.PixelIdxList)) = 1;
            rp_dt_Temp = regionprops(Img_dt_Temp,'Area','PixelList','PixelIdxList'); % update

            % = Assign distance-target blobs to Beg, Bdc
            FlagID_eg_Temp = zeros(height(rp_dt_Temp),1,'logical');
            FlagID_dc_Temp = zeros(height(rp_dt_Temp),1,'logical');
            for bCt = 1:height(rp_dt_Temp)
                % Fraction of blob stain in eg
                Frac_eg_Temp = ...
                    numel(find(ismember(rp_dt_Temp(bCt).PixelIdxList,cat(1,rp_Beg_Temp.PixelIdxList))))/numel(rp_dt_Temp(bCt).PixelIdxList);
                Frac_dc_Temp = ...
                    numel(find(ismember(rp_dt_Temp(bCt).PixelIdxList,cat(1,rp_Bdc_Temp.PixelIdxList))))/numel(rp_dt_Temp(bCt).PixelIdxList);
                if (Frac_eg_Temp>=0.5) & (Frac_dc_Temp<0.5)
                    FlagID_eg_Temp(bCt,1) = 1;
                elseif (Frac_eg_Temp<0.5) & (Frac_dc_Temp>=0.5)
                    FlagID_dc_Temp(bCt,1) = 1;
                end
            end
            rp_dt_eg_Temp = rp_dt_Temp;
            rp_dt_eg_Temp(~FlagID_eg_Temp) = [];
            Img_dt_eg_Temp = zeros(size(Img_dt_Temp),'logical');
            Img_dt_eg_Temp(cat(1,rp_dt_eg_Temp.PixelIdxList)) = 1;

            rp_dt_dc_Temp = rp_dt_Temp;
            rp_dt_dc_Temp(~FlagID_dc_Temp) = [];
            Img_dt_dc_Temp = zeros(size(Img_dt_Temp),'logical');
            Img_dt_dc_Temp(cat(1,rp_dt_dc_Temp.PixelIdxList)) = 1;

            rp_dt_Temp(FlagID_eg_Temp | FlagID_dc_Temp) = [];
            Img_dt_Temp = zeros(size(Img_dt_Temp),'logical');  % update; without dc and eg blobs
            Img_dt_Temp(cat(1,rp_dt_Temp.PixelIdxList)) = 1;

            % % % figure;
            % % % imshow(single(cat(3,Img_dt_eg_Temp,Img_dt_dc_Temp,Img_dt_Temp)));

            % = Assign to output
            ImgStack_dt_eg(:,:,dtCt) = Img_dt_eg_Temp;
            ImgStack_dt_dc(:,:,dtCt) = Img_dt_dc_Temp;
            ImgStack_dt_egdcRmv(:,:,dtCt) = Img_dt_Temp; % Not eg dc; include distance target blobs in trabecular bone but needs clean up; not stored in output,

        else % 20250609: Distance Target Signal not present slice

            ImgStack_dt_eg(:,:,dtCt) = zeros(size(Img_m_Temp),'single');
            ImgStack_dt_dc(:,:,dtCt) = zeros(size(Img_m_Temp),'single');
            ImgStack_dt_egdcRmv(:,:,dtCt) = zeros(size(Img_m_Temp),'single');

        end

    end

end

% = 20250320: Create "Hypothetical" bone front stain from Bone Edge Line Mask
Img_dtBeg_Temp = imdilate(Img_Begdc_Cell_In{1,1},strel('disk',round(1.0*Ebf3Sz_ulim_px))); % "Hypothetical" Beg stain
Img_dtBdc_Temp = imdilate(Img_Begdc_Cell_In{1,2},strel('disk',round(1.0*Ebf3Sz_ulim_px))) & ~Img_dtBeg_Temp; % "Hypothetical" Bdc stain; prioritize Beg

% = Store output in Img_DT_Cell
Img_DistT_Cell_Out{1,1} = Img_Beg_Temp;
Img_DistT_Cell_Out{1,2} = Img_Bdc_Temp;

Img_DistT_Cell_Out{4,1} = Img_dtBeg_Temp;
Img_DistT_Cell_Out{4,2} = Img_dtBdc_Temp;

if UI_In.BoneFrontOnly_Option==0
    Img_DistT_Cell_Out{3,1} = ImgStack_dt_eg;
    Img_DistT_Cell_Out{3,2} = ImgStack_dt_dc;
elseif UI_In.BoneFrontOnly_Option==1 % 20250625: If no DistT (OCN, TRAP etc) given, use hypothetical bone front as real bone front
    Img_DistT_Cell_Out{3,1} = Img_DistT_Cell_Out{4,1};
    Img_DistT_Cell_Out{3,2} = Img_DistT_Cell_Out{4,2};
end

clearvars *Temp dtCt;


%%  ==== Distance-Target Blobs assignment to Trabecular Bone (tb)
% Col 03-04

% Strategy: Trabecular Bone has to be identified among marrow holes by
% distance target blobs (post removal of blobs assigned to eg dc). Then,
% distance target blobs are assigned to identified trabecular bone. 
% Process is therefore somewhat iterative since the two relies to each
% other for identification (trabecular bone) and assignment (distance target 
% blob assignment to trabecular bone) 


%%  STEP 01: Create Prelim (AreaCln) Trabecular Bone Mask
% By marrow hole size: trabecular bone are assumed to be only a portion of (larger) marrow 
% holes, and co-stained by distance targets (OCN-stained osteoblast, TRAP-stained
% osteoclasts)
% Also remove holes overlapping Bone Edge *Region* Masks for eg, dc
% Start with MrwHole Mask, in Img_Mrw_Def_Cell

Img_mh_Temp = Img_MrwDef_Cell_In{1,5}; % Input for this section; MrwHole Mask

% = Designate Bone Edge *Region* Masks for eg, dc
% Masks in Img_Begdc_Cell
if ~UI_In.MrwMask_SmOption % Not smoothed MrwMask
    Img_Beg_Temp = Img_Begdc_Cell_In{1,5}; 
    Img_Bdc_Temp = Img_Begdc_Cell_In{1,6}; 
else % Smoothed MrwMask
    Img_Beg_Temp = Img_Begdc_Cell_In{1,7}; 
    Img_Bdc_Temp = Img_Begdc_Cell_In{1,8}; 
end

% 20250513: If Marrow Hole in non-Beg, non-Bdc regions exceeds an Area Limit, keep
Img_mh2_Temp = Img_mh_Temp & (~Img_Beg_Temp) & (~Img_Bdc_Temp); 
rp_mh2_Temp = ...
    regionprops(Img_mh2_Temp,'Area','MinFeretProperties','MaxFeretProperties','PixelIdxList');
FlagID_mh2_Temp = zeros(height(rp_mh2_Temp),1,'logical');
for bCt = 1:height(rp_mh2_Temp)
    % if (rp_mh2_Temp(bCt).MinFeretDiameter<1.0*Ebf3Sz_llim_px) & (rp_mh2_Temp(bCt).MaxFeretDiameter<3.0*Ebf3Sz_llim_px) 
    % if (rp_mh2_Temp(bCt).Area<(10.0*pi*(0.5*Ebf3Sz_llim_px)^2)) | ...
    %         numel(find(ismember(rp_mh2_Temp(bCt).PixelIdxList,find(Img_Beg_Temp))))/numel(rp_mh2_Temp(bCt).PixelIdxList)>0.10 | ... % More than x% overlap between marrow hole and Beg
    %         numel(find(ismember(rp_mh2_Temp(bCt).PixelIdxList,find(Img_Bdc_Temp))))/numel(rp_mh2_Temp(bCt).PixelIdxList)>0.25 % More than x% overlap between marrow hole and Bdc
    if (rp_mh2_Temp(bCt).Area<(9.0*pi*(0.5*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px))^2)) |...
            (rp_mh2_Temp(bCt).MaxFeretDiameter<(5.0*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px))) 
        FlagID_mh2_Temp(bCt,1) = 1;
    end
end
rp_mh2_Temp(FlagID_mh2_Temp) = [];

rp_mh_Temp = regionprops(Img_mh_Temp,'PixelIdxList');
FlagID_mh_Temp = zeros(height(rp_mh_Temp),1,'logical');
for bCt = 1:height(rp_mh_Temp)
    if all(~ismember(rp_mh_Temp(bCt).PixelIdxList,cat(1,rp_mh2_Temp.PixelIdxList)))
        FlagID_mh_Temp(bCt,1) = 1;
    end
end
rp_mh_Temp(FlagID_mh_Temp) = [];

Img_mh_Temp = zeros(size(Img_mh_Temp),'logical'); % update
% % % Img_mh_Temp(cat(1,rp_mh_Temp.PixelIdxList)) = 1; % OPTION 1: Trabecular bone may extend to Beg
Img_mh_Temp(cat(1,rp_mh2_Temp.PixelIdxList)) = 1; % OPTION 2: Trabecular bone may divide into Beg, Bdc

Img_mh_AreaCln = Img_mh_Temp; % Output for this section

% % % figure; 
% % % imshow(Img_mh_AreaCln);

clearvars *Temp;
clearvars *Ct;


%% STEP02: Create Prelim (DistCln) All-Distance-Target Mask (Img_dtZ_Mask)
% All distance targets are considered for trabecular bone identification.
% Zmax of all distance target masks are therefore used.

Img_mh_Temp = Img_mh_AreaCln; % Input for this section

LinIdx_mh_Temp = find(Img_mh_Temp);

% Remove small distance-target staining unlikely associated with trabular bone. 
% As distance-target signal does not always align completely, imdilate()
% for prelim clean
Img_dtZ_Temp = logical(max(ImgStack_dt_egdcRmv,[],3)); % combine all distance-target blob information (without eg, dc blobs)
Img_dtZ_Temp = imdilate(Img_dtZ_Temp,strel('disk',round(1.5*Ebf3Sz_llim_px)));
rp_dtZ_Temp = regionprops(Img_dtZ_Temp,'PixelIdxList');
FlagID_dtZ_Temp = ones(height(rp_dtZ_Temp),1,'logical'); % Remove blobs with overlap
for bCt = 1:height(rp_dtZ_Temp)
    if ~ismember(rp_dtZ_Temp(bCt).PixelIdxList,LinIdx_mh_Temp)
        FlagID_dtZ_Temp(bCt,1) = 0;
    end
end
rp_dtZ_Temp(FlagID_dtZ_Temp) = [];

Img_dtZ_Temp = logical(max(ImgStack_dt_egdcRmv,[],3)); % update; pre imdilate()
Img_dtZ_Temp(cat(1,rp_dtZ_Temp.PixelIdxList)) = 0; 

Img_dtZ_DistCln = Img_dtZ_Temp; % Output for this section

clearvars *Temp;
clearvars *Ct;


%% STEP03: Update Prelim Trabecular Bone Mask (AreaCln->AreaDistCln) based on distance from distance-target blobs
% Quick remove marrow holes too far from (non-eg-dc) distance-target blobs

Img_dtZ_Temp = Img_dtZ_DistCln; % Input for this section
Img_mh_Temp = Img_mh_AreaCln; % Input for this section

LinIdx_dtZ_Temp = ... % Note: with imdilate()
    find(imdilate(Img_dtZ_Temp,strel('disk',round(1.5*Ebf3Sz_llim_px)))); 

rp_mh_Temp = regionprops(Img_mh_Temp,'PixelIdxList');
FlagID_mh_Temp = zeros(height(rp_mh_Temp),1,'logical');
for bCt = 1:height(rp_mh_Temp)
    if ~ismember(rp_mh_Temp(bCt).PixelIdxList,LinIdx_dtZ_Temp)
        FlagID_mh_Temp(bCt,1) = 1;
    end
end
rp_mh_Temp(FlagID_mh_Temp) = [];
Img_mh_Temp = zeros(size(Img_mh_Temp),'logical'); % update; pre imdilate()
Img_mh_Temp(cat(1,rp_mh_Temp.PixelIdxList)) = 1; 

Img_mh_AreaDistCln = Img_mh_Temp; % Output for this section

% % % figure; 
% % % imshowpair(Img_mh_AreaDistCln,Img_dtZ_DistCln);

clearvars *Temp;
clearvars *Ct;


%% STEP 04: Prelim Assign Distance-target Blobs (Edge) to Prelim (AreaDistCln) Trabecular Bone Mask; finalize Trabecular Bone Mask
% i) Use pDist2 to assign distance-target blob to (prelim) identified trabecular bone
% ii) Remove trabecular bone without distance-target blob assignment;
% outcome is final trabecular bone mask

Img_dtZ_Temp = Img_dtZ_DistCln; % Input for this section
Img_mh_Temp = Img_mh_AreaDistCln; % Input for this section

% === i) Use pDist2 to assign distance-target blob to (prelim) identified trabecular bone

Img_dtZE_Temp = edge(Img_dtZ_Temp);
rp_dtZE_Temp = regionprops(Img_dtZE_Temp,'PixelList','PixelIdxList');

rp_mh_Temp = regionprops(Img_mh_Temp,'PixelList','PixelIdxList');

mhIDKeep_dtzE_Prelim = nan(height(rp_dtZE_Temp),1,'single'); % MrwHole ID to be kept for each dt blob (will decide which mrw hole will be kept; more strict than assign)
mhIDAssign_dtZE_Prelim = nan(height(rp_dtZE_Temp),1,'single'); % MrwHole ID to be assigned to each dt blob

% for bdCt = 1:1
for bdCt = 1:height(rp_dtZE_Temp)

    % = Closest distance from each Mrw Hole blob to each pixel of distance-target Blob Edge
    % pD_D_Temp, pD_I_Temp size:
    % # Rows = # Pixels, specific (bmCt) Mrw Hole; # Cols = # Pixels distance-target Blob Edge
    % # Rows = 1 if find smallest distance; pD_I refers to the specific Mrw Hole's Pixel that is closest to that distance-target blob edge pixel
    % pDI_Mtx is the vertcat of pD_D_Temp of different bmCt (k=1), and of
    % pD_I_Temp of different bmCt (k=2).
    % (pD_I_Temp specifies which pixel in the specific mrw hole (by row) the
    % pixel is closest to. If 2 rows, or mrw holes, have similar pD_D_Temp values, a
    % wider range pD_I_is better--ie, dt blob stain more "spread" along the marrow hole)
    % The row of pDI_matrix (which specifies which marrow hole) with the shortest distance is the one the distance-target blob should be assigned to 
    
    pDI_Mtx_Temp = ...
        zeros(height(rp_mh_Temp),height(rp_dtZE_Temp(bdCt).PixelList),2,'single'); 

    for bmCt = 1:height(rp_mh_Temp)
        
          [pD_D_Temp,pD_I_Temp] = pdist2(rp_mh_Temp(bmCt).PixelList,rp_dtZE_Temp(bdCt).PixelList,...
            'euclidean','Smallest',1); % pD_D:  # Col = # Pixels, Blob Edge mhE; # Row = # Pixels, Blob Edge dtZE

          if (numel(find(pD_D_Temp>3.0*Ebf3Sz_llim_px))/numel(pD_D_Temp)>0.5) | ... % More than x fraction of dt blob edge too far away from marrow hole
                  ((numel(unique(pD_I_Temp))/numel(find(pD_D_Temp<=3.0*Ebf3Sz_llim_px))<0.125) & (numel(find(pD_D_Temp<=3.0*Ebf3Sz_llim_px))>16.0)) % dt blob edge pixels all share few mrw hole pixels (ie, not wrapping around marrow hole)
              pD_I_Temp(:) = NaN;
              pD_D_Temp(:) = NaN;
          else
              pD_I_Temp(pD_D_Temp>3.0*Ebf3Sz_llim_px) = NaN;
              pD_D_Temp(pD_D_Temp>3.0*Ebf3Sz_llim_px) = NaN;
          end

          pDI_Mtx_Temp(bmCt,:,1) = pD_D_Temp;
          pDI_Mtx_Temp(bmCt,:,2) = pD_I_Temp;

    end
    
    if ~isempty(find(any(pDI_Mtx_Temp(:,:,1)==0,2))) % one or more rows in pDI_Mtx has 0 value; ie, one or more mrw hole overlaps with dtBlob Edge
        if any(~isnan(pDI_Mtx_Temp(:,:,1)),'all')
            NumZeroinRow_Temp = sum(pDI_Mtx_Temp(:,:,1)==0,2,'omitmissing');
            [max_Temp,maxIdx_Temp] = max(NumZeroinRow_Temp,[],'all','omitmissing');
            mhIDAssign_dtZE_Prelim(bdCt,1) = maxIdx_Temp;
        end
    else % no overlap between dtblob edge and any marrow hole
        if any(~isnan(pDI_Mtx_Temp(:,:,1)),'all')
            [min_Temp,minIdx_Temp] = min(mean(pDI_Mtx_Temp(:,:,1),2,'omitnan'),[],1,'omitmissing');
            mhIDAssign_dtZE_Prelim(bdCt,1) = minIdx_Temp;
        end
    end

    if width(pDI_Mtx_Temp)>(3.0*Ebf3Sz_llim_px) % sufficiently large dt blob
        mhIDKeep_dtzE_Prelim(bdCt,1) = mhIDAssign_dtZE_Prelim(bdCt,1); % Also keep assigned mrw hole
    end

end

% === ii) Remove trabecular bone without distance-target blob assignment
FlagID_mh_Temp = ~ismember([1:height(rp_mh_Temp)],unique(mhIDKeep_dtzE_Prelim(~isnan(mhIDKeep_dtzE_Prelim))));
rp_mh_Temp(FlagID_mh_Temp) = [];
Img_mh_Temp = zeros(size(Img_mh_Temp),'logical'); % update
Img_mh_Temp(cat(1,rp_mh_Temp.PixelIdxList)) = 1;

% === 20250320: Create "hypothetical" trabecular bone staining using Final Trabecular Bone Mask 
% Give priority to Beg and Bdc. 
Img_dtBtb_Temp = imdilate(edge(Img_mh_Temp),strel('disk',round(1.0*Ebf3Sz_ulim_px))) & ...
    ~(Img_DistT_Cell_Out{4,1}|Img_DistT_Cell_Out{4,2}); % Give priority to Beg and Bdc

% === Store output in Img_DT_Cell
% Store: Final Trabecular Bone Mask: "Img_mh_Temp"
% Store: "Hypothetical" Trabecular Bone Stain: "Img_dtBtb_Temp"
% Do not Store: Near-Final Distance Target (All target) Mask: "Img_dtZ_Temp"
% (Not final as removal of marrow holes last step causese some dt blob to be
% too far away for good assignment)

Img_DistT_Cell_Out{1,3} =  Img_mh_Temp;
Img_DistT_Cell_Out{4,3} =  Img_dtBtb_Temp;

% % % figure; 
% % % imshowpair(Img_DistT_Cell_Out{1,3},Img_dtZ_Temp);

clearvars *Temp;
clearvars *Ct; 


%% STEP05: Final Assign Distance-target Blobs (Edge) to Final Trabecular Bone Mask; finalize Distance-target Blob Mask
% * Essentially a repeat of STEP04, but without ii) Removal of
% no-dt-blob-assigned trabecular bone; also do not create
% mhIDKeep_dtzE_Final as trabecular bone mask is finalized 
% * Purpose: update trabecular bone (mhID) assignment of dt blobs after some trabecular bone 
% removed in STEP04 ii)

Img_dtZ_Temp = Img_dtZ_DistCln; % Input for this section
Img_mh_Temp = Img_DistT_Cell_Out{1,3}; % Input for this section

Img_dtZE_Temp = edge(Img_dtZ_Temp); % edge of Near-Final Trabecular Bone
rp_dtZE_Temp = regionprops(Img_dtZE_Temp,'PixelList','PixelIdxList');

rp_mh_Temp = regionprops(Img_mh_Temp,'PixelList','PixelIdxList');

% % % mhIDKeep_dtzE_Final = nan(height(rp_dtZE_Temp),1,'single'); % Mrw Hole ID to be kept for each dt blob (will decide which mrw hole will be kept; more strict than assign)
mhIDAssign_dtZE_Final = nan(height(rp_dtZE_Temp),1,'single'); % Mrw Hole ID to be assigned to each dt blob

% % % close all; figure; % uncomment for visual check location of each dtZE blob

% for bdCt = 1:1
for bdCt = 1:height(rp_dtZE_Temp)

    % % % figure; % uncomment for visual check location of each dtZE blob
    % % % Img_Temp = zeros(size(Img_dtZE_Temp),'logical');
    % % % Img_Temp(rp_dtZE_Temp(bdCt).PixelIdxList) = 1;
    % % % imshowpair(Img_Temp,Img_mh_Temp);

    % = Closest distance from each Mrw Hole blob to each pixel of distance-target Blob Edge
    % pD_D_Temp, pD_I_Temp size:
    % # Rows = # Pixels, specific (bmCt) Mrw Hole; # Cols = # Pixels distance-target Blob Edge
    % # Rows = 1 if find smallest distance; pD_I refers to the specific Mrw Hole's Pixel that is closest to that distance-target blob edge pixel
    % pDI_Mtx is the vertcat of pD_D_Temp of different bmCt (k=1), and of
    % pD_I_Temp of different bmCt (k=2).
    % (pD_I_Temp specifies which pixel in the specific mrw hole (by row) the
    % pixel is closest to. If 2 rows, or mrw holes, have similar pD_D_Temp values, a
    % wider range pD_I_is better--ie, dt blob stain more "spread" along the marrow hole)
    % The row of pDI_matrix (which specifies which marrow hole) with the shortest distance is the one the distance-target blob should be assigned to 

    pDI_Mtx_Temp = ...
        zeros(height(rp_mh_Temp),height(rp_dtZE_Temp(bdCt).PixelList),2,'single'); 

    for bmCt = 1:height(rp_mh_Temp)
        
          [pD_D_Temp,pD_I_Temp] = pdist2(rp_mh_Temp(bmCt).PixelList,rp_dtZE_Temp(bdCt).PixelList,...
            'euclidean','Smallest',1); % pD_D:  # Col = # Pixels, Blob Edge mhE; # Row = # Pixels, Blob Edge dtZE

          if (numel(find(pD_D_Temp>3.0*Ebf3Sz_llim_px))/numel(pD_D_Temp)>0.5) | ... % More than x fraction of dt blob edge too far away from marrow hole
                  ((numel(unique(pD_I_Temp))/numel(find(pD_D_Temp<=3.0*Ebf3Sz_llim_px))<0.125) & (numel(find(pD_D_Temp<=3.0*Ebf3Sz_llim_px))>16.0)) % dt blob edge pixels all share few mrw hole pixels (ie, not wrapping around marrow hole)
              pD_I_Temp(:) = NaN;
              pD_D_Temp(:) = NaN;
          else
              pD_I_Temp(pD_D_Temp>3.0*Ebf3Sz_llim_px) = NaN;
              pD_D_Temp(pD_D_Temp>3.0*Ebf3Sz_llim_px) = NaN;
          end

          pDI_Mtx_Temp(bmCt,:,1) = pD_D_Temp;
          pDI_Mtx_Temp(bmCt,:,2) = pD_I_Temp;

    end
    
    if ~isempty(find(any(pDI_Mtx_Temp(:,:,1)==0,2))) % one or more rows in pDI_Mtx has 0 value; ie, one or more mrw hole overlaps with dtBlob Edge
        if any(~isnan(pDI_Mtx_Temp(:,:,1)),'all')
            NumZeroinRow_Temp = sum(pDI_Mtx_Temp(:,:,1)==0,2,'omitmissing');
            [max_Temp,maxIdx_Temp] = max(NumZeroinRow_Temp,[],'all','omitmissing');
            mhIDAssign_dtZE_Final(bdCt,1) = maxIdx_Temp;
        end
    else % no overlap between dtblob edge and any marrow hole
        if any(~isnan(pDI_Mtx_Temp(:,:,1)),'all')
            [min_Temp,minIdx_Temp] = min(mean(pDI_Mtx_Temp(:,:,1),2,'omitmissing'),[],1,'omitmissing');
            mhIDAssign_dtZE_Final(bdCt,1) = minIdx_Temp;
        end
    end

    % % % if width(pDI_Mtx_Temp)>(3.0*Ebf3Sz_llim_px) % sufficiently large dt blob
    % % %     mhIDKeep_dtzE_Final(bdCt,1) = mhIDAssign_dtZE_Final(bdCt,1); % Also keep assigned mrw hole
    % % % end

end

% = Remove dt blob edge pixels without assigned trabecular bone ID
% Note: number of dt blob edge blobs =/= dt blobs
Img_dtZE_Temp(cat(1,rp_dtZE_Temp(isnan(mhIDAssign_dtZE_Final)).PixelIdxList)) = 0; % Update
rp_dtZE_Temp = regionprops(Img_dtZE_Temp,'PixelList','PixelIdxList'); % Update
mhIDAssign_dtZE_Final(isnan(mhIDAssign_dtZE_Final)) = []; % Update

% = Create Img_dtZ_Final: (non eg, dc) Logical Mask of distance-target
% blobs associated with trabecular bone, all targets
% Match dt blobs to kept dt-blob-edge blobs
rp_dtZ_Temp = regionprops(Img_dtZ_Temp,'PixelList','PixelIdxList');
KeepID_dtZ_Temp = ones(height(rp_dtZ_Temp),1,'logical');
for bCt = 1:height(rp_dtZ_Temp)
    if any(ismember(cat(1,rp_dtZE_Temp.PixelIdxList),rp_dtZ_Temp(bCt).PixelIdxList))
        KeepID_dtZ_Temp(bCt,1) = 0;
    end
end
rp_dtZ_Temp(KeepID_dtZ_Temp) = [];
Img_dtZ_Temp = zeros(size(Img_dtZ_Temp),'logical'); % Update
Img_dtZ_Temp(cat(1,rp_dtZ_Temp.PixelIdxList)) = 1; % Update

% = Save inter-section variables
% NOTE: number of blobs in Img_dtZ_tb =/= number of blobs in Img_dtZE_tb
% due to how edge() works
Img_dtZ_tb = Img_dtZ_Temp; % Mask of all distance-target blobs associated with trabecular bone
Img_dtZE_tb = Img_dtZE_Temp; % Mask of all distance-target blob edge associated with trabecular bone

% = Create Logical Mask for each distance-target 
ImgStack_dt_tb = zeros(size(ImgStack_dt_egdcRmv),'logical');
for dtCt = 1:size(ImgStack_dt_egdcRmv,3) % distance target (OCN, TRAP etc) count
    ImgStack_dt_tb(:,:,dtCt) = ImgStack_dt_egdcRmv(:,:,dtCt) & single(Img_dtZ_tb);
end

% = Store output in Img_DT_Cell
% Already stored: Final Trabecular Bone Mask: Img_DT_Cell_Out{1,3}
% "Img_dtZ_tb" is max(ImgStack_dt_tb,[],3) and does not need to be stored
Img_DistT_Cell_Out{3,3} =  ImgStack_dt_tb; 

% % % figure; 
% % % imshowpair(Img_DistT_Cell_Out{1,3},max(Img_DistT_Cell_Out{3,3},[],3));

clearvars *Temp;
clearvars *Ct; 


%% STEP06: Label each trabecular bone blob in Final Trabecular Bone Mask
% Final trabecular bone mask stored in "Img_DT_Cell_Out{1,3}"
% Label value: 0 = Background; 1 and above = different piece of trabular bone 

Img_mh_Temp = Img_DistT_Cell_Out{1,3}; % Input for this section

rp_mh_Temp = regionprops(Img_mh_Temp,'PixelList','PixelIdxList');

Img_mm_tbLbl = zeros(size(Img_DistT_Cell_Out{1,3}),'uint16');
for bmCt = 1:height(rp_mh_Temp)
    Img_mm_tbLbl(rp_mh_Temp(bmCt).PixelIdxList) = 1*bmCt;
end

% === Store in output
Img_DistT_Cell_Out{1,4} =  Img_mm_tbLbl;
Img_DistT_Cell_Out{4,4} =  Img_mm_tbLbl; % 20250320

clearvars *Ct;


%% STEP07: Label each distance-target blob according to their assigned trabecular bone ID 
% Label value: 0 = Background; 1 and above = different piece of trabular bone
% METHOD: as edges were used for assignment in STEP 04-05, the labeling is
% done by edge first and then, the blobs are labeled based on which edge
% colocalizes with each blob and its label.
% (Again, number of blob edge =/= number of blobs (due to edge()'s
% behavior))
% 2 STEPS:
% i) Label distance-target blob edge
% ii) Extend label of distance-target blob edge to distance-target blob

Img_dtZE_Temp = Img_dtZE_tb; % Input for this section

% === i) Label distance-target blob edge
% Process all distance-targets together
rp_dtZE_Temp = regionprops(Img_dtZE_Temp,'PixelList','PixelIdxList');

Img_dtZE_tbLbl = zeros(size(Img_dtZE_Temp),'uint16');
for bdCt = 1:height(rp_dtZE_Temp)
    Img_dtZE_tbLbl(rp_dtZE_Temp(bdCt).PixelIdxList) = 1*mhIDAssign_dtZE_Final(bdCt,1);
end

% % % figure; 
% % % imshow(label2rgb(Img_dtZE_tbLbl,colormap(jet(max(Img_dtZE_tbLbl,[],'all'))),[0 0 0]));

% ii) Extend label of distance-target blob edge to distance-target blob
% Process each distance-target individually
ImgStack_dt_tbLbl = zeros(size(ImgStack_dt_egdcRmv),'uint16');
for dtCt = 1:NumDistT % distance target (OCN, TRAP etc) count
    Img_dt_Temp = ImgStack_dt_tb(:,:,dtCt); 
    % % % figure; imshowpair(logical(Img_dt_Temp),logical(max(label2rgb(Img_dtZE_tbLbl,colormap(jet(max(Img_dtZE_tbLbl,[],'all'))),[0 0 0]),[],3))); % Check colocalization
    rp_dt_Temp = regionprops(logical(Img_dt_Temp),Img_dtZE_tbLbl,'PixelValues','PixelIdxList');
    rp_dt_imd_Cell_Temp{1,1} = regionprops(logical(Img_dt_Temp),imdilate(Img_dtZE_tbLbl,strel('disk',1)),'PixelValues','PixelIdxList'); % Edge may not colocalize well when features small; allow imdilate to capture slightly off-position blobs
    rp_dt_imd_Cell_Temp{2,1} = regionprops(logical(Img_dt_Temp),imdilate(Img_dtZE_tbLbl,strel('disk',2)),'PixelValues','PixelIdxList');
    rp_dt_imd_Cell_Temp{3,1} = regionprops(logical(Img_dt_Temp),imdilate(Img_dtZE_tbLbl,strel('disk',3)),'PixelValues','PixelIdxList');    
    Img_dt_tbTbl_Temp = zeros(size(Img_dt_Temp),'uint16');
    for bCt = 1:height(rp_dt_Temp)
        Ct_Temp = tabulate(rp_dt_Temp(bCt).PixelValues); % 3 columns: Value, Count, Percent
        Ct_Temp(Ct_Temp(:,1)==0,:) = []; % Remove 0 as value choice
        [~,maxIdx_Temp] = max(Ct_Temp(:,3),[],1); % Find trabular bone ID occuring at highest percent of pixels (=frequency)
        tbID_Temp = Ct_Temp(maxIdx_Temp,1);
        if ~isempty(tbID_Temp)
            Img_dt_tbTbl_Temp(rp_dt_Temp(bCt).PixelIdxList) = repmat(uint16(tbID_Temp),numel(rp_dt_Temp(bCt).PixelIdxList),1);
        else
            for drCt=1:size(rp_dt_imd_Cell_Temp,1) % disk radius of strel()
                Ct_Temp = tabulate(rp_dt_imd_Cell_Temp{drCt,1}(bCt).PixelValues); % 3 columns: Value, Count, Percent
                Ct_Temp(Ct_Temp(:,1)==0,:) = []; % Remove 0 as value choice
                [~,maxIdx_Temp] = max(Ct_Temp(:,3),[],1); % Find trabular bone ID occuring at highest percent of pixels (=frequency)
                tbID_Temp = Ct_Temp(maxIdx_Temp,1);
                if ~isempty(tbID_Temp)
                    Img_dt_tbTbl_Temp(rp_dt_Temp(bCt).PixelIdxList) = repmat(uint16(tbID_Temp),numel(rp_dt_Temp(bCt).PixelIdxList),1);
                    break;
                end
            end
        end
    end
    % % % figure; 
    % % % imshow(label2rgb(Img_dt_tbTbl_Temp));
    ImgStack_dt_tbLbl(:,:,dtCt) = Img_dt_tbTbl_Temp;
end

% === Store output in Img_DT_Cell
Img_DistT_Cell_Out{3,4} = ImgStack_dt_tbLbl;


% === Display img of trabecular bone label, and distance target label-by-trabecular-bone; 
% save in ImgCheck
% Col 01: Trabecular Bone Label
% Col 02 to (NumDistT+1): Distance target blobs assigned to trabecular bone label
if max(Img_DistT_Cell_Out{1,4},[],'all') > 0 % trabecular bone present
    Img_tbLbl_Disp = addborder(label2rgb(Img_DistT_Cell_Out{1,4},colormap(jet(max(Img_DistT_Cell_Out{1,4},[],'all'))),[0 0 0]),2,[0 0 0],'inner');
else
    Img_tbLbl_Disp = addborder(zeros(height(Img_DistT_Cell_Out{1,4}),width(Img_DistT_Cell_Out{1,4}),3,'uint8'),2,[0 0 0],'inner');
end
for dtCt = 1: size(Img_DistT_Cell_Out{3,4},3)
    if max(Img_DistT_Cell_Out{3,4}(:,:,dtCt),[],'all') > 0 % Distance target blobs assigned to trabecular bone label
        Img_tbLbl_Disp = horzcat(Img_tbLbl_Disp,...
            addborder(label2rgb(Img_DistT_Cell_Out{3,4}(:,:,dtCt),colormap(jet(max(Img_DistT_Cell_Out{3,4}(:,:,dtCt),[],'all'))),[0 0 0]),2,[0 0 0],'inner'));
    else
        Img_tbLbl_Disp = horzcat(Img_tbLbl_Disp,...
            addborder(zeros(height(Img_DistT_Cell_Out{3,4}(:,:,dtCt)),width(Img_DistT_Cell_Out{3,4}(:,:,dtCt)),3,'uint8'),2,[0 0 0],'inner'));
    end
end
% % % figure; imshow(Img_tbLbl_Disp);

ImgCheck_DistT_Cell_Out{1,2} = Img_tbLbl_Disp;
ImgCheck_DistT_Cell_Out{1,2} = imresize(ImgCheck_DistT_Cell_Out{1,2},[800 NaN]);

clearvars *Temp *Disp;
clearvars *Ct; 


%%  ==== Prepare "Img_Begdc_Cell" equivalent for Trabular Bone: "Img_Btb_Cell"
% Similar info as Img_Begdc_Cell_Out: records the bone (edge) regions assigned to eg, dc, tb

% Trabecular Bone Mask (logical)
Img_Btb_Cell_Out{1,1} = Img_DistT_Cell_Out{1,3};
% % % Img_Btb_Cell_Out{2,1} = Img_Btb_Cell_Out{1,1};
% % % Img_Btb_Cell_Out{3,1} = repmat(Img_Btb_Cell_Out{1,1},1,1,NumDistT);
% % % Img_Btb_Cell_Out{4,1} = repmat(Img_Btb_Cell_Out{1,1},1,1,NumDistTbf); % 20250320

% Trabecular Bone Mask, Trabecular Bone labeled with ID (uint16)
Img_Btb_Cell_Out{1,2} = Img_DistT_Cell_Out{1,4};
% % % Img_Btb_Cell_Out{2,2} = Img_Btb_Cell_Out{1,2};
% % % Img_Btb_Cell_Out{3,2} = repmat(Img_Btb_Cell_Out{1,2},1,1,NumDistT);
% % % Img_Btb_Cell_Out{4,2} = repmat(Img_Btb_Cell_Out{1,2},1,1,NumDistTbf);


%% ==== ImgCheck: Colocalize Masks of Bone Front, "Real" Distance-Targets (Row 3), "Hypothetical" Bone Front Stain (Row 4)

% i) Different bone and bone front (Beg, Bdc, Btb) in different colours
cmap_Disp_Temp = vertcat(...
    [1 1 0].*0.5,... % Beg: yellow
    [0 1 1].*0.5,... % Bdc: teal
    [1 0 1].*0.5... % Btb: magenta
    );
% Create ImgStack of different bone masks
% (1 x 3) z-planes; 3 for Beg, Bdc. Btb
% Beg: k =  1
% Bdc: k = 2
% Btb: k = 3
Img_Begdctb_Disp = cell2mat(permute(Img_DistT_Cell_Out(1,1:3),[1 3 2])); 
Img_Begdctb_Disp = uint16(Img_Begdctb_Disp).*uint16(permute((1:1:size(Img_Begdctb_Disp,3)),[1 3 2]));
Img_Begdctb_Disp = max(Img_Begdctb_Disp,[],3);
Img_Begdctb_Disp = label2rgb(Img_Begdctb_Disp,cmap_Disp_Temp,[0 0 0]);

% iia) Different distance-measure targets @ different bone front (Beg, Bdc, Btb) in different colours
cmapval_Disp_Temp = linspace(0.40,1,NumDistT)'; % created needed number brightness levels (=number of distance-targets)
cmap_Disp_Temp = vertcat(...
    [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
    [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
    [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
    );

% Create ImgStack of distance-measure targets masks
% (NumDistT x 3) z-planes; 3 for Beg, Bdc. Btb
% Beg: k =  1:NumDistT
% Bdc: k = (NumDistT+1):2*NumDistT
% Btb: k = (2*NumDistT+1):3*NumDistT

Img_dT_Disp = cell2mat(permute(Img_DistT_Cell_Out(3,1:3),[1 3 2])); 
Img_dT_Disp = uint16(Img_dT_Disp).*uint16(permute((1:1:size(Img_dT_Disp,3)),[1 3 2]));
Img_dT_Disp = max(Img_dT_Disp,[],3);
Img_dT_Disp = label2rgb(Img_dT_Disp,cmap_Disp_Temp,[0 0 0]);

% iib) "Hypothetical" bone front staining @ different bone front (Beg, Bdc, Btb) in different colours
cmapval_Disp_Temp = linspace(0.40,1,NumDistTbf)'; % created needed number brightness levels (=1 for "hypothetical" bone front stain)
cmap_Disp_Temp = vertcat(...
    [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
    [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
    [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
    );

% Create ImgStack of "hypothetical" bone front stain masks
% (NumDistT x 3) z-planes; 3 for Beg, Bdc. Btb
% Beg: k =  1:NumDistTbf
% Bdc: k = (NumDistTbf+1):2*NumDistTbf
% Btb: k = (2*NumDistTbf+1):3*NumDistTbf

Img_dTbf_Disp = cell2mat(permute(Img_DistT_Cell_Out(4,1:3),[1 3 2])); 
Img_dTbf_Disp = uint16(Img_dTbf_Disp).*uint16(permute((1:1:size(Img_dTbf_Disp,3)),[1 3 2]));
Img_dTbf_Disp = max(Img_dTbf_Disp,[],3);
Img_dTbf_Disp = label2rgb(Img_dTbf_Disp,cmap_Disp_Temp,[0 0 0]);

ImgCheck_DistT_Cell_Out{1,1} = horzcat(...
    addborder(Img_Begdctb_Disp,2,[255 255 255],'inner'),...
    addborder(Img_dT_Disp,2,[255 255 255],'inner'),...
    addborder(Img_dTbf_Disp,2,[255 255 255],'inner'));
ImgCheck_DistT_Cell_Out{1,1} = imresize(ImgCheck_DistT_Cell_Out{1,1},[800 NaN]);

% % % figure; 
% % % imshow(ImgCheck_DistT_Cell_Out{1,1});

close all;
clearvars *_Temp;








