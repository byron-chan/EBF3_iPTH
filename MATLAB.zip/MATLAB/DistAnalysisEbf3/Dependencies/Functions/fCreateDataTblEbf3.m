% 20240308: Extract properties of Dist-Source blobs assigned to each Dist-Target,
% prepare Data Tables used for plotting

function [Tbl_dSAssignAdj_Cell_Out]  = fCreateDataTblEbf3(Img_DistS_Cell_In,Img_dSAssignAdj_Cell_In,Img_gDistMap_Cell_In,UI_In)


%% Prepare Output

% = "Tbl_AssignData_Cell_Out"

Tbl_dSAssignAdj_Cell_Out = cell(4,3,2);

% Contains data table from final assignments of pixels and distance-source
% blobs to distance-targets

% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = dataTbl (class: 'table'), px & dS-blob final assignments to epiphysis-growth plate (eg) distance-target blobs (Row 3,4: real/hyp Distance Target; cell array of size(1,1,NumDistT), each cell = 1 table)
% * Col02 = dataTbl (class: 'table'), px & dS-blob final assignments to diaphysis-cortical bone (dc) distance-target blobs (Row 3,4: real/hyp Distance Target; cell array of size(1,1,NumDistT), each cell = 1 table)
% * Col03 = dataTbl (class: 'table'), px & dS-blob final assignments to trabecular bone (tb) distance-target blobs (Row 3,4: real/hyp Distance Target; cell array of size(1,1,NumDistT), each cell = 1 table)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


%%

% % % NumDistT = size(Img_gDistMap_Cell_In{3,1},3); % Number of distance target (OCN, TRAP etc)
% % % NumDistTbf = size(Img_gDistMap_Cell_In{4,1},3); % Number of "hypothetical" bone front staining = 1
NumDistT_Mtx = [...
    size(Img_gDistMap_Cell_In{3,1},3); ... % Number of distance target (OCN, TRAP etc); = NumDistT (Row 3)
    size(Img_gDistMap_Cell_In{4,1},3)... % Number of "hypothetical" bone front staining = 1 = NumDistTbf (Row 4)
    ];

% = Quality of Assignment: Ignore only vs Ignore+Consider
if UI_In.dSAssignQOption==[1 0]
    Numq = 1;
elseif UI_In.dSAssignQOption==[1 1]
    Numq = 2;
end


%%

% = ColIdx_In_Temp & ColIdx_Out_Temp are used to specify where to save data
% "Img_dSAssignAdj_Cell_In" Column Idx; row for Px vs dS; column for Beg vs Bdc vs Btb, z
% for ignore quality score vs consider quality score
ColIdx_In_Temp = [3 4 5; 23 24 25];
% "Tbl_dSAssignAdj_Cell_Out" Column Idx; column for Beg vs Bdc vs Btb, z
% for ignore quality score vs consider quality score
ColIdx_Out_Temp = cat(3,[1 2 3]);

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Prepare for saving data tables
    SaveTblFilePath_Temp = strcat(UI_In.SaveFilePath,'dataTbl_dtSet',num2str(dtsCt,'%02d'),'/');
    if exist(SaveTblFilePath_Temp,'dir')==7
        rmdir(SaveTblFilePath_Temp,'s'); % important
    end
    mkdir(SaveTblFilePath_Temp);

    % = Create strings for creating filename to save data tables
    Str_B_Temp = ["Beg";"Bdc";"Btb"];
    Str_dT_Temp = [1:1:NumDistT_Temp]'; % must be column vector
    Str_dT_Temp = strcat("DistT",num2str(Str_dT_Temp,'%02d'));
    Str_Temp = table2array(combinations(Str_B_Temp,Str_dT_Temp)); % string array; size (kx2)

    for qCt = 1:Numq % ignore vs consider quality of assignment score

        % = Create:
        % i) ImgStack_Adj_PxAssignMask_Temp (logical): z-stack of all ssignment-of-distSblob masks
        % ii) ImgStack_Adj_dSAssignMask_Temp (logical): z-stack of all ssignment-of-distSblob masks
        % iii) ImgStack_gDist_Temp (single): z-stack of all DIstMap
        % Beg: k =  1:NumDistT
        % Bdc: k = (NumDistT+1):2*NumDistT
        % Btb: k = (2*NumDistT+1):3*NumDistT

        ImgStack_Adj_PxAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_In(RowIdx_Temp,ColIdx_In_Temp(1,:),qCt),[1 3 2])); % i)
        ImgStack_Adj_dSAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_In(RowIdx_Temp,ColIdx_In_Temp(2,:),qCt),[1 3 2])); % ii)
        ImgStack_gDist_Temp = cell2mat(permute(Img_gDistMap_Cell_In(RowIdx_Temp,1:3),[1 3 2])); % iii)

        % = Prepare data tables
        % From J241028_Ebf3DistAnalysis.m w/ minor modifications

        dataTbl_Cell_Temp = cell(1,1,size(ImgStack_Adj_dSAssignMask_Temp,3));

        for k = 1:size(ImgStack_Adj_dSAssignMask_Temp,3)

            % = Prepare 2 regionprops
            % i) Ref image = Dist-Source Blob image; so PixelValues = DistSource Blob Intensity
            % ii) Ref image = gDistMap; so PixelValues = gDist (px) = DistSource Blob gDist to distTarget k
            rp_I_Tbl = regionprops('table',ImgStack_Adj_dSAssignMask_Temp(:,:,k),Img_DistS_Cell_In{2,4},...
                'Area','BoundingBox','Centroid','Circularity','Eccentricity','MajorAxisLength','MinorAxisLength','MaxFeretProperties','MinFeretProperties','PixelList','PixelIdxList','PixelValues','WeightedCentroid');
            rp_I_Tbl = renamevars(rp_I_Tbl, ["PixelValues","WeightedCentroid"],...
                ["PixelValues_I","WeightedCentroid_I"]);

            rp_D_Tbl = regionprops('table',ImgStack_Adj_dSAssignMask_Temp(:,:,k),ImgStack_gDist_Temp(:,:,k),...
                'Area','Centroid','PixelList','PixelIdxList','PixelValues','WeightedCentroid');
            rp_D_Tbl = renamevars(rp_D_Tbl, ["Area","Centroid","PixelList","PixelIdxList","PixelValues","WeightedCentroid"],...
                ["Area_D","Centroid_D","PixelList_D","PixelIdxList_D","PixelValues_D","WeightedCentroid_D"]);

            if (isempty(rp_I_Tbl) & isempty(rp_D_Tbl)) % 20250801: if dSAssignMask carries no blobs (including case of no trabecular bone->no Ebf3 cells assigned to trabecular bone)

                emptyMsk_Option = logical(1);
                
                emptyMsk_fakeAssignMask = zeros(size(ImgStack_Adj_dSAssignMask_Temp(:,:,k)),'logical'); % Create fake dsAssignMask; (will remove data later)
                emptyMsk_fakeAssignMask(end-1:end,end-1:end) = 1;

                rp_I_Tbl = regionprops('table',emptyMsk_fakeAssignMask,Img_DistS_Cell_In{2,4},...
                    'Area','BoundingBox','Centroid','Circularity','Eccentricity','MajorAxisLength','MinorAxisLength','MaxFeretProperties','MinFeretProperties','PixelList','PixelIdxList','PixelValues','WeightedCentroid');
                rp_I_Tbl = renamevars(rp_I_Tbl, ["PixelValues","WeightedCentroid"],...
                    ["PixelValues_I","WeightedCentroid_I"]);

                rp_D_Tbl = regionprops('table',emptyMsk_fakeAssignMask,ImgStack_gDist_Temp(:,:,k),...
                    'Area','Centroid','PixelList','PixelIdxList','PixelValues','WeightedCentroid');
                rp_D_Tbl = renamevars(rp_D_Tbl, ["Area","Centroid","PixelList","PixelIdxList","PixelValues","WeightedCentroid"],...
                    ["Area_D","Centroid_D","PixelList_D","PixelIdxList_D","PixelValues_D","WeightedCentroid_D"]);

            else

                emptyMsk_Option = logical(0);

            end

            % = Combine rp_I_Tbl and rp_D_Tbl
            % Check that rp_I and rp_D have same order of blobs and same order of
            % pixels within each blob. If so, combine table, remove redundant columns
            if (isequal(rp_I_Tbl.Area,rp_D_Tbl. ...
                    Area_D) & isequal(cat(1,rp_I_Tbl.PixelIdxList{:}),cat(1,rp_D_Tbl.PixelIdxList_D{:})))
                rp_Tbl = horzcat(rp_I_Tbl,rp_D_Tbl);
                rp_Tbl = removevars(rp_Tbl,{'Area_D','Centroid_D','PixelList_D','PixelIdxList_D'});
                rp_Tbl.BlobIdx = (1:1:height(rp_Tbl))'; % Add column
            else
                warning('Blob data from regionprops based on Intensity and regionprops based on distance are ordered different. Cannot generate combined table.')
            end

            % = Organize rp_Tbl
            % Note: "MaxFeretCoordinates", "MinFeretCoordinates" are in formats ([x1 y1; x2
            % y2]) and not splitable by splitvars(). As unlikely to be used, will keep as
            % single row for each blob.
            rp_Tbl = splitvars(rp_Tbl,'Centroid','NewVariableNames',{'Centroid_x','Centroid_y'});
            rp_Tbl = splitvars(rp_Tbl,'BoundingBox','NewVariableNames',{'BoundingBox_x','BoundingBox_y','BoundingBox_w','BoundingBox_h'});
            rp_Tbl = splitvars(rp_Tbl,'WeightedCentroid_I','NewVariableNames',{'WeightedCentroid_I_x','WeightedCentroid_I_y'});
            rp_Tbl = splitvars(rp_Tbl,'WeightedCentroid_D','NewVariableNames',{'WeightedCentroid_D_x','WeightedCentroid_D_y'});

            % Split rp_Tbl info into info by blob and info by pixel
            % i) dataTbl_byBlob: Single value for each blob
            % * Varibles in following order:
            % BlobIdx
            % Centroid_x, Centroid_y
            % BoundingBox_x, BoundingBox_y, BoundingBox_w, BoundingBox_h,
            % Major_Axis_Length, Minor_Axis_Length, Eccentricity,
            % MaxFeretDiameter, MinFeretDiameter,
            % MaxFeretAngle, MinFeretAngle,
            % [MaxFeretCoordinates_x1, MaxFeretCoordinates_y1; MaxFeretCoordinates_x2, MaxFeretCoordinates_y2],
            % [MinFeretCoordinates_x1, MinFeretCoordinates_y1; MinFeretCoordinates_x2, MinFeretCoordinates_y2],
            % Area, Circularity,
            % WeightedCentrioid_D_x, WeightedCentrioid_D_y,
            % WeightedCentrioid_I_x, WeightedCentrioid_I_y

            dataTbl_byBlob = rp_Tbl(:,[26 2 3 4 5 6 7 8 9 10 17 20 18 21 19 22 1 11 24 25 15 16]);

            % ii) dataTbl_byPixel: Multiple values for each blob
            % * Varibles in following order:
            % PixelIdxList, PixelList_x, PixelList_y,
            % PixelValues_D,
            % PixelValues_I
            dataTbl_byPixel = rp_Tbl(:,[12 13 14 23]);
            dataTbl = table;

            % = Built plot-friendly, exportable dataTbl
            % for rCt = 1:1
            for rCt = 1:height(rp_Tbl)

                tbl_Temp = varfun(@cell2mat, dataTbl_byPixel(rCt,1:end));
                tbl_Temp.Properties.VariableNames = dataTbl_byPixel.Properties.VariableNames;
                tbl_Temp = splitvars(tbl_Temp,'PixelList','NewVariableNames',{'PixelList_x','PixelList_y'});

                tbl_Temp = horzcat(repelem(dataTbl_byBlob(rCt,1:end),height(tbl_Temp),1),tbl_Temp);
                dataTbl = vertcat(dataTbl,tbl_Temp);

            end

            % = Include Extra information not from regionprops()
            % AreaFrac = (Final total assignment area, dSAssign for k)/(Final total assignment area, PxAssign for k)
            % AreaPxAssign = Final total assignment area, PxAssign for k
            % XY_PxLength_um = pixel size (um) (same for all blobs)
            % Filename
            % Timestamp
            dataTbl.AreaFrac = dataTbl.Area./numel(find(ImgStack_Adj_PxAssignMask_Temp(:,:,k)));
            dataTbl.AreaPxAssign = repelem(numel(find(ImgStack_Adj_PxAssignMask_Temp(:,:,k))),height(dataTbl),1);
            dataTbl.XY_PxLength_umpx = repelem(UI_In.XY_PxLength_umpx,height(dataTbl),1); % Change when known;

            dataTbl.Filename = repelem(convertCharsToStrings(UI_In.Img_Filename),height(dataTbl),1);

            dataTbl.TimeStamp = repelem(UI_In.timestamp,height(dataTbl),1);

            % = Save dataTbl
            if emptyMsk_Option % 20250801: dSAssignMask has no blobs
                dataTbl = dataTbl(false,:); % empty table contents (as generated from fake mask); leave only column names
            else % save dataTbl if dsAssignMask is real and not empty
                writetable(dataTbl,strcat(SaveTblFilePath_Temp,"dataTbl_",Str_Temp(k,1),"_",Str_Temp(k,2),"_q",num2str(qCt,'%02d'),"_",unique(dataTbl.Filename),"_",UI_In.timestamp,".csv"));
            end

            % = Store in cell
            dataTbl_Cell_Temp{1,1,k} = dataTbl;

            close all;

        end

        % = Store as output
        % Reorganize Assignment Masks; store as output
        dataTbl_Cell_Temp = reshape(dataTbl_Cell_Temp,[],3,NumDistT_Temp);
        Tbl_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Out_Temp(1,1),qCt} = dataTbl_Cell_Temp(:,1,:); % Dist-source Assign Mask to Beg DistTarget
        Tbl_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Out_Temp(1,2),qCt} = dataTbl_Cell_Temp(:,2,:); % Dist-source Assign Mask to Bdc DistTarget
        Tbl_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Out_Temp(1,3),qCt} = dataTbl_Cell_Temp(:,3,:); % Dist-source Assign Mask to Btb DistTarget

    end

end

clearvars  *_Temp;
clearvars dataTbl* rp*Tbl k qCt rCt;