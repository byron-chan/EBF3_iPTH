% 20250405
% Combine Area Histograms, by DistT (TRAP, OCN, "hypothetical" bone front
% stain etc) of all bone fronts (Begdctb) or cortical + trabecular bone fronts only (Bdctb)

function [PlotData_AreaDHist_BCombo_Cell_Out,Plot_AreaDHist_BCombo_Cell_Out] = fCombineAreaDHistEbf3(PlotData_AreaDHist_Cell_In,UI_In)

%% Prepare Output Cells

% 3 Cases of describing occupancy of Distance-Source (Ebf3)
% Case 1): "Hist_dSPxbyD"
% Multi dist for each dSBlob
% Case 2.1): "Hist_dSPxbyD_Blob"
% 1 dist for each dSBlob x # px in blob
% Case 2.2): "Hist_dSUtbyD_Blob"
% 1 dist for each dSBlob x # dSUt in blob

% = PlotData_AreaDHist_BCombo_Cell

PlotData_AreaDHist_BCombo_Cell_Out = cell(4,4,2);

% Plot data from adjusted (final) assignment of distance-source blobs to different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = <empty>
% * Col02 = class "structure", histogram data, Case 1.0) (Row 3,4)
% * Col03 = class "structure", histogram data, Case 2.1) (Row 3,4)
% * Col04 = class "structure", histogram data, Case 2.2) (Row 3,4)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = Plot_AreaDHist_BCombo_Cell

Plot_AreaDHist_BCombo_Cell_Out = cell(2,4,2);

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)

% Column (match PlotData above):
% * Col01 = <empty>
% * Col02 = Histogram, Case 1.0) (Row 1,2)
% * Col03 = Histogram, Case 2.1) (Row 1,2)
% * Col04 = Histogram, Case 2.2) (Row 1,2)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


%%

% % % NumDistT = size(Img_gDistMap_Cell_In{3,1},3); % Number of distance target (OCN, TRAP etc)
% % % NumDistTbf = size(Img_gDistMap_Cell_In{4,1},3); % Number of "hypothetical" bone front staining = 1
NumDistT_Mtx = [...
    PlotData_AreaDHist_Cell_In{3,2,1}.HistData.NumDistT; ... % Number of distance target (OCN, TRAP etc); = NumDistT (Row 3)
    PlotData_AreaDHist_Cell_In{4,2,1}.HistData.NumDistT; ... % Number of "hypothetical" bone front staining = 1 = NumDistTbf (Row 4)
    ];

% = Quality of Assignment: Ignore only vs Ignore+Consider
if UI_In.dSAssignQOption==[1 0]
    Numq = 1;
elseif UI_In.dSAssignQOption==[1 1]
    Numq = 2;
end



%% Case 1.1): "Hist_dSPxbyD"

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    for qCt=1:Numq

        HistData_Temp = PlotData_AreaDHist_Cell_In{RowIdx_Temp,2,qCt}.HistData;

        % Case 1)
        % Row01: Row02/Row03 (to be plotted)
        % Row02: Number of Pixels, PxAssign, in each distance HistBin
        % Row03: Number of Pixels, dSAssign, in each distance HistBin (each blob's every pixel assigned its own PixelValues_D)
        HistData_Temp.HistCt_Begdctb = zeros(1,width(HistData_Temp.HistCt),NumDistT_Temp,'single');
        for dtCt = 1: NumDistT_Temp % DistT (not DistTSet) count
            HistCt_Begdctb_Temp = sum(HistData_Temp.HistCt(:,:,dtCt:NumDistT_Temp:end),3,'omitmissing');
            HistCt_Begdctb_Temp = HistCt_Begdctb_Temp(3,:)./HistCt_Begdctb_Temp(2,:);
            HistData_Temp.HistCt_Begdctb(:,:,dtCt) = HistCt_Begdctb_Temp;
        end

        HistData_Temp.HistCt_Bdctb = zeros(1,width(HistData_Temp.HistCt),NumDistT_Temp,'single');
        for dtCt = 1: NumDistT_Temp % DistT (not DistTSet) count
            HistCt_Bdctb_Temp = sum(HistData_Temp.HistCt(:,:,(NumDistT_Temp+dtCt):NumDistT_Temp:end),3,'omitmissing');
            HistCt_Bdctb_Temp = HistCt_Bdctb_Temp(3,:)./HistCt_Bdctb_Temp(2,:);
            HistData_Temp.HistCt_Bdctb(:,:,dtCt) = HistCt_Bdctb_Temp;
        end

        % = 20250405: HistCt_Tbl (2D table for export into csv)
        % 3 Columns: [dtCt HistBin Row01Val]
        for dtCt = 1: NumDistT_Temp
            Mtx_Begdctb_Temp = horzcat(repmat(dtCt,width(HistData_Temp.HistCt_Begdctb(1,:,dtCt)),1),... % dtCt
                (1:1:width(HistData_Temp.HistCt_Begdctb(1,:,dtCt)))',... % HistBin
                HistData_Temp.HistCt_Begdctb(1,:,dtCt)'); % Row01Val
            Mtx_Bdctb_Temp = horzcat(repmat(dtCt,width(HistData_Temp.HistCt_Bdctb(1,:,dtCt)),1),... % dtCt
                (1:1:width(HistData_Temp.HistCt_Bdctb(1,:,dtCt)))',... % HistBin
                HistData_Temp.HistCt_Bdctb(1,:,dtCt)'); % Row01Val
            if dtCt<2
                DataExp_Begdctb_Temp = Mtx_Begdctb_Temp;
                DataExp_Bdctb_Temp = Mtx_Bdctb_Temp;
            else
                DataExp_Begdctb_Temp = vertcat(DataExp_Begdctb_Temp,Mtx_Begdctb_Temp);
                DataExp_Bdctb_Temp = vertcat(DataExp_Bdctb_Temp,Mtx_Bdctb_Temp);
            end
        end
        HistData_Temp.HistCt_Begdctb_Tbl = ...
            array2table(DataExp_Begdctb_Temp,'VariableNames',{'dtCt','HistBin','Row01Val'});
        HistData_Temp.HistCt_Bdctb_Tbl = ...
            array2table(DataExp_Bdctb_Temp,'VariableNames',{'dtCt','HistBin','Row01Val'});

        PlotData_AreaDHist_BCombo_Cell_Out{RowIdx_Temp,2,qCt}.HistData = HistData_Temp;

    end

end


%% Case 2.1) and 2.2): "Hist_dSPxbyD_Blob", "Hist_dSUtbyD_Blob"

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    for csCt = 1:2 % Case 2.1), 2.2)

        if csCt==1
            ColIdx_Temp = 3;
        elseif csCt==2
            ColIdx_Temp = 4;
        end

        for qCt = 1:Numq

            HistData_Temp = PlotData_AreaDHist_Cell_In{RowIdx_Temp,ColIdx_Temp,qCt}.HistData;

            % Case 2.1) "Data_HistCt_dSPxbyD_Blob_Temp": 3 rows:
            % Row01: Row03/Row02 (to be plotted)
            % Row02: Correction Factor for normalizing different number of pixels assigned to each k, each HistBin_D
            % (Inversely proportional to Row02: "Number of Pixels, PxAssign, in each distance HistBin", in Case 1)
            % Row03: Number of Pixels, dSAssign, in each distance HistBin (each blob's every pixel assigned blob's mean PixelValues_D)
            HistData_Temp.HistCt_Begdctb = zeros(1,width(HistData_Temp.HistCt),NumDistT_Temp,'single');
            for dtCt = 1: NumDistT_Temp % DistT (not DistTSet) count
                HistCt_Begdctb_Temp = HistData_Temp.HistCt(3,:,dtCt:NumDistT_Temp:end)./HistData_Temp.HistCt(2,:,dtCt:NumDistT_Temp:end);
                HistCt_Begdctb_Temp = sum(HistCt_Begdctb_Temp,3,'omitmissing');
                HistData_Temp.HistCt_Begdctb(:,:,dtCt) = HistCt_Begdctb_Temp;
            end

            HistData_Temp.HistCt_Bdctb = zeros(1,width(HistData_Temp.HistCt),NumDistT_Temp,'single');
            for dtCt = 1: NumDistT_Temp % DistT (not DistTSet) count
                HistCt_Bdctb_Temp = HistData_Temp.HistCt(3,:,(NumDistT_Temp+dtCt):NumDistT_Temp:end)./HistData_Temp.HistCt(2,:,(NumDistT_Temp+dtCt):NumDistT_Temp:end);
                HistCt_Bdctb_Temp = sum(HistCt_Bdctb_Temp,3,'omitmissing');
                HistData_Temp.HistCt_Bdctb(:,:,dtCt) = HistCt_Bdctb_Temp;
            end

            % = 20250405: HistCt_Tbl (2D table for export into csv)
            % 3 Columns: [dtCt HistBin Row01Val]
            for dtCt = 1: NumDistT_Temp
                Mtx_Begdctb_Temp = horzcat(repmat(dtCt,width(HistData_Temp.HistCt_Begdctb(1,:,dtCt)),1),... % dtCt
                    (1:1:width(HistData_Temp.HistCt_Begdctb(1,:,dtCt)))',... % HistBin
                    HistData_Temp.HistCt_Begdctb(1,:,dtCt)'); % Row01Val
                Mtx_Bdctb_Temp = horzcat(repmat(dtCt,width(HistData_Temp.HistCt_Bdctb(1,:,dtCt)),1),... % dtCt
                    (1:1:width(HistData_Temp.HistCt_Bdctb(1,:,dtCt)))',... % HistBin
                    HistData_Temp.HistCt_Bdctb(1,:,dtCt)'); % Row01Val
                if dtCt<2
                    DataExp_Begdctb_Temp = Mtx_Begdctb_Temp;
                    DataExp_Bdctb_Temp = Mtx_Bdctb_Temp;
                else
                    DataExp_Begdctb_Temp = vertcat(DataExp_Begdctb_Temp,Mtx_Begdctb_Temp);
                    DataExp_Bdctb_Temp = vertcat(DataExp_Bdctb_Temp,Mtx_Bdctb_Temp);
                end
            end
            HistData_Temp.HistCt_Begdctb_Tbl = ...
                array2table(DataExp_Begdctb_Temp,'VariableNames',{'dtCt','HistBin','Row01Val'});
            HistData_Temp.HistCt_Bdctb_Tbl = ...
                array2table(DataExp_Bdctb_Temp,'VariableNames',{'dtCt','HistBin','Row01Val'});

            PlotData_AreaDHist_BCombo_Cell_Out{RowIdx_Temp,ColIdx_Temp,qCt}.HistData = HistData_Temp;

        end

    end

end

clearvars *Temp *Disp dtCt qCt csCt dtsCt;


%% Prepare Histograms

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Define colormap for plotting all histograms
    cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
    cmap_Disp_Temp = vertcat(...
        [0.7 0.7 0.7].*cmapval_Disp_Temp... % Combined Bone Fronts: Grey
        );

    % = Specify HistData to plot
    ColIdx_PlotInOut_Temp = [2:4]; % Case 1), 2.1), 2.2)

    for csCt = 1:width(ColIdx_PlotInOut_Temp) % number of cases

        for qCt = 1:Numq

            HistData_Temp = PlotData_AreaDHist_BCombo_Cell_Out{RowIdx_Temp,ColIdx_PlotInOut_Temp(csCt),qCt}.HistData;

            % = Figure 01a: 2 columns for HistCt_Begdctb, HistCt_Bdctb; NumDistT_Temp rows

            FigHandle01a = figure('Position',[25 150 1200 320*NumDistT_Temp],'visible','off','PaperPositionMode','auto'); % [left bottom width height]
            tlo = tiledlayout(NumDistT_Temp,2,'TileSpacing','Compact','Padding','tight','TileIndexing', 'columnmajor'); % tile layout; replace subplot()
            set(gcf,'color','white');

            for cbCt = 1:2 % HistCt_Begdctb, HistCt_Bdctb

                for dtCt = 1:NumDistT_Temp

                    x_Temp = HistData_Temp.HistBinLbl_D;

                    if cbCt == 1
                        y_Temp = HistData_Temp.HistCt_Begdctb(1,:,dtCt);
                        Str_cb_Temp = "_Begdctb";
                    elseif cbCt == 2
                        y_Temp = HistData_Temp.HistCt_Bdctb(1,:,dtCt);
                        Str_cb_Temp = "_Bdctb";
                    end

                    ax = nexttile(tlo);
                    hold(ax, 'on'); grid off;

                    bh = bar(x_Temp,y_Temp,'FaceColor','flat','FaceAlpha',0.50);
                    bh(1).CData = repmat(cmap_Disp_Temp(dtCt,:),height(bh(1).CData),1);
                    bh(1). LineWidth = 2.00;

                    try
                    ylim([0 max(y_Temp,[],'all')]);
                    catch
                        1+1;
                    end

                    xlabel('Distance to Target (um)','interpreter','none');
                    ylabel(HistData_Temp.HistyLbl,'interpreter','none');
                    title(strcat("dtSet",num2str(dtsCt,'%02d'),"_DistT",num2str(dtCt,'%02d'),Str_cb_Temp,'_q',num2str(qCt,'%02d')),'interpreter','none');

                    fontname('Arial'); fontsize(16,'points'); set(gca,'FontWeight','bold');

                end

            end

            sgtitle(strcat(HistData_Temp.HistName),'interpreter','none','FontName','Arial','FontSize',12,'FontWeight','bold');

            % = Prepare display, also store as plot output
            iptsetpref("ImshowBorder","tight"); % remove borders; do before export_fig

            Img_Fig01a_Temp =  export_fig(FigHandle01a,'-r150');
            Img_Fig01a_Temp = imresize(Img_Fig01a_Temp,[round(1.5*325*NumDistT_Temp) NaN]); % Proportional to height of FigHandle

            % % % figure; imshow(Img_Fig01a_Temp);

            Plot_AreaDHist_BCombo_Cell_Out{dtsCt,ColIdx_PlotInOut_Temp(csCt),qCt} = Img_Fig01a_Temp;

            close all;

        end

    end

end

clearvars *_Temp *_Disp FigHandle* tlo ax bh k hCt;