% 20250328: fPlotShapevsDistEbf3() prepares data and histogram of aspect ratio of distance-source blobs (Ebf3) vs distance to their assigned different distance
% targets @ different bone fronts (Beg, Bdc, Btb)

function [PlotData_ShapeDHist_Cell_Out,Plot_ShapeDHist_Cell_Out,ImgCheck_ShapeDHist_Cell_Out] = ...
    fPlotShapeDHistEbf3(Img_DistS_Cell_In,Img_gDistMap_Cell_In,Img_dSAssignAdj_Cell_In,UI_In)

%% Prepare Output Cells

% 6 Cases of using skeleton branch length to measure aspect ratio of
% dist-source blobs:

% * Case 1.1): "Hist_skbrL_by_brD"
% Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to 1 HistBin_D
% * Case 1.2): "Hist_skbrL_by_brpxD"
% Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to multiple HistBin_D
% * Case 1.3): "Hist_skbrLS_by_brD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to 1 HistBin_D
% * Case 1.4): "Hist_skbrLS_by_blobD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to 1 HistBin_D
% * Case 1.5): "Hist_skbrLS_by_brpxD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to multiple HistBin_D
% * Case 1.6): "Hist_skbrLS_by_blobpxD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to multiple HistBin_D

% Each case may ignore quality of assignment (q0), or consider quality of assignment (q1)

% = PlotData_ShapeDHist_Cell

PlotData_ShapeDHist_Cell_Out = cell(4,7,2);

% Plot data from adjusted (final) assignment of distance-source blobs to different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = <empty>
% * Col02 = class "structure", histogram data, Case 1.1) (Row 3,4)
% * Col03 = class "structure", histogram data, Case 1.2) (Row 3,4)
% * Col04 = class "structure", histogram data, Case 1.3) (Row 3,4)
% * Col05 = class "structure", histogram data, Case 1.4) (Row 3,4)
% * Col06 = class "structure", histogram data, Case 1.5) (Row 3,4)
% * Col07 = class "structure", histogram data, Case 1.6) (Row 3,4)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = Plot_AreaDHist_Cell

Plot_ShapeDHist_Cell_Out = cell(2,7,2);

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)

% Column (match PlotData above):
% * Col01 = <empty>
% * Col02 = Histogram, Case 1.1) (Row 1,2)
% * Col03 = Histogram, Case 1.2) (Row 1,2)
% * Col04 = Histogram, Case 1.3) (Row 1,2)
% * Col05 = Histogram, Case 1.4) (Row 1,2)
% * Col06 = Histogram, Case 1.5) (Row 1,2)
% * Col07 = Histogram, Case 1.6) (Row 1,2)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = ImgCheck_ShapeDHist_Cell_Out

ImgCheck_ShapeDHist_Cell_Out = cell(2,1,2);

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Label Img (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), pixels, dist-source blobs and skeleton branches
% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


%%

% % % NumDistT = size(Img_gDistMap_Cell_In{3,1},3); % Number of distance target (OCN, TRAP etc)
% % % NumDistTbf = size(Img_gDistMap_Cell_In{4,1},3); % Number of "hypothetical" bone front staining = 1
NumDistT_Mtx = [...
    size(Img_gDistMap_Cell_In{3,1},3); ... % Number of distance target (OCN, TRAP etc); = NumDistT (Row 3)
    size(Img_gDistMap_Cell_In{4,1},3)... % Number of "hypothetical" bone front staining = 1 = NumDistTbf (Row 4)
    ];

% = Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)
Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;

% = Quality of Assignment: Ignore only vs Ignore+Consider
if UI_In.dSAssignQOption==[1 0]
    Numq = 1;
elseif UI_In.dSAssignQOption==[1 1]
    Numq = 2;
end


%%

% =  Logical Mask, pixels excluded from PxAssign Histogram
% Use Mask of Non-trabecular bone marrow holes that are likely tears from biopsy preparations
% These pixels are excluded from histogram preparations as dist-source
% blobs cannot sit on these pixels

Img_PxHistExclude_Mask_Temp = Img_DistS_Cell_In{1,6};

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % === Preparations for all k and qCt
    % "ColIdx_In_Temp' specifies the column Idx of where data needed is stored in
    % "Img_dSAssignAdj_Cell". Row for Px vs dS; column for Beg vs Bdc vs Btb, z
    % for ignore quality score vs consider quality score
    % % % ColIdx_In_Temp = cat(3,[3 4 5; 23 24 25],[6 7 8; 26 27 28]);
    ColIdx_In_Temp = [3 4 5; 23 24 25];

    % "ColIdx_Out_Temp' specifies the column Idx of where hist data is stored in
    % "PlotData_ShapevsD_Cell_Out". 1 Row; Column for:
    % * Case 1.1) Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to 1 HistBin_D
    % * Case 1.2) Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to multiple HistBin_D
    % * Case 1.3) Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to 1 HistBin_D
    % * Case 1.4) Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to 1 HistBin_D
    % * Case 1.5) Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to multiple HistBin_D
    % * Case 1.6) Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to multiple HistBin_D
    % z for ignore quality score vs consider quality score
    % % % ColIdx_Out_Temp = cat(3,[2 4 6 8 10 12],[3 5 7 9 11 13]);
    ColIdx_Out_Temp = [2 3 4 5 6 7];

    % "ColIdx_ImgCheck_Out_Temp' specifies the column Idx of where ImgCheck data is stored in
    % "ImgCheck_ShapevsD_Cell_Out". 1 Row; 1 Column (All cases same)
    % z for ignore quality score vs consider quality score
    ColIdx_ImgCheck_Out_Temp = 1;

    % === Create string labels for each k for saving with histogram data
    Str_B_Temp = ["Beg";"Bdc";"Btb"];
    Str_dT_Temp = (1:1:NumDistT_Temp)'; % must be column vector
    Str_dT_Temp = strcat("DistT",num2str(Str_dT_Temp,'%02d'));
    Str_Temp = table2array(combinations(Str_B_Temp,Str_dT_Temp)); % string array; size (kx2)
    clearvars Str_B_Temp Str_dT_Temp;

    for qCt = 1:Numq % ignore vs consider quality of assignment score

        % === Create for All BoxChart creation, for each qCt:
        % (Same for all cases)
        % i) ImgStack_Hist_PxAssignMask_Temp (logical): z-stack of all
        % assignment-of-pixel masks to be used for histogram; remove pixels
        % that are not trabecular bone but tears in biopsy or without k
        % assignment due to geodesic distance measurement inaccessbility
        % ii) ImgStack_Hist_dSAssignMask_Temp (logical): z-stack of all assignment-of-distSblob masks
        % iii) ImgStack_gDist_um_Temp (single): z-stack of all DIstMap; *convert to um*
        % Beg: k =  1:NumDistT
        % Bdc: k = (NumDistT+1):2*NumDistT
        % Btb: k = (2*NumDistT+1):3*NumDistT
        ImgStack_Hist_PxAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_In(RowIdx_Temp,ColIdx_In_Temp(1,:),qCt),[1 3 2])); % i)
        ImgStack_Hist_PxAssignMask_Temp = ImgStack_Hist_PxAssignMask_Temp & ... % 20250318: exclude non-trabecular marrow hole pixels that are tears in biopsy prep or without k assignment
            repmat(~Img_PxHistExclude_Mask_Temp,1,1,size(ImgStack_Hist_PxAssignMask_Temp,3));
        ImgStack_Hist_dSAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_In(RowIdx_Temp,ColIdx_In_Temp(2,:),qCt),[1 3 2])); % ii)
        ImgStack_gDist_um_Temp = UI_In.XY_PxLength_umpx.*cell2mat(permute(Img_gDistMap_Cell_In(RowIdx_Temp,1:3),[1 3 2])); % iii)

        % === Define HistName Root 
        % (Same for all cases)
        HistName_Case_Temp = [...
            "Hist_skbrL_by_brD",... % Case 1.1
            "Hist_skbrL_by_brpxD",... % Case 1.2
            "Hist_skbrLS_by_brD",... % Case 1.3
            "Hist_skbrLS_by_blobD",... % Case 1.4
            "Hist_skbrLS_by_brpxD",... % Case 1.5
            "Hist_skbrLS_by_blobpxD"]; % Case 1.6

        % === Define Histogram Edge & Bin Label for Distance (um)
        % (Same for all cases)
        HistEdgeMax_Px_D_Temp = ImgStack_gDist_um_Temp.*single(ImgStack_Hist_PxAssignMask_Temp);
        HistEdgeMax_Px_D_Temp(isnan(HistEdgeMax_Px_D_Temp) | isinf(HistEdgeMax_Px_D_Temp)) = -9.99; % Exclude from max distance comparison
        HistEdgeMax_Px_D_Temp = max(HistEdgeMax_Px_D_Temp,[],3);
        HistEdgeMax_dS_D_Temp = ImgStack_gDist_um_Temp.*single(ImgStack_Hist_dSAssignMask_Temp);
        HistEdgeMax_dS_D_Temp(isnan(HistEdgeMax_dS_D_Temp) | isinf(HistEdgeMax_dS_D_Temp)) = -9.99; % Exclude from max distance comparison
        HistEdgeMax_dS_D_Temp = max(HistEdgeMax_dS_D_Temp,[],3);
        HistEdgeMax_D_Temp = max(max(HistEdgeMax_Px_D_Temp,[],'all'),max(HistEdgeMax_dS_D_Temp,[],'all'));

        HistEdgeStep_D_Temp = UI_In.PlotDistStep_um; % in pixels
        HistEdge_D_Temp = 0:HistEdgeStep_D_Temp:HistEdgeStep_D_Temp*ceil(HistEdgeMax_D_Temp./HistEdgeStep_D_Temp);
        clearvars HistEdgeMax_*;

        HistBinLbl_D_Temp = strings(1,(numel(HistEdge_D_Temp)-1));
        for bCt = 1:(numel(HistEdge_D_Temp)-1) % HistBin Count
            str_Temp = strcat(num2str(HistEdge_D_Temp(bCt)),'-',num2str(HistEdge_D_Temp(bCt+1)));
            HistBinLbl_D_Temp(1,bCt) = str_Temp;
        end
        clearvars str_Temp bCt;

        % === Dist-Source Blob Shape by Skeleton Branch Length 
        % (Same for all cases)
        % Use geodesic distance measurement
        % https://www.mathworks.com/matlabcentral/answers/67123-how-to-find-length-of-branch-in-a-skeleton-image
        % Case 1.1) Multiple branch length per dSblob; 1 distance-to-DistT per skel branch
        % (ie, 1 dist-source blob can be represented by > 1 skel branch, in >1 HistBin_D)
        % Case 1.2) 1 branch length = sum branch length per dSblob; 1 distance-to-DistT per dSBlob
        % (ie, 1 dist-source blob represented by 1 branch, in 1 HistBin_D)

        % == Create Img of labels for PxAssignMask (label = k), dsAssignMask
        % (label = k), and dSMask (label = which blob)
        Img_Lbl_PxAssignMask_Temp = ImgStack_Hist_PxAssignMask_Temp.*permute((1:1:size(ImgStack_Hist_PxAssignMask_Temp,3)),[1 3 2]);
        Img_Lbl_PxAssignMask_Temp = single(max(Img_Lbl_PxAssignMask_Temp,[],3));

        Img_Lbl_dSAssignMask_Temp = ImgStack_Hist_dSAssignMask_Temp.*permute((1:1:size(ImgStack_Hist_dSAssignMask_Temp,3)),[1 3 2]);
        Img_Lbl_dSAssignMask_Temp = single(max(Img_Lbl_dSAssignMask_Temp,[],3));

        Img_Lbl_dSBlobIdxMask_Temp = single(bwlabel(logical(Img_Lbl_dSAssignMask_Temp))); % Label all dsBlobs, removing k info
        
        % == Prepare skeleton for skeleton branch length measurement
        Img_sk_Temp = logical(sum(single(ImgStack_Hist_dSAssignMask_Temp),3));
        % % % Img_sk_Temp = imfill(Img_sk_Temp,'holes'); 
        Img_sk_Temp = bwskel(Img_sk_Temp); % skeleton of all dist-source blobs with dist target assignment + distance measurement
        % % % Img_sk_Temp = bwskel(Img_sk_Temp,'MinBranchLength',round(0.5*Ebf3Sz_llim_px));

        Img_skbp_Temp =  bwmorph(Img_sk_Temp,'branchpoints'); % Skeleton branch points
        Img_skbr_Temp = Img_sk_Temp & ~Img_skbp_Temp; % Skeleton branches = Skeleton minus branch points

        rp_skbr_dsBlobIdx_Temp = ... % PixelValues = which dS blob idx
            regionprops(Img_skbr_Temp,Img_Lbl_dSBlobIdxMask_Temp,'Area','PixelValues','PixelIdxList');
        rp_skbr_kAssign1_Temp = ... % PixelValues = k Assignment of each skeleton; match to dist-source blob (Ebf3) assign label from each skeleton branch comes from (preferred)
            regionprops(Img_skbr_Temp,Img_Lbl_dSAssignMask_Temp,'Area','PixelValues','PixelIdxList');
        rp_skbr_kAssign2_Temp = ... % PixelValues = k Assignment of each skeleton; match to px assign label from each skeleton branch sits (2nd choice, if preferred kAssign1 no value)
            regionprops(Img_skbr_Temp,Img_Lbl_PxAssignMask_Temp,'Area','PixelValues','PixelIdxList');      
        % % % [maxArea_Temp,maxArea_Idx_Temp] = ...
        % % %     max(cat(1,rp_skbr_k1_Temp.Area),[],1); % For debugging only: pick dSBlob with largest skeleton, most likely with multiple branches
        clearvars Img_sk_Temp Img_skbp_Temp maxArea_Temp maxArea_Idx_Temp;

        % == Measure Skeleton branch length
        % (Same for all cases)
        ImgStack_skbrLength_um_Temp = zeros(size(ImgStack_Hist_dSAssignMask_Temp),'single'); % skel branch length (um) for each k; zero branch length not expected
        ImgStack_skbrMask_Temp = zeros(size(ImgStack_Hist_dSAssignMask_Temp),'logical'); % all skel br pixel = 1 for each k
   
        for brCt = 1:height(rp_skbr_kAssign1_Temp) % skeleton branch count (pre branch pt removal)           
            % for brCt = 1419:1419
            
            Img_skbrMask_brCt_Temp = zeros(size(Img_skbr_Temp),'logical');
            Img_skbrMask_brCt_Temp(rp_skbr_kAssign1_Temp(brCt).PixelIdxList) = 1; % Mask of skeleton branch
            Img_skbrepMask_brCt_Temp = bwmorph(Img_skbrMask_brCt_Temp,'endpoints'); % Skeleton branch end points
            LinIdx_skbrepMask_brCt_Temp = find(Img_skbrepMask_brCt_Temp);
            if numel(LinIdx_skbrepMask_brCt_Temp)<2 % single point skel branch; ie, skeleton branch length = 1; geodesic distance between skeleton branch endpoints = 0
                continue;
            end
            
            % = Which dist source blob distance branch belongs to
            dSBlobIdx_brCt_Temp = rp_skbr_dsBlobIdx_Temp(brCt).PixelValues; 
            dSBlobIdx_brCt_Temp(dSBlobIdx_brCt_Temp<eps) = []; % may have sporadic 0 due to imfill()
            if isempty(dSBlobIdx_brCt_Temp)
                continue;
            end
            dSBlobIdx_brCt_Temp = single(round(mean(single(dSBlobIdx_brCt_Temp),'all')));
            
            % = Length of skeleton branch
            Img_gDist_brCt_Temp = bwdistgeodesic(Img_skbrMask_brCt_Temp,LinIdx_skbrepMask_brCt_Temp(1)); % geodesic distance (px) between skeleton branch endpoints
            % % % Img_gDist_brCt_Disp = Img_gDist_brCt_Temp;
            % % % Img_gDist_brCt_Disp(isnan(Img_gDist_brCt_Disp)) = 0;
            % % % figure; imshow(Img_gDist_brCt_Disp./max(Img_gDist_brCt_Disp,[],'all'));

            skbrLength_um_brCt_Temp = UI_In.XY_PxLength_umpx .* max(Img_gDist_brCt_Temp(~isnan(Img_gDist_brCt_Temp)),[],'all'); % skeleton branch length = max gDist (um)
            
            % = Closest distance target of skeleton branch
            kAssign_brCt_Temp = rp_skbr_kAssign1_Temp(brCt).PixelValues; %  Determine which k (closest dist target) skeleton branch belongs to; 1 value per skeleton branch pixel
            kAssign_brCt_Temp(kAssign_brCt_Temp<eps) = []; % may have sporadic 0 due to imfill()
            if isempty(kAssign_brCt_Temp) % Not sure why this happens (all rp_skbr_kAssign1_Temp(brCt).PixelValues = 0)
                kAssign_brCt_Temp = rp_skbr_kAssign2_Temp(brCt).PixelValues; 
                kAssign_brCt_Temp(kAssign_brCt_Temp<eps) = []; % may have sporadic 0 due to imfill()
            end
            kAssign_brCt_Temp = single(round(mean(single(kAssign_brCt_Temp),'all')));
            
            % = Load into ImgStack                        
            Img_skbrLength_um_brCt_Temp = single(Img_skbrMask_brCt_Temp).*single(skbrLength_um_brCt_Temp);  % Load info into Image Stacks
            ImgStack_skbrLength_um_Temp(:,:,kAssign_brCt_Temp) = ...
                ImgStack_skbrLength_um_Temp(:,:,kAssign_brCt_Temp) + Img_skbrLength_um_brCt_Temp;

            ImgStack_skbrMask_Temp(:,:,kAssign_brCt_Temp) = ...
                ImgStack_skbrMask_Temp(:,:,kAssign_brCt_Temp) | Img_skbrMask_brCt_Temp;

            if brCt<2 | ~exist('Mtx_skbrLength_dsBlobIdx_k_Temp') % For summing skeleton branch length in each dsBlob
                Mtx_skbrLength_dsBlobIdx_k_Temp = horzcat(skbrLength_um_brCt_Temp,dSBlobIdx_brCt_Temp,kAssign_brCt_Temp);
            else
                Mtx_skbrLength_dsBlobIdx_k_Temp = vertcat(Mtx_skbrLength_dsBlobIdx_k_Temp,...
                    horzcat(skbrLength_um_brCt_Temp,dSBlobIdx_brCt_Temp,kAssign_brCt_Temp));
            end

        end
        clearvars *_brCt_Temp brCt;
        
        % = Sum skbrLength_um values belonging to each dsBlob
        % Note: some dSBlob may not have skeleton branch (too short?)
        [grp_dsBlobIdx_Temp,grpID_dsBlobIdx_Temp] = findgroups(round(Mtx_skbrLength_dsBlobIdx_k_Temp(:,2)));
        skbrLengthSum_um_grp_dSBlobIdx_Temp = splitapply(@sum,Mtx_skbrLength_dsBlobIdx_k_Temp(:,1),grp_dsBlobIdx_Temp);
        
        % = Create 'Img_skbrLengthSumbydSBlob_um_Temp': dsBlob pixels assigned skbrLengthSum_um values
        Img_skbrLengthSumbydSBlob_um_Temp = zeros(size(Img_Lbl_dSBlobIdxMask_Temp),'single'); % total skeleton branch length in each dist source blob (will split into ImgStack by k later)
        for lsCt = 1:numel(skbrLengthSum_um_grp_dSBlobIdx_Temp) % Number of skbrLengthSum
            Img_skbrLengthSumbydSBlob_um_Temp(abs(Img_Lbl_dSBlobIdxMask_Temp-grpID_dsBlobIdx_Temp(lsCt))<eps) = ...
                skbrLengthSum_um_grp_dSBlobIdx_Temp(lsCt);
        end

        % = Split 'Img_skbrLengthSumbydSBlob_um_Temp' into ImgStack by k
        ImgStack_skbrLengthSumbydSBlob_um_Temp = zeros(size(ImgStack_Hist_dSAssignMask_Temp),'single');
        for k=1:size(ImgStack_skbrLength_um_Temp,3)
            ImgStack_skbrLengthSumbydSBlob_um_Temp(:,:,k) = Img_skbrLengthSumbydSBlob_um_Temp.*single(ImgStack_Hist_dSAssignMask_Temp(:,:,k));
        end

        % = Create Img of labels for skbrMask (label = k), for ImgCheck 
        Img_Lbl_skbrMask_Temp = ImgStack_skbrMask_Temp.*permute((1:1:size(ImgStack_skbrMask_Temp,3)),[1 3 2]);
        Img_Lbl_skbrMask_Temp = single(max(Img_Lbl_skbrMask_Temp,[],3));

        clearvars skbrLengthSum_um_grp_dSBlobIdx_Temp Img_skbrLengthSumbydSBlob_um_Temp;
        clearvars grp_dsBlobIdx_Temp grpID_dsBlobIdx_Temp lsCt k;
        
        % === ImgCheck: Colocalize PxAssign, dSAssign and Skeleton Branch
        % (Same for all cases)
        cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
        cmap_Disp_Temp = vertcat(...
            [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
            [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
            [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
            );

        Img_Lbl_PxAssignMask_Disp = label2rgb(Img_Lbl_PxAssignMask_Temp,cmap_Disp_Temp,[0 0 0]);
        Img_Lbl_PxAssignMask_Disp = addborder(Img_Lbl_PxAssignMask_Disp,2,[255 255 255],'inner');

        Img_Lbl_dSAssignMask_Disp = label2rgb(Img_Lbl_dSAssignMask_Temp,cmap_Disp_Temp,[0 0 0]);
        Img_Lbl_dSAssignMask_Disp = addborder(Img_Lbl_dSAssignMask_Disp,2,[255 255 255],'inner');

        Img_Lbl_skbrMask_Disp = label2rgb(Img_Lbl_skbrMask_Temp,cmap_Disp_Temp,[0 0 0]);
        Img_Lbl_skbrMask_Disp = addborder(Img_Lbl_skbrMask_Disp,2,[255 255 255],'inner');

        Img_Disp = horzcat(Img_Lbl_PxAssignMask_Disp,Img_Lbl_dSAssignMask_Disp,Img_Lbl_skbrMask_Disp);
        ImgCheck_ShapeDHist_Cell_Out{dtsCt,ColIdx_ImgCheck_Out_Temp(1,1),qCt} = Img_Disp;
        
        clearvars *Disp*;

               
        % === Case 1.1) *Skeleton branch length* as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to 1 HistBin_D
        % === Case 1.2) *Skeleton branch length* as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to multiple HistBin_D

        % == Distance HistBins of each Skeleton Branch
        ImgStack_gDist_skbr_um_Temp = nan(size(ImgStack_Hist_dSAssignMask_Temp),'single'); % allow for zero distance

        for csCt = 1:2 % Case 1.1), 1.2)

            for k=1:(3*NumDistT_Mtx(dtsCt,1))

                if csCt == 1 % Case 1.1); determine mean distance for each skel branch

                    rp_skbr_D_Temp = ... % PixelValues = gDist from distance-target (um)
                        regionprops(ImgStack_skbrMask_Temp(:,:,k),ImgStack_gDist_um_Temp(:,:,k),'Area','PixelValues','PixelIdxList');
                    Img_k_Temp = nan(height(ImgStack_gDist_skbr_um_Temp),width(ImgStack_gDist_skbr_um_Temp),'single');
                    for brCt = 1:height(rp_skbr_D_Temp)
                        % for brCt = 1419:1419

                        Img_skbrMask_brCt_Temp = zeros(size(Img_skbr_Temp),'logical');
                        Img_skbrMask_brCt_Temp(rp_skbr_D_Temp(brCt).PixelIdxList) = 1; % Mask of skeleton branch
                        Img_k_Temp(rp_skbr_D_Temp(brCt).PixelIdxList) = 0; % Set skeleton branch pixels from nan to 0 (so addition will work later)

                        gDist_brCt_Temp = rp_skbr_D_Temp(brCt).PixelValues;
                        gDist_brCt_Temp(isnan(gDist_brCt_Temp) | isinf(gDist_brCt_Temp)) = [];
                        gDist_brCt_Temp = mean(gDist_brCt_Temp,"all");

                        Img_k_Temp = Img_k_Temp + single(Img_skbrMask_brCt_Temp).*gDist_brCt_Temp;
                    end

                    ImgStack_gDist_skbr_um_Temp(:,:,k) = Img_k_Temp;

                elseif csCt == 2 % Case 1.2); each pixel in each skel branch retains its own distance to distance target

                    Img_k_Temp = single(ImgStack_skbrMask_Temp(:,:,k)).*ImgStack_gDist_um_Temp(:,:,k);
                    Img_k_Temp(~ImgStack_skbrMask_Temp(:,:,k)) = NaN;
                    ImgStack_gDist_skbr_um_Temp(:,:,k) = Img_k_Temp;

                end

            end

            clearvars rp_skbr_D_Temp Img_skbrMask_brCt_Temp gDist_brCt_Temp Img_k_Temp brCt k;

            % == Assign skbr pixels to HistBins of distance to distance-targets
            % 'HistData_skbrPxbyD_Cell_Temp': cell of 1 row, 2 columns, k depth
            % 2 columns for:
            % * Col01: HistCt (number of elements = numel(HistEdge_D_Temp)-1)
            % * Col02: HistBin (size of image; each skbr pixel labelled by HistBin)
            % 'Mtx_skbrLengthbykbyD_um_Temp', matrix of # skeleton-branch-pixels
            % rows, 3 columns:
            % * Col01: k (which distance target the skeleton branch is assigned to)
            % * Col02: HistBin_D (which HistBin_D, of distance to distance target, the skeleton branch is assigned to
            % * Col03: skeleton branch length, in um (1 value for each pixel assigned the length)
            HistData_skbrPxbyD_Cell_Temp = cell(1,2,size(ImgStack_skbrLength_um_Temp,3));
            Mtx_skbrLengthbykbyD_um_Temp = []; % Hold all skeleton branch length (um) for boxplots

            for k=1:(3*NumDistT_Mtx(dtsCt,1))

                Img_gD_k_Temp = ImgStack_gDist_skbr_um_Temp(:,:,k);
                Img_gD_k_Temp(isnan(Img_gD_k_Temp)) = -9.999; % outside HistEdge_D_Temp
                [HistCt_gDist_skbr_Temp,~,HistBin_gDist_skbr_Temp] = histcounts(Img_gD_k_Temp,HistEdge_D_Temp);

                Img_skbrL_k_Temp = ImgStack_skbrLength_um_Temp(:,:,k);
                for hbCt = 1:(numel(HistEdge_D_Temp)-1) % HistBin
                    skbrL_k_hb_Temp = Img_skbrL_k_Temp(abs(HistBin_gDist_skbr_Temp-hbCt)<eps);
                    skbrL_k_hb_Temp = horzcat(...
                        repelem(single(k),height(skbrL_k_hb_Temp),1),... % which k
                        repelem(single(hbCt),height(skbrL_k_hb_Temp),1),... % which HistBin_D in HistEdge_D_Temp
                        skbrL_k_hb_Temp); % skeleton branch length (um) in this k and HistBin_D
                    Mtx_skbrLengthbykbyD_um_Temp = vertcat(...
                        Mtx_skbrLengthbykbyD_um_Temp,...
                        skbrL_k_hb_Temp);
                end

                HistData_skbrPxbyD_Cell_Temp{1,1,k} = single(HistCt_gDist_skbr_Temp);
                HistData_skbrPxbyD_Cell_Temp{1,2,k} = single(HistBin_gDist_skbr_Temp);

            end

            clearvars HistCt_gDist_skbr_Temp HistBin_gDist_skbr_Temp Img_skbrL_k_Temp Img_gD_k_Temp skbrL_k_hb_Temp k hbCt;

            % == 20250405: yBox_Tbl (2D table for export into csv)
            % 3 Columns: [k HistBin Row01Val]
            DataExp_skbrLengthbykbyD_um_Temp = array2table(Mtx_skbrLengthbykbyD_um_Temp,'VariableNames',{'k','HistBin','yval'});

            % ==  Store in Output
            HistData_Save_Temp = struct;
            HistData_Save_Temp.HistData.HistName = strcat(HistName_Case_Temp(csCt),"_dtSet",num2str(dtsCt,'%02d'),"_q",num2str(qCt,'%02d'));
            HistData_Save_Temp.HistData.HistEdge_D = HistEdge_D_Temp;
            HistData_Save_Temp.HistData.HistBinLbl_D = HistBinLbl_D_Temp;
            HistData_Save_Temp.HistData.HistCt = HistData_skbrPxbyD_Cell_Temp; % HistCt & HistBin Data, not directly plotted
            HistData_Save_Temp.HistData.yBox = Mtx_skbrLengthbykbyD_um_Temp; % Plot Data for BoxPlot; [k HistBin yval]
            HistData_Save_Temp.HistData.yBox_Tbl = DataExp_skbrLengthbykbyD_um_Temp; % [k HistBin yval], with column name
            HistData_Save_Temp.HistData.Img_Lbl_PxAssignMask = single(Img_Lbl_PxAssignMask_Temp); % pixels, labeled w/ k (same for all cases)
            HistData_Save_Temp.HistData.Img_Lbl_dSAssignMask = single(Img_Lbl_dSAssignMask_Temp); % dSBlob, labeled w/ k (same for all cases)
            HistData_Save_Temp.HistData.Img_Lbl_skbrMask = single(Img_Lbl_skbrMask_Temp); % skeleton branch, labeled w/ k (same for all cases)
            HistData_Save_Temp.HistData.HistyLbl = "SkBrLength_um"; % y label of histogram
            HistData_Save_Temp.HistData.NumDistT = NumDistT_Temp; % OCN, TRAP etc; 1 for bone front
            HistData_Save_Temp.HistData.k_Str = Str_Temp;

            PlotData_ShapeDHist_Cell_Out{RowIdx_Temp,ColIdx_Out_Temp(1,csCt),qCt} = HistData_Save_Temp;

            clearvars HistData_skbrPxbyD_Cell_Temp Mtx_skbrLengthbykbyD_um_Temp k csCt;

        end


        % === Case 1.3) *Sum of Skeleton branch length in dSBlob* as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to 1 HistBin_D
        % === Case 1.4) *Sum of Skeleton branch length in dSBlob* as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to 1 HistBin_D
        % === Case 1.5) *Sum of Skeleton branch length in dSBlob* as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to multiple HistBin_D
        % === Case 1.6) *Sum of Skeleton branch length in dSBlob* as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to multiple HistBin_D

        for csCt = 3:6 % Case 1.3-1.6

            % == Distance HistBins of each dist-source blob containing skeleton
            % (A v. small number of dSBlob may have no skeleton if very short)
            ImgStack_gDist_skbrLS_um_Temp = nan(size(ImgStack_Hist_dSAssignMask_Temp),'single'); % allow for zero distance

            for k=1:(3*NumDistT_Mtx(dtsCt,1))

                Img_skbrLS_k_Temp = ImgStack_skbrLengthSumbydSBlob_um_Temp(:,:,k);
                if rem(csCt,2)==1 % Case 1.3), Case 1.5): Reduce analysis area to skeleton branch pixels only
                    Img_skbrLS_k_Temp = Img_skbrLS_k_Temp.*single(ImgStack_skbrMask_Temp(:,:,k)); % Restrict to Skeleton Branch Pixels Only
                end
                Img_skbrLS_k_Temp(isnan(Img_skbrLS_k_Temp)) = 0; % logical() next step

                if csCt==3 | csCt==4 % Case 1.3), Case 1.4): Each dSBlob w/ 1 HistD Value

                    rp_skbrLS_D_Temp = ... % PixelValues = gDist from distance-target (um)
                        regionprops(logical(Img_skbrLS_k_Temp),ImgStack_gDist_um_Temp(:,:,k),'Area','PixelValues','PixelIdxList');

                    Img_k_Temp = nan(height(ImgStack_gDist_skbrLS_um_Temp),width(ImgStack_gDist_skbrLS_um_Temp),'single');
                    for bCt = 1:height(rp_skbrLS_D_Temp) % dsBlob (w/ skeleton) count
                        % for brCt = 1419:1419

                        Img_blobMask_bCt_Temp = zeros(size(Img_skbrLS_k_Temp),'logical');
                        Img_blobMask_bCt_Temp(rp_skbrLS_D_Temp(bCt).PixelIdxList) = 1; % Mask of dSBlob containing skeleton
                        Img_k_Temp(rp_skbrLS_D_Temp(bCt).PixelIdxList) = 0; % Set blob pixels from nan to 0 (so addition will work later)

                        gDist_bCt_Temp = rp_skbrLS_D_Temp(bCt).PixelValues; % in um
                        gDist_bCt_Temp(isnan(gDist_bCt_Temp) | isinf(gDist_bCt_Temp)) = [];
                        gDist_bCt_Temp = mean(gDist_bCt_Temp,"all");

                        Img_k_Temp = Img_k_Temp + single(Img_blobMask_bCt_Temp).*gDist_bCt_Temp;

                    end

                    ImgStack_gDist_skbrLS_um_Temp(:,:,k) = Img_k_Temp;

                elseif csCt==5 | csCt==6 % Case 1.5), Case 1.6): Each dSBlob w/ multiple HistD Value

                    Img_k_Temp = single(logical(Img_skbrLS_k_Temp)) .* ImgStack_gDist_um_Temp(:,:,k);
                    Img_k_Temp(~logical(Img_skbrLS_k_Temp)) = NaN;
                    ImgStack_gDist_skbrLS_um_Temp(:,:,k) = Img_k_Temp;

                end

            end

            clearvars Img_skbrLS_k_Temp gDist_bCt_Temp Img_k_Temp Img_blobMask_bCt_Temp brCt k;

            % == Assign dSBlob pixels to HistBins of distance to distance-targets
            % 'HistData_skbrLengthSum_bydSBlobbykbyD_Cell_Temp': cell of 1 row, 2 columns, k depth
            % 2 columns for:
            % * Col01: HistCt (number of elements = numel(HistEdge_D_Temp)-1)
            % * Col02: HistBin (size of image; each skbr pixel labelled by HistBin)
            % 'Mtx_skbrLengthSum_bydSBlobbykbyD_um_Temp', matrix of # dSBlob (containing skeleton) pixels
            % rows, 3 columns:
            % * Col01: k (which distance target the skeleton branch is assigned to)
            % * Col02: HistBin_D (which HistBin_D, of distance to distance target, the skeleton branch is assigned to
            % * Col03: skeleton branch length, in um (1 value for each pixel assigned the length)
            HistData_skbrLengthSum_bydSBlobbykbyD_Cell_Temp = cell(1,2,size(ImgStack_skbrLength_um_Temp,3));
            Mtx_skbrLengthSum_bydSBlobbykbyD_um_Temp = []; % Hold all skeleton branch length sum (um) for boxplots

            for k=1:(3*NumDistT_Mtx(dtsCt,1))

                Img_gD_k_Temp = ImgStack_gDist_skbrLS_um_Temp(:,:,k); % Distance to Distance Target
                if rem(csCt,2)==1 % Case 1.3), Case 1.5): Reduce analysis area to skeleton branch pixels only
                    Img_gD_k_Temp = Img_gD_k_Temp.*single(ImgStack_skbrMask_Temp(:,:,k)); % Restrict to Skeleton Branch Pixels Only
                end
                Img_gD_k_Temp(isnan(Img_gD_k_Temp)) = -9.999; % outside HistEdge_D_Temp
                [HistCt_gDist_skbrLS_Temp,~,HistBin_gDist_skbrLS_Temp] = histcounts(Img_gD_k_Temp,HistEdge_D_Temp);

                Img_skbrLS_k_Temp = ImgStack_skbrLengthSumbydSBlob_um_Temp(:,:,k); % Skeleton Branch Length Sum
                 if rem(csCt,2)==1 % Case 1.3), Case 1.5): Reduce analysis area to skeleton branch pixels only
                    Img_skbrLS_k_Temp = Img_skbrLS_k_Temp.*single(ImgStack_skbrMask_Temp(:,:,k)); % Restrict to Skeleton Branch Pixels Only
                end
                for hbCt = 1:(numel(HistEdge_D_Temp)-1) % HistBin
                    skbrLS_k_hb_Temp = Img_skbrLS_k_Temp(abs(HistBin_gDist_skbrLS_Temp-hbCt)<eps);
                    skbrLS_k_hb_Temp = horzcat(...
                        repelem(single(k),height(skbrLS_k_hb_Temp),1),... % which k
                        repelem(single(hbCt),height(skbrLS_k_hb_Temp),1),... % which HistBin_D in HistEdge_D_Temp
                        skbrLS_k_hb_Temp); % skeleton branch length sum (um) in this k and HistBin_D
                    Mtx_skbrLengthSum_bydSBlobbykbyD_um_Temp = vertcat(...
                        Mtx_skbrLengthSum_bydSBlobbykbyD_um_Temp,...
                        skbrLS_k_hb_Temp);
                end

                HistData_skbrLengthSum_bydSBlobbykbyD_Cell_Temp{1,1,k} = single(HistCt_gDist_skbrLS_Temp);
                HistData_skbrLengthSum_bydSBlobbykbyD_Cell_Temp{1,2,k} = single(HistBin_gDist_skbrLS_Temp);

            end

            clearvars HistCt_gDist_skbrLS_Temp HistBin_gDist_skbrLS_Temp Img_gD_k_Temp Img_skbrLS_k_Temp skbrLS_k_hb_Temp hbCt k;

            % == 20250405: yBox_Tbl (2D table for export into csv)
            % 3 Columns: [k HistBin Row01Val]
            DataExp_skbrLengthSum_bydSBlobbykbyD_um_Temp = array2table(Mtx_skbrLengthSum_bydSBlobbykbyD_um_Temp,'VariableNames',{'k','HistBin','yval'});

            % ==  Store in Output
            HistData_Save_Temp = struct;
            HistData_Save_Temp.HistData.HistName = strcat(HistName_Case_Temp(csCt),"_dtSet",num2str(dtsCt,'%02d'),"_q",num2str(qCt,'%02d'));
            HistData_Save_Temp.HistData.HistEdge_D = HistEdge_D_Temp;
            HistData_Save_Temp.HistData.HistBinLbl_D = HistBinLbl_D_Temp;
            HistData_Save_Temp.HistData.HistCt = HistData_skbrLengthSum_bydSBlobbykbyD_Cell_Temp; % HistCt & HistBin Data, not directly plotted
            HistData_Save_Temp.HistData.yBox = Mtx_skbrLengthSum_bydSBlobbykbyD_um_Temp; % Plot Data for BoxPlot: which k, which HistBin_D, skeleton branch length sum (um) for the k and HistBin_D
            HistData_Save_Temp.HistData.yBox_Tbl = DataExp_skbrLengthSum_bydSBlobbykbyD_um_Temp; % [k HistBin yval], w/ column names
            HistData_Save_Temp.HistData.Img_Lbl_PxAssignMask = single(Img_Lbl_PxAssignMask_Temp); % pixels, labeled w/ k (same for all cases)
            HistData_Save_Temp.HistData.Img_Lbl_dSAssignMask = single(Img_Lbl_dSAssignMask_Temp); % dSBlob, labeled w/ k (same for all cases)
            HistData_Save_Temp.HistData.Img_Lbl_skbrMask = single(Img_Lbl_skbrMask_Temp); % skeleton branch, labeled w/ k (same for all cases)
            HistData_Save_Temp.HistData.HistyLbl = "SkBrLengthSum_um"; % y label of histogram
            HistData_Save_Temp.HistData.NumDistT = NumDistT_Temp; % OCN, TRAP etc; 1 for bone front
            HistData_Save_Temp.HistData.k_Str = Str_Temp;

            PlotData_ShapeDHist_Cell_Out{RowIdx_Temp,ColIdx_Out_Temp(1,csCt),qCt} = HistData_Save_Temp; % Case 1.3-1.6

            clearvars HistData_skbrLengthSum_bydSBlobbykbyD_Cell_Temp Mtx_skbrLengthSum_bydSBlobbykbyD_um_Temp

        end

    end

end

clearvars *_Temp dstCt brCt csCt k; 


%% Plot skeleton branch length histogram from Mtx_skbrLengthbykbyD_um_Temp data

close all;

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % === Define colormap for plotting all histograms
    cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
    cmap_Disp_Temp = vertcat(...
        [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
        [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
        [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
        );

    % === Specify HistData to plot
    ColIdx_PlotInOut_Temp = [2:7];

    for csCt = 1:width(ColIdx_PlotInOut_Temp) % number of histograms

        for qCt = 1:Numq

            HistData_Temp = PlotData_ShapeDHist_Cell_Out{RowIdx_Temp,ColIdx_PlotInOut_Temp(csCt),qCt}.HistData;

            % == Plot box chart: Figure 01a: All k, All k's ymax

            % == y-axis upper limit
            ymax_wrapper = @(x) prctile(x,75)+1.5*iqr(x);
            [ygrp_Temp,ygrpID_k_Temp,ygrpID_HistBin_Temp] = findgroups(HistData_Temp.yBox(:,1),HistData_Temp.yBox(:,2));
            ymax_Temp = min(splitapply(ymax_wrapper,HistData_Temp.yBox(:,3),ygrp_Temp), splitapply(@max,HistData_Temp.yBox(:,3),ygrp_Temp)); % either upper box whisker val or largest ymax of each k and HistBin_D combo
            ymax_Temp = max(ymax_Temp,[],'all');

            FigHandle01a = figure('Position',[25 150 1200 300*NumDistT_Temp],'visible','off','PaperPositionMode','auto'); % [left bottom width height]
            tlo = tiledlayout(NumDistT_Temp,3,'TileSpacing','Compact','Padding','tight','TileIndexing', 'columnmajor'); % tile layout; replace subplot(); 3 Col for Beg, Bdc, Btb
            set(gcf,'color','white');

            for k=1:(3*NumDistT_Mtx(dtsCt,1))
                % for k=1:1

                ax = nexttile(tlo);
                hold(ax, 'on'); grid off;

                mtx_k_Temp = HistData_Temp.yBox(abs(HistData_Temp.yBox(:,1)-k)<eps,:);

                xgrp_k_Temp = categorical(HistData_Temp.HistBinLbl_D,HistData_Temp.HistBinLbl_D,'Ordinal',true)';
                xgrp_k_Temp = xgrp_k_Temp(mtx_k_Temp(:,2));
                y_k_Temp = mtx_k_Temp(:,3);

                boxchart(xgrp_k_Temp,y_k_Temp,...
                    'BoxFaceColor',cmap_Disp_Temp(k,:), 'BoxFaceAlpha',0.5,'BoxEdgeColor',[0 0 0],'LineWidth',2,'MarkerColor',cmap_Disp_Temp(k,:));

                ylim([0 ymax_Temp]);

                xlabel('Distance to Target (um)','interpreter','none');
                ylabel(HistData_Temp.HistyLbl,'interpreter','none');

                fontname('Arial'); fontsize(16,'points'); set(gca,'FontWeight','bold');

            end

            sgtitle(HistData_Temp.HistName,'interpreter','none','FontName','Arial','FontSize',12,'FontWeight','bold');

            % = Prepare display, also store as plot output
            iptsetpref("ImshowBorder","tight"); % remove borders; do before export_fig

            Img_Fig01a_Temp =  export_fig(FigHandle01a,'-r150');
            Img_Fig01a_Temp = imresize(Img_Fig01a_Temp,[round(1.5*300*NumDistT_Temp) NaN]); % Proportional to height of FigHandle

            % % % figure; imshow(Img_Fig01a_Temp);

            Plot_ShapeDHist_Cell_Out{dtsCt,ColIdx_PlotInOut_Temp(csCt),qCt} = Img_Fig01a_Temp;

            close all;
            clearvars FigHandle* ax tlo;

        end

        clearvars y*Temp x*Temp mtx_k_Temp k;

    end

end

clearvars *Temp *Disp *Ct;


