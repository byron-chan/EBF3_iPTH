% 20250313: fPlotAreaDHistEbf3() prepares data and histogram of occupancy
% (area) of distance-source blobs (Ebf3) vs distance to their assigned different distance
% targets @ different bone fronts (Beg, Bdc, Btb)

% Change name from fPlotAreavsDistEbf3 to fPlotAreaDHistEbf3

function [PlotData_AreaDHist_Cell_Out,Plot_AreaDHist_Cell_Out,ImgCheck_AreaDHist_Cell_Out] = ...
    fPlotAreaDHistEbf3(Img_MrwDef_Cell_In,Img_DistS_Cell_In,Img_DistT_Cell_In,Img_Btb_Cell_In,Img_gDistMap_Cell_In,Img_dSAssignAdj_Cell_In,Tbl_dSAssignAdj_Cell_In,UI_In);

%% Prepare Output Cells

% 3 Cases of describing occupancy of Distance-Source (Ebf3)
% Case 1): "Hist_dSPxbyD"
% Multi dist for each dSBlob
% Case 2.1): "Hist_dSPxbyD_Blob"
% 1 dist for each dSBlob x # px in blob
% Case 2.2): "Hist_dSUtbyD_Blob"
% 1 dist for each dSBlob x # dSUt in blob

% = PlotData_AreaDHist_Cell

PlotData_AreaDHist_Cell_Out = cell(4,4,2);

% Plot data from adjusted (final) assignment of distance-source blobs to different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = class "structure", distance source unit (dSUt) area statistics  (Row 3,4)
% * Col02 = class "structure", Case 1) histogram data, dist-source blob pixel distance from nearest dist-target (HistVal = multiple dist val for each dSBlob) (Row 3,4)
% * Col03 = class "structure", Case 2.1) histogram data, dist-source blob pixel distance from nearest dist-target (HistVal = 1 dist val for each dSBlob x # pixels in blob) (Row 3,4)
% * Col04 = class "structure", Case 2.2) histogram data, dist-source blob pixel distance from nearest dist-target (HistVal = 1 dist val for each dSBlob x # dSUt in blob) (Row 3,4)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)

% = Plot_AreaDHist_Cell

Plot_AreaDHist_Cell_Out = cell(2,4,2);

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = Area statistics (Box Plot), distance source unit (dSUt) area
% * Col02 = Case 1) Histogram
% * Col03 = Case 2.1) Histogram
% * Col04 = Case 2.2)  Histogram

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = ImgCheck_AreaDHist_Cell_Out

ImgCheck_AreaDHist_Cell_Out = cell(2,2,2);

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Colocalized Img, dist-source blobs for measuring dSUt properties (Row 3,4; Z 1)
% * Col02 = Label Img (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), pixels and dist-source blobs used in histogram
% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


%%

% % % NumDistT = size(Img_gDistMap_Cell_In{3,1},3); % Number of distance target (OCN, TRAP etc)
% % % NumDistTbf = size(Img_gDistMap_Cell_In{4,1},3); % Number of "hypothetical" bone front staining = 1
NumDistT_Mtx = [...
    size(Img_gDistMap_Cell_In{3,1},3); ... % Number of distance target (OCN, TRAP etc); = NumDistT (Row 3)
    size(Img_gDistMap_Cell_In{4,1},3)... % Number of "hypothetical" bone front staining = 1 = NumDistTbf (Row 4)
    ];

% = Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)
Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;

% = Quality of Assignment: Ignore only vs Ignore+Consider
if UI_In.dSAssignQOption==[1 0]
    Numq = 1;
elseif UI_In.dSAssignQOption==[1 1]
    Numq = 2;
end


%%  ===== dSUt properties

%% Estimate size of dist-source blob unit (dSUt)
% * 'dSUt' is used to approximate the size of a distance-source cell, 1 or many of which makes
% up a distance-source blob
% (Should have equal results from Row3,4)
% (Quality of assignment score irrelevant; use q01 (ignore) only)

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Create 'dataTbl_Cell_Temp': z-cell of all dataTbl describing properties
    % of dSBlobs assigned to each k
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT
    dataTbl_Cell_Temp = cat(3,Tbl_dSAssignAdj_Cell_In{RowIdx_Temp,1,1},Tbl_dSAssignAdj_Cell_In{RowIdx_Temp,2,1},Tbl_dSAssignAdj_Cell_In{RowIdx_Temp,3,1});

    % = Select dSBlobs for estimating the area of dSUt
    % dS Blob far away from bone (ie, large distance) likely made of 1
    % unit (~ individual Ebf3 cell); while those close to bone made of
    % multiple units (~ multiple Ebf3 cells)
    % * Estimate 'dSUt' area from blobs > x*Ebf3Sz_ulim_px away from
    % any distance target (@ Beg, Bdc, Btb), and also not near any bone front,
    % combine data from all k to draw summary statistics

    ImgCheck_dS_Temp = zeros(size(Img_DistS_Cell_In{2,5}),'logical'); % Img of all dSBlobs, drawn from dataTbl
    ImgCheck_dSUt_Temp = zeros(size(Img_DistS_Cell_In{2,5}),'logical'); % Img of dSBlobs used for dSUt measurement
    for k=1:size(dataTbl_Cell_Temp,3)

        dataTbl_k_Temp = dataTbl_Cell_Temp{1,1,k};

        if ~isempty(dataTbl_k_Temp) % 20250801: dsAssignMask has blobs assigned to k

            dataTbl_k_Temp(isnan(dataTbl_k_Temp.PixelValues_D) | isinf(dataTbl_k_Temp.PixelValues_D),:) = []; % Should have no deletion here, but safeguard

            % = Flag for removal: dSBlobs with any pixel near bone front (Beg, Bdc, Btb)
            FlagID_Begdctb_ColocalbyBlobIdx_k_Temp  = ...
                splitapply(@any,ismember(dataTbl_k_Temp.PixelIdxList,...
                find(Img_DistT_Cell_In{1,1} | ... % Beg region (already imdilate thickened 3.0*Ebf3Sz_ulim_px from bone front line)
                Img_DistT_Cell_In{1,2}|... % Bdc region (already imdilate thickened 3.0*Ebf3Sz_ulim_px from bone front line)
                imdilate(Img_DistT_Cell_In{1,3},strel('disk',round(3.0*Ebf3Sz_ulim_px))))),... % Btb
                dataTbl_k_Temp.BlobIdx);

            % = Flag for removal: dSBlobs < 8.0*Ebf3Sz_ulim_px away from any distance targets
            PixelValues_D_MinbyBlobIdx_k_Temp = splitapply(@min,dataTbl_k_Temp.PixelValues_D,dataTbl_k_Temp.BlobIdx); % distance unit: px
            FlagID_PixelValues_D_MinbyBlobIdx_k_Temp = PixelValues_D_MinbyBlobIdx_k_Temp<(8.0*Ebf3Sz_ulim_px);

            % = Count pixels in each dSBlob (= measure area of each dSBlob), remove dSBlobs flagged
            NumPx_Blob_k_Temp = splitapply(@numel,dataTbl_k_Temp.PixelValues_D,dataTbl_k_Temp.BlobIdx); % distance-blob area

            FlagID_k_Temp = FlagID_Begdctb_ColocalbyBlobIdx_k_Temp | FlagID_PixelValues_D_MinbyBlobIdx_k_Temp;
            NumPx_Blob_k_Temp(FlagID_k_Temp) = [];

            % = Add kept dSBlobs for this k to ImgCheck_dSUt_Temp
            ImgCheck_dS_Temp(dataTbl_k_Temp.PixelIdxList) = 1;
            dataTbl_k_Temp(ismember(dataTbl_k_Temp.BlobIdx,find(FlagID_k_Temp)),:) = [];
            ImgCheck_dSUt_Temp(dataTbl_k_Temp.PixelIdxList) = 1;

            if k<2
                NumPxbyBlobIdx_Temp = NumPx_Blob_k_Temp; % Will hold NumPxbyBlobIdx of all k
            else
                NumPxbyBlobIdx_Temp = vertcat(NumPxbyBlobIdx_Temp,NumPx_Blob_k_Temp);
            end

        end

    end

    % = Calculate statistics of NumPxbyBlobIdx (= area of dSBlobs chosen to estimate dSUt)
    dSUt_Temp = struct;
    dSUt_Temp.dSUt.Area.Data_px = NumPxbyBlobIdx_Temp;
    dSUt_Temp.dSUt.Area.Data_um = dSUt_Temp.dSUt.Area.Data_px.*(UI_In.XY_PxLength_umpx)^2;
    dSUt_Temp.dSUt.Area.Mean_px = mean(NumPxbyBlobIdx_Temp,1,'omitmissing');
    dSUt_Temp.dSUt.Area.Mean_um = dSUt_Temp.dSUt.Area.Mean_px.*(UI_In.XY_PxLength_umpx)^2;
    dSUt_Temp.dSUt.Area.Stdev_px = std(NumPxbyBlobIdx_Temp,0,1,'omitmissing');
    dSUt_Temp.dSUt.Area.Stdev_um = dSUt_Temp.dSUt.Area.Stdev_px.*(UI_In.XY_PxLength_umpx)^2;
    dSUt_Temp.dSUt.Area.Median_px = median(NumPxbyBlobIdx_Temp,1,'omitmissing');
    dSUt_Temp.dSUt.Area.Median_um = dSUt_Temp.dSUt.Area.Median_px.*(UI_In.XY_PxLength_umpx)^2;
    dSUt_Temp.dSUt.Area.Prctile5_25_75_95px = prctile(NumPxbyBlobIdx_Temp,[5 25 75 95]);
    dSUt_Temp.dSUt.Area.Prctile5_25_75_95um = dSUt_Temp.dSUt.Area.Prctile5_25_75_95px.*(UI_In.XY_PxLength_umpx)^2;
    [~,dSUt_Temp.dSUt.Area.Outlier_llim_px,dSUt_Temp.dSUt.Area.Outlier_ulim_px,~] = isoutlier(NumPxbyBlobIdx_Temp,'quartiles');

    % = Prepare Display & ImgCheck Image
    Img_dSUt_Disp = horzcat(...
        addborder(uint8(255.*repmat(ImgCheck_dS_Temp,1,1,3)),2,[255 255 255],'inner'),...
        addborder(uint8(255.*repmat(ImgCheck_dSUt_Temp,1,1,3)),2,[255 255 255],'inner'),...
        addborder(imfuse(ImgCheck_dS_Temp,ImgCheck_dSUt_Temp,'Scaling','none','ColorChannels',[1 2 0]),2,[255 255 255],'inner'));
    Img_dSUt_Disp = imresize(Img_dSUt_Disp,[800 NaN]);
    % % % figure; imshow(Img_dSUt_Disp);

    % = Store as output
    PlotData_AreaDHist_Cell_Out{RowIdx_Temp,1} = dSUt_Temp;
    ImgCheck_AreaDHist_Cell_Out{dtsCt,1,1} = Img_dSUt_Disp;

end

close all;
clearvars *_Temp *_Disp;


%% Box Plot: dSUt Area statistics

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    close all; clearvars FigHandle* tlo ax;
    FigHandle01 = figure('Position',[50 200 400 500],'visible','off','PaperPositionMode','auto');
    tlo = tiledlayout(1,2,'TileSpacing','Compact','Padding','tight');
    set(gcf,'Color','white');

    ax = nexttile(tlo);
    hold(ax, 'on');
    boxchart(PlotData_AreaDHist_Cell_Out{RowIdx_Temp,1}.dSUt.Area.Data_um);
    ylabel('Est Area, dSUt (um2)','interpreter','none');
    ylim([0 pi*10^2]); % area of 0-10um circle

    fontname('Arial');
    fontsize(12,'points');
    set(gca,'FontWeight','bold');

    ax = nexttile(tlo);
    hold(ax, 'on');
    boxchart(2.0*sqrt(PlotData_AreaDHist_Cell_Out{RowIdx_Temp,1}.dSUt.Area.Data_um/pi));
    ylabel('Est Equiv Diameter, dSUt (um)','interpreter','none');
    ylim([0 20]);

    fontname('Arial');
    fontsize(12,'points');
    set(gca,'FontWeight','bold');

    % = Store as output
    Plot_AreaDHist_Cell_Out{dtsCt,1} = export_fig(FigHandle01,'-r150');

end

close all;
clearvars *_Temp k qCt FigHandle* tlo ax;


%%  ===== Histograms

%% Prepare Histogram Data

% =  Logical Mask, pixels excluded from PxAssign Histogram
% Use mask of Non-trabecular bone marrow holes that are likely tears from biopsy preparations
% These pixels are excluded from histogram preparations as dist-source
% blobs cannot sit on these pixels
% (Will = ImgCheck_AreaDHist_Cell{dtsCt,2})

Img_PxHistExclude_Mask_Temp = Img_DistS_Cell_In{1,6};

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Preparations for all k and qCt
    % "ColIdx_In_Temp' specifies the column Idx of where data needed is stored in
    % "Img_dSAssignAdj_Cell". Row for Px vs dS; column for Beg vs Bdc vs Btb, z
    % for ignore quality score vs consider quality score
    % % % ColIdx_In_Temp = cat(3,[3 4 5; 23 24 25],[6 7 8; 26 27 28]);
    ColIdx_In_Temp = [3 4 5; 23 24 25];

    % "ColIdx_Out_Temp' specifies the column Idx of where hist data is stored in
    % "PlotData_dSAsnAdj_Cell_Out". 1 Row; Column for:
    % Case 1) (multi dist for each dSBlob)
    % Case 2.1) (1 dist for each dSBlob x # px in blob)
    % Case 2.2) (1 dist for each dSBlob x # dSUt in blob)
    % z for ignore quality score vs consider quality score
    % % % ColIdx_Out_Temp = cat(3,[2 4 6],[3 5 7]);
    ColIdx_Out_Temp = [2 3 4];

    % Create string labels for each k for saving with histogram data
    Str_B_Temp = ["Beg";"Bdc";"Btb"];
    Str_dT_Temp = (1:1:NumDistT_Temp)'; % must be column vector
    Str_dT_Temp = strcat("DistT",num2str(Str_dT_Temp,'%02d'));
    Str_Temp = table2array(combinations(Str_B_Temp,Str_dT_Temp)); % string array; size (kx2)

    for qCt = 1:Numq % ignore vs consider quality of assignment score

        % = Create for Histogram creation, for each qCt:
        % i) ImgStack_Hist_PxAssignMask_Temp (logical): z-stack of all
        % assignment-of-pixel masks to be used for histogram; remove pixels
        % that are not trabecular bone but tears in biopsy or without k
        % assignment due to geodesic distance measurement inaccessbility
        % ii) ImgStack_Hist_dSAssignMask_Temp (logical): z-stack of all assignment-of-distSblob masks
        % iii) ImgStack_gDist_um_Temp (single): z-stack of all DIstMap; *convert to um*
        % Beg: k =  1:NumDistT
        % Bdc: k = (NumDistT+1):2*NumDistT
        % Btb: k = (2*NumDistT+1):3*NumDistT
        ImgStack_Hist_PxAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_In(RowIdx_Temp,ColIdx_In_Temp(1,:),qCt),[1 3 2])); % i)
        ImgStack_Hist_PxAssignMask_Temp = ImgStack_Hist_PxAssignMask_Temp & ... % 20250318: exclude non-trabecular marrow hole pixels that are tears in biopsy prep or without k assignment
            repmat(~Img_PxHistExclude_Mask_Temp,1,1,size(ImgStack_Hist_PxAssignMask_Temp,3));
        ImgStack_Hist_dSAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_In(RowIdx_Temp,ColIdx_In_Temp(2,:),qCt),[1 3 2])); % ii)
        ImgStack_gDist_um_Temp = UI_In.XY_PxLength_umpx.*cell2mat(permute(Img_gDistMap_Cell_In(RowIdx_Temp,1:3),[1 3 2])); % iii)

        % = Extract dataTbl for all k, also define qstr for histogram name
        dataTbl_Cell_Temp = cat(3,Tbl_dSAssignAdj_Cell_In{RowIdx_Temp,1,qCt},Tbl_dSAssignAdj_Cell_In{RowIdx_Temp,2,qCt},Tbl_dSAssignAdj_Cell_In{RowIdx_Temp,3,qCt});

        % = Define Histogram Edge & Bin Label for Distance (um)
        HistEdgeMax_Px_D_Temp = ImgStack_gDist_um_Temp.*single(ImgStack_Hist_PxAssignMask_Temp);
        HistEdgeMax_Px_D_Temp(isnan(HistEdgeMax_Px_D_Temp) | isinf(HistEdgeMax_Px_D_Temp)) = -9.99; % Exclude from max distance comparison
        HistEdgeMax_Px_D_Temp = max(HistEdgeMax_Px_D_Temp,[],3);
        HistEdgeMax_dS_D_Temp = ImgStack_gDist_um_Temp.*single(ImgStack_Hist_dSAssignMask_Temp);
        HistEdgeMax_dS_D_Temp(isnan(HistEdgeMax_dS_D_Temp) | isinf(HistEdgeMax_dS_D_Temp)) = -9.99; % Exclude from max distance comparison
        HistEdgeMax_dS_D_Temp = max(HistEdgeMax_dS_D_Temp,[],3);
        HistEdgeMax_D_Temp = max(max(HistEdgeMax_Px_D_Temp,[],'all'),max(HistEdgeMax_dS_D_Temp,[],'all'));

        HistEdgeStep_D_Temp = UI_In.PlotDistStep_um; % in pixels
        HistEdge_D_Temp = 0:HistEdgeStep_D_Temp:HistEdgeStep_D_Temp*ceil(HistEdgeMax_D_Temp./HistEdgeStep_D_Temp); % in um

        HistBinLbl_D_Temp = strings(1,(numel(HistEdge_D_Temp)-1));
        for bCt = 1:(numel(HistEdge_D_Temp)-1) % HistBin Count
            str_Temp = strcat(num2str(HistEdge_D_Temp(bCt)),'-',num2str(HistEdge_D_Temp(bCt+1)));
            HistBinLbl_D_Temp(1,bCt) = str_Temp;
        end

        % = Number of pixels assigned for each k and HistBin_D after adjustment
        % To be used for normalizing histogram counts for all Cases
        NumPx_PxAssign_byHistBinD_byk_Temp = zeros(1,numel(HistEdge_D_Temp)-1,size(ImgStack_gDist_um_Temp,3),'single');

        for k=1:size(ImgStack_gDist_um_Temp,3)

            Img_gDist_Temp = ImgStack_gDist_um_Temp(:,:,k);
            Img_PxMask_Temp = ImgStack_Hist_PxAssignMask_Temp(:,:,k);

            Img_gDist_Temp = Img_gDist_Temp(Img_PxMask_Temp);
            Img_gDist_Temp(isnan(Img_gDist_Temp) | isinf(Img_gDist_Temp)) = [];
            Img_gDist_Temp = UI_In.XY_PxLength_umpx.*Img_gDist_Temp; % distance unit = um

            NumPx_PxAssign_byHistBinD_byk_Temp(1,:,k) = histcounts(Img_gDist_Temp,HistEdge_D_Temp);

        end

        % Case 1): Each dS-Blob represented by multiple distance values, from each pixel in the blob,
        % to nearest distance-targets
        % ie. each dS-Blob's pixels may cross multiple distance HistBin

        HistVal_dsPxbyD_Cell_Temp = cell(1,1,size(ImgStack_gDist_um_Temp,3));
        for k=1:size(ImgStack_gDist_um_Temp,3)

            Img_gDist_Temp = ImgStack_gDist_um_Temp(:,:,k);
            Img_dSMask_Temp = ImgStack_Hist_dSAssignMask_Temp(:,:,k);
            Img_PxMask_Temp = ImgStack_Hist_PxAssignMask_Temp(:,:,k);

            HistVal_dsPxbyD_Cell_Temp{1,1,k} = Img_gDist_Temp(Img_dSMask_Temp);
            HistVal_dsPxbyD_Cell_Temp{1,1,k}(isnan(HistVal_dsPxbyD_Cell_Temp{1,1,k}) | isinf(HistVal_dsPxbyD_Cell_Temp{1,1,k})) = [];
            HistVal_dsPxbyD_Cell_Temp{1,1,k} = UI_In.XY_PxLength_umpx.*HistVal_dsPxbyD_Cell_Temp{1,1,k}; % distance unit = um

        end

        % "Data_HistCt_dSPxbyD_Temp": 3 rows:
        % Row01: Row02/Row03 (to be plotted)
        % Row02: Number of Pixels, PxAssign, in each distance HistBin
        % Row03: Number of Pixels, dSAssign, in each distance HistBin (each blob's every pixel assigned its own PixelValues_D)
        Data_HistCt_dSPxbyD_Temp = zeros(3,... % Number of rows =  3 rows of data
            numel(HistEdge_D_Temp)-1,... % # Number of columns = length(HistBin_D)
            size(ImgStack_gDist_um_Temp,3),'single'); % k = Dist Target Index
        for k=1:size(ImgStack_gDist_um_Temp,3)
            Data_HistCt_dSPxbyD_Temp(3,:,k) = single(histcounts(HistVal_dsPxbyD_Cell_Temp{1,1,k},HistEdge_D_Temp));
            Data_HistCt_dSPxbyD_Temp(2,:,k) = NumPx_PxAssign_byHistBinD_byk_Temp(:,:,k);
            Data_HistCt_dSPxbyD_Temp(1,:,k) = Data_HistCt_dSPxbyD_Temp(3,:,k)./Data_HistCt_dSPxbyD_Temp(2,:,k); % Row01: to be plotted
        end

        % = 20250405: HistCt_Tbl (2D table for export into csv)
        % 3 Columns: [k HistBin Row01Val]
        for k=1:size(ImgStack_gDist_um_Temp,3)
            Mtx_dSPxbyD_Temp = horzcat(repmat(k,(numel(HistEdge_D_Temp)-1),1),... % k
                (1:1:(numel(HistEdge_D_Temp)-1))',... % HistBin
                Data_HistCt_dSPxbyD_Temp(1,:,k)'); % Row01Val
            if k<2
                DataExp_HistCt_dSPxbyD_Temp = Mtx_dSPxbyD_Temp;
            else
                DataExp_HistCt_dSPxbyD_Temp = vertcat(DataExp_HistCt_dSPxbyD_Temp,Mtx_dSPxbyD_Temp);
            end
        end
        DataExp_HistCt_dSPxbyD_Temp = ...
            array2table(DataExp_HistCt_dSPxbyD_Temp,'VariableNames',{'k','HistBin','Row01Val'});

        % = Store in Output
        HistData_Save_Temp = struct;
        HistData_Save_Temp.HistData.HistName = strcat("Hist_dSPxbyD_q",num2str(qCt,'%02d'),"_um");
        HistData_Save_Temp.HistData.HistEdge_D = HistEdge_D_Temp;
        HistData_Save_Temp.HistData.HistBinLbl_D = HistBinLbl_D_Temp;
        HistData_Save_Temp.HistData.HistCt = Data_HistCt_dSPxbyD_Temp; % Plot Row01 of each k for Histogram
        HistData_Save_Temp.HistData.HistCt_Tbl = DataExp_HistCt_dSPxbyD_Temp; % [k HistBin Row01Val]
        HistData_Save_Temp.HistData.HistyLbl = "Fraction_Ct_dSPx_Ct_Px"; % y label of histogram
        HistData_Save_Temp.HistData.NumDistT = NumDistT_Temp; % OCN, TRAP etc; 1 for bone front
        HistData_Save_Temp.HistData.k_Str = Str_Temp;

        PlotData_AreaDHist_Cell_Out{RowIdx_Temp,ColIdx_Out_Temp(1,1),qCt} = HistData_Save_Temp;

        % Case 2): Each dS-Blob represented by 1 distance value (= mean of all pixels in the blob)
        % to nearest distance-targets
        % ie. each dS-Blob's pixels are in 1 distance HistBin
        % * Case 2.1) Uniformize distance of each dSBlob; set value = mean of all distance values
        % in blob. Each blob is represented in 'HistVal' as ** number of pixels in blob **.
        % (HistVal = 1 dist val per dSBlob x # px in blob)
        % * Case 2.2) Uniformize distance of each dSBlob; set value = mean of all distance values
        % in blob. Each blob is represented in 'HistVal' as ** number of dSUt in blob **.
        % (HistVal = 1 dist val per dSBlob x # dSUt in blob)

        HistVal_dSPxbyD_Blob_Cell_Temp = cell(1,1,size(ImgStack_gDist_um_Temp,3));
        HistVal_dSUtbyD_Blob_Cell_Temp = cell(1,1,size(ImgStack_gDist_um_Temp,3));

        for k=1:size(ImgStack_gDist_um_Temp,3)

            dataTbl_k_Temp = dataTbl_Cell_Temp{1,1,k};

            if ~isempty(dataTbl_k_Temp) % 20250801: dSAssignMask has blobs assigned to k

                dataTbl_k_Temp(isnan(dataTbl_k_Temp.PixelValues_D) | isinf(dataTbl_k_Temp.PixelValues_D),:) = []; % Should have no deletion here, but safeguard

                % Case 2.1) Uniformize distance of each dSBlob; set value = mean of all distance values
                % in blob. Each blob is represented in 'HistVal' as ** number of pixels in blob **.
                PxVal_D_Blob_k_Temp = splitapply(@mean,dataTbl_k_Temp.PixelValues_D,dataTbl_k_Temp.BlobIdx); % distance unit: px
                NumdSPx_Blob_k_Temp = splitapply(@numel,dataTbl_k_Temp.PixelValues_D,dataTbl_k_Temp.BlobIdx);
                HistVal_dSPxbyD_Blob_k_Temp = UI_In.XY_PxLength_umpx.*repelem(PxVal_D_Blob_k_Temp,NumdSPx_Blob_k_Temp); % distance unit: um
                HistVal_dSPxbyD_Blob_Cell_Temp{1,1,k} = HistVal_dSPxbyD_Blob_k_Temp; % distance unit: um

                % Case 2.2) Uniformize distance of each dSBlob; set value = mean of all distance values
                % in blob. Each blob is represented in 'HistVal' as ** number of dSUt in blob **.
                NumdSUt_byBlobIdx_k_Temp = max(1,round(NumdSPx_Blob_k_Temp/PlotData_AreaDHist_Cell_Out{RowIdx_Temp,1}.dSUt.Area.Median_px)); % Est number of dsUt in blob
                HistVal_dSUtbyD_Blob_k_Temp = UI_In.XY_PxLength_umpx.*repelem(PxVal_D_Blob_k_Temp,NumdSUt_byBlobIdx_k_Temp);
                HistVal_dSUtbyD_Blob_Cell_Temp{1,1,k} = HistVal_dSUtbyD_Blob_k_Temp;
            
            end

        end

        % Case 2.1) "Data_HistCt_dSPxbyD_Blob_Temp": 3 rows:
        % Row01: Row03/Row02 (to be plotted)
        % Row02: Correction Factor for normalizing different number of pixels assigned to each k, each HistBin_D
        % (Inversely proportional to Row02: "Number of Pixels, PxAssign, in each distance HistBin", in Case 1)
        % Row03: Number of Pixels, dSAssign, in each distance HistBin (each blob's every pixel assigned blob's mean PixelValues_D)
        Data_HistCt_dSPxbyD_Blob_Temp = zeros(2,... % Number of rows =  2 rows of data
            numel(HistEdge_D_Temp)-1,... % # Number of columns = length(HistBin_D)
            size(ImgStack_gDist_um_Temp,3),'single'); % k = Dist Target Index

        % Case 2.2)  "Data_HistCt_dSUtbyD_Blob_Temp": 2 rows:
        % Row01: Row03/Row02 (= Fraction Px Pixels occupancy by dS pixels)
        % Row02: Correction Factor for normalizing different number of pixels assigned to each k, each HistBin_D
        % (Inversely proportional to Row02: "Number of Pixels, PxAssign, in each distance HistBin", in Case 1)
        % Row03: (Estimated) Number of dSUt, dSAssign, in each distance HistBin (each blob divides into u dSUt's; each dSUt distance = blob's mean PixelValues_D)
        Data_HistCt_dSUtbyD_Blob_Temp = zeros(2,... % Number of rows =  2 rows of data
            numel(HistEdge_D_Temp)-1,... % # Number of columns = length(HistBin_D)
            size(ImgStack_gDist_um_Temp,3),'single'); % k = Dist Target Index

        for k=1:size(ImgStack_gDist_um_Temp,3)
            if ~isempty(HistVal_dSPxbyD_Blob_Cell_Temp{1,1,k}) % 20250801: dSAssignMask has blobs assigned to k
                Data_HistCt_dSPxbyD_Blob_Temp(3,:,k) = single(histcounts(HistVal_dSPxbyD_Blob_Cell_Temp{1,1,k},HistEdge_D_Temp));
                Data_HistCt_dSPxbyD_Blob_Temp(2,:,k) = NumPx_PxAssign_byHistBinD_byk_Temp(1,:,k);
                Data_HistCt_dSPxbyD_Blob_Temp(1,:,k) = Data_HistCt_dSPxbyD_Blob_Temp(3,:,k)./Data_HistCt_dSPxbyD_Blob_Temp(2,:,k); % Row01: to be plotted
            end

            if ~isempty(HistVal_dSUtbyD_Blob_Cell_Temp{1,1,k}) % 20250801: dSAssignMask has blobs assigned to k
                Data_HistCt_dSUtbyD_Blob_Temp(3,:,k) = single(histcounts(HistVal_dSUtbyD_Blob_Cell_Temp{1,1,k},HistEdge_D_Temp));
                Data_HistCt_dSUtbyD_Blob_Temp(2,:,k) = NumPx_PxAssign_byHistBinD_byk_Temp(1,:,k);
                Data_HistCt_dSUtbyD_Blob_Temp(1,:,k) = Data_HistCt_dSUtbyD_Blob_Temp(3,:,k)./Data_HistCt_dSUtbyD_Blob_Temp(2,:,k); % Row01: to be plotted
            end
        end

        % = 20250405: HistCt_Tbl (2D table for export into csv)
        % 3 Columns: [k HistBin Row01Val]
        for k=1:size(ImgStack_gDist_um_Temp,3)

            if max(Data_HistCt_dSPxbyD_Blob_Temp,[],'all')>0 % 20250801: dSAssignMask has blobs assigned to k
                Mtx_dSPxbyD_Blob_Temp = horzcat(repmat(k,(numel(HistEdge_D_Temp)-1),1),...
                    (1:1:(numel(HistEdge_D_Temp)-1))',...
                    Data_HistCt_dSPxbyD_Blob_Temp(1,:,k)');
                if k<2
                    DataExp_HistCt_dSPxbyD_Temp = Mtx_dSPxbyD_Blob_Temp;
                else
                    DataExp_HistCt_dSPxbyD_Temp = vertcat(DataExp_HistCt_dSPxbyD_Temp,Mtx_dSPxbyD_Blob_Temp);
                end
            end

            if max(Data_HistCt_dSUtbyD_Blob_Temp,[],'all')>0 % 20250801: dsAssignMask has blobs assigned to k
                Mtx_dSUtbyD_Blob_Temp = horzcat(repmat(k,(numel(HistEdge_D_Temp)-1),1),...
                    (1:1:(numel(HistEdge_D_Temp)-1))',...
                    Data_HistCt_dSUtbyD_Blob_Temp(1,:,k)');
                if k<2
                    DataExp_HistCt_dSUtbyD_Blob_Temp = Mtx_dSUtbyD_Blob_Temp;
                else
                    DataExp_HistCt_dSUtbyD_Blob_Temp = vertcat(DataExp_HistCt_dSUtbyD_Blob_Temp,Mtx_dSUtbyD_Blob_Temp);
                end
            end

        end

        DataExp_HistCt_dSPxbyD_Temp = ...
            array2table(DataExp_HistCt_dSPxbyD_Temp,'VariableNames',{'k','HistBin','Row01Val'});
        DataExp_HistCt_dSUtbyD_Blob_Temp = ...
            array2table(DataExp_HistCt_dSUtbyD_Blob_Temp,'VariableNames',{'k','HistBin','Row01Val'});

        % = Store in Output
        % Case 2.1) HIstVal = 1 dist val per dSBlob x # px in blob
        HistData_Save_Temp = struct;
        HistData_Save_Temp.HistData.HistName = strcat("Hist_dSPxbyD_Blob_q",num2str(qCt,'%02d'),"_um");
        HistData_Save_Temp.HistData.HistEdge_D = HistEdge_D_Temp;
        HistData_Save_Temp.HistData.HistBinLbl_D = HistBinLbl_D_Temp;
        HistData_Save_Temp.HistData.HistCt = Data_HistCt_dSPxbyD_Blob_Temp; % Plot Row01 of each k for Histogram
        HistData_Save_Temp.HistData.HistCt_Tbl = DataExp_HistCt_dSPxbyD_Temp; % [k HistBin Row01Val]
        HistData_Save_Temp.HistData.HistyLbl = "Normalized_Ct_dSPx";
        HistData_Save_Temp.HistData.NumDistT = NumDistT_Temp; % OCN, TRAP etc; 1 for bone front
        HistData_Save_Temp.HistData.k_Str = Str_Temp;

        PlotData_AreaDHist_Cell_Out{RowIdx_Temp,ColIdx_Out_Temp(1,2),qCt} = HistData_Save_Temp;

        % Case 2.2) HIstVal = 1 dist val per dSBlob x # dSUt in blob
        HistData_Save_Temp = struct;
        HistData_Save_Temp.HistData.HistName = strcat("Hist_dSUtbyD_Blob_q",num2str(qCt,'%02d'),"_um");
        HistData_Save_Temp.HistData.HistEdge_D = HistEdge_D_Temp;
        HistData_Save_Temp.HistData.HistBinLbl_D = HistBinLbl_D_Temp;
        HistData_Save_Temp.HistData.HistCt = Data_HistCt_dSUtbyD_Blob_Temp; % Plot Row01 of each k for Histogram
        HistData_Save_Temp.HistData.HistCt_Tbl = DataExp_HistCt_dSUtbyD_Blob_Temp; % [k HistBin Row01Val]
        HistData_Save_Temp.HistData.HistyLbl = "Normalized_Ct_dSUt";
        HistData_Save_Temp.HistData.NumDistT = NumDistT_Temp; % OCN, TRAP etc; 1 for bone front
        HistData_Save_Temp.HistData.k_Str = Str_Temp;

        PlotData_AreaDHist_Cell_Out{RowIdx_Temp,ColIdx_Out_Temp(1,3),qCt} = HistData_Save_Temp;

    end

end

clearvars *_Temp k qCt;


%% Create Histogram Plots

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Define colormap for plotting all histograms
    cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
    cmap_Disp_Temp = vertcat(...
        [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
        [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
        [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
        );

    % = Specify HistData to plot
    ColIdx_PlotInOut_Temp = [2:4]; % Case 1), 2.1), 2.2)

    for csCt = 1:width(ColIdx_PlotInOut_Temp) % number of cases

        for qCt = 1:Numq

            HistData_Temp = PlotData_AreaDHist_Cell_Out{RowIdx_Temp,ColIdx_PlotInOut_Temp(csCt),qCt}.HistData;

            x_Temp = HistData_Temp.HistBinLbl_D;
            y_Temp = HistData_Temp.HistCt(1,:,:); % all k along 3rd dimension

            % = Figure 01a: All k, auto ymax

            FigHandle01a = figure('Position',[25 150 1800 300*NumDistT_Temp],'visible','off','PaperPositionMode','auto'); % [left bottom width height]
            tlo = tiledlayout(NumDistT_Temp,3,'TileSpacing','Compact','Padding','tight','TileIndexing', 'columnmajor'); % tile layout; replace subplot()
            set(gcf,'color','white');

            for k=1:size(y_Temp,3) % all k

                ax = nexttile(tlo);
                hold(ax, 'on'); grid off;

                bh = bar(x_Temp,y_Temp(:,:,k),'FaceColor','flat','FaceAlpha',0.50);
                bh(1).CData = repmat(cmap_Disp_Temp(k,:),height(bh(1).CData),1);
                bh(1). LineWidth = 2.00;

                ylim([0 max(y_Temp,[],'all')]);

                xlabel('Distance to Target (um)','interpreter','none');
                ylabel(HistData_Temp.HistyLbl,'interpreter','none');

                fontname('Arial'); fontsize(16,'points'); set(gca,'FontWeight','bold');

            end

            sgtitle(HistData_Temp.HistName,'interpreter','none','FontName','Arial','FontSize',12,'FontWeight','bold');


            % = Figure 01b: k of Bdc, Btb only

            FigHandle01b = figure('Position',[50 200 1200 300*NumDistT_Temp],'visible','off','PaperPositionMode','auto'); % [left bottom width height]
            tlo = tiledlayout(NumDistT_Temp,3,'TileSpacing','Compact','Padding','tight','TileIndexing', 'columnmajor'); % tile layout; replace subplot()
            set(gcf,'color','white');

            for k=1:size(y_Temp,3)

                ax = nexttile(tlo);
                hold(ax, 'on'); grid off;

                if k > NumDistT_Temp % Plot only Bdc, Btb
                    bh = bar(x_Temp,y_Temp(:,:,k),'FaceColor','flat','FaceAlpha',0.50);
                    bh(1).CData = repmat(cmap_Disp_Temp(k,:),height(bh(1).CData),1);
                    bh(1). LineWidth = 2.00;
                end

                ylim([0 max(y_Temp(1,:,(NumDistT_Temp+1):end),[],'all')]); % calculated from Bdc, Btb only

                xlabel('Distance to Target (um)','interpreter','none');
                ylabel(HistData_Temp.HistyLbl,'interpreter','none');

                fontname('Arial'); fontsize(16,'points'); set(gca,'FontWeight','bold');

            end

            sgtitle(HistData_Temp.HistName,'interpreter','none','FontName','Arial','FontSize',12,'FontWeight','bold');

            % = Prepare display, also store as plot output
            iptsetpref("ImshowBorder","tight"); % remove borders; do before export_fig

            Img_Fig01a_Temp =  export_fig(FigHandle01a,'-r150');
            Img_Fig01a_Temp = imresize(Img_Fig01a_Temp,[round(1.5*300*NumDistT_Temp) NaN]); % Proportional to height of FigHandle

            Img_Fig01b_Temp =  export_fig(FigHandle01b,'-r150');
            Img_Fig01b_Temp = imresize(Img_Fig01b_Temp,[height(Img_Fig01a_Temp) width(Img_Fig01a_Temp)]);

            Img_Fig01_Temp = vertcat(...
                Img_Fig01a_Temp,...
                255.*ones(40,width(Img_Fig01a_Temp),3,'uint8'),... % spacer between 2 plots
                Img_Fig01b_Temp);

            % % % figure; imshow(Img_Fig01_Temp);

            Plot_AreaDHist_Cell_Out{dtsCt,ColIdx_PlotInOut_Temp(csCt),qCt} = Img_Fig01_Temp;

            close all;

        end

    end

end

clearvars *_Temp *_Disp FigHandle* bh k hCt;


%% Prepare ImgCheck

% =  Logical Mask, pixels excluded from PxAssign Histogram
% Use Mask of non-trabecular bone marrow holes that are likely tears from biopsy preparations
% Pixels without k assigned due to inaccessibility by geodesic distance measurement
% These pixels are excluded from histogram preparations as dist-source
% blobs cannot sit on these pixels
% (= ImgCheck_AreaDHist_Cell{dtsCt,2})

Img_PxHistExclude_Mask_Temp = Img_DistS_Cell_In{1,6};

% = Preparations for all k and qCt
% "ColIdx_In_Temp' specifies the column Idx of where data needed is stored in
% "Img_dSAssignAdj_Cell". Row for Px vs dS; column for Beg vs Bdc vs Btb, z
% for ignore quality score vs consider quality score
% % % ColIdx_In_Temp = cat(3,[3 4 5; 23 24 25],[6 7 8; 26 27 28]);
ColIdx_In_Temp = [3 4 5; 23 24 25];

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Define colormap for plotting all histograms
    cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
    cmap_Disp_Temp = vertcat(...
        [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
        [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
        [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
        );

    for qCt = 1:Numq % ignore vs consider quality of assignment score

        % = Create for Histogram creation, for each qCt:
        % i) ImgStack_Hist_PxAssignMask_Temp (logical): z-stack of all
        % assignment-of-pixel masks to be used for histogram; remove pixels
        % that are not trabecular bone but tears in biopsy or without k
        % assignment due to geodesic distance measurement inaccessbility
        % ii) ImgStack_Hist_dSAssignMask_Temp (logical): z-stack of all assignment-of-distSblob masks
        % iii) ImgStack_gDist_um_Temp (single): z-stack of all DIstMap; *convert to um*
        % Beg: k =  1:NumDistT
        % Bdc: k = (NumDistT+1):2*NumDistT
        % Btb: k = (2*NumDistT+1):3*NumDistT

        ImgStack_Hist_PxAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_In(RowIdx_Temp,ColIdx_In_Temp(1,:),qCt),[1 3 2])); % i)
        ImgStack_Hist_PxAssignMask_Temp = ImgStack_Hist_PxAssignMask_Temp & ... % 20250318: exclude non-trabecular marrow hole pixels that are tears in biopsy prep or without k assignment
            repmat(~Img_PxHistExclude_Mask_Temp,1,1,size(ImgStack_Hist_PxAssignMask_Temp,3));
        ImgStack_Hist_dSAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_In(RowIdx_Temp,ColIdx_In_Temp(2,:),qCt),[1 3 2])); % ii)

        Img_Hist_PxAssignMask_Disp = max(uint16(ImgStack_Hist_PxAssignMask_Temp).*permute(uint16(1:1:size(ImgStack_Hist_PxAssignMask_Temp,3)),[1 3 2]),[],3);
        Img_Hist_PxAssignMask_Disp = label2rgb(Img_Hist_PxAssignMask_Disp,cmap_Disp_Temp,[0 0 0]);
        Img_Hist_PxAssignMask_Disp = addborder(Img_Hist_PxAssignMask_Disp,2,[255 255 255],'inner');

        Img_Hist_dSAssignMask_Disp = max(uint16(ImgStack_Hist_dSAssignMask_Temp).*permute(uint16(1:1:size(ImgStack_Hist_PxAssignMask_Temp,3)),[1 3 2]),[],3);
        Img_Hist_dSAssignMask_Disp = label2rgb(Img_Hist_dSAssignMask_Disp,cmap_Disp_Temp,[0 0 0]);
        Img_Hist_dSAssignMask_Disp = addborder(Img_Hist_dSAssignMask_Disp,2,[255 255 255],'inner');

        Img_Disp = horzcat(repmat(255.*uint8(Img_MrwDef_Cell_In{1,1}),1,1,3), ... % Marrow Mask
            Img_Hist_PxAssignMask_Disp, ...  % Adj PxAssign Mask, non Btb tears and unassigned k regions removed
            Img_Hist_dSAssignMask_Disp); % Adj dSAssign Mask

        % % % figure; imshow(Img_Disp);

        ImgCheck_AreaDHist_Cell_Out{dtsCt,2,qCt} = Img_Disp;
        ImgCheck_AreaDHist_Cell_Out{dtsCt,2,qCt} = imresize(ImgCheck_AreaDHist_Cell_Out{dtsCt,2,qCt},[800, NaN]);

    end

end

clearvars *_Temp *_Disp qCt k;