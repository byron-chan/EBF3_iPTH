% 20250123: Usage
% i) Img_Lbl_Cell_In: 'Img_Lbl_Cell' contains nuclei image in {1,1}, Ebf3 image in {2,1} and all
% bone structure image in {3,1} 
% Nuclei Image (ie, Img_Lbl_Cell_In{1,1}) used to create marrow mask
% ii) Default adapthisteq_NumTiles_In = 64
% iii) 'y' if create colocalization check image

function [Img_Nuc_MrwMask_Out,ImgCheck_Nuc_MrwMask_Out] = fCreateMrwMaskEbf3(Img_Lbl_Cell_In,adapthisteq_NumTiles_In,ImgCheckOption_In)

%% Create Marrow Mask

% = Define Marrow Mask
Img_Nuc_In = Img_Lbl_Cell_In{1,1}; % Nuclei Image

Img_Nuc_BW = adapthisteq(Img_Nuc_In,'NumTiles',[adapthisteq_NumTiles_In round(adapthisteq_NumTiles_In.*width(Img_Nuc_In)/height(Img_Nuc_In))]);

[thresh,threshmetric] = multithresh(Img_Nuc_BW(Img_Nuc_BW>0),1);
Img_Nuc_BW = imbinarize(Img_Nuc_BW,thresh(1)); % NumTiles: [Row Col]
Img_Nuc_MrwMask_Out = Img_Nuc_BW;

rp_Tbl = regionprops(Img_Nuc_MrwMask_Out,'Area','PixelIdxList');
FlagID = cat(1,rp_Tbl.Area)<0.1*max(cat(1,rp_Tbl.Area),[],'all');
rp_Tbl(FlagID) = [];
Img_Nuc_MrwMask_Out = zeros(size(Img_Nuc_MrwMask_Out),'logical');
Img_Nuc_MrwMask_Out(cat(1,rp_Tbl.PixelIdxList)) = 1;

% = OPTIONAL: Check Marrow Mask
% Colocalize with Ebf3 cells (image in Img_Lbl_Cell_In{2,1}) and 
% bone structure images in Img_Lbl_Cell_In{3,1}
% Resize Img_Check_Out to have height = 500px
if ImgCheckOption_In == 'y'
    ImgCheck_Nuc_MrwMask_Out = imresize(imfuse(Img_Lbl_Cell_In{2,1}, 0.80.*Img_Nuc_MrwMask_Out,'Scaling','none','ColorChannels',[1 0 2]),[500 NaN]); % Ebf3 
    for bsCt = 1:size(Img_Lbl_Cell_In{3,1},3) % bone structure count
        ImgCheck_Nuc_MrwMask_Out = horzcat(ImgCheck_Nuc_MrwMask_Out,...
            imresize(imfuse(Img_Lbl_Cell_In{3,1}(:,:,bsCt), 0.80.*Img_Nuc_MrwMask_Out,'Scaling','none','ColorChannels',[0 1 2]),[500 NaN]));
    end
    % figure;
    % Img_Fuse = horzcat(imfuse(Img_Lbl_Cell_In{2,1}, 0.80.*Img_Nuc_MrwMask_Out,'Scaling','none','ColorChannels',[1 0 2]),...
    %     imfuse(Img_Lbl_Cell_In{3,1}(:,:,1), 0.80.*Img_Nuc_MrwMask_Out,'Scaling','none','ColorChannels',[0 1 2]));
    % imshow(Img_Fuse);
else
    ImgCheck_Nuc_MrwMask_Out = [];
end

clearvars thresh* Img_Nuc_BW Img_Nuc_Temp;
clearvars rp* FlagID;
clearvars Img_Check;