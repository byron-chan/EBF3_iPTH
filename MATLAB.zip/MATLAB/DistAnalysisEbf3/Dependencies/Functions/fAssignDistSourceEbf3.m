% 20250306: Assign pixels in distance-assigned area, and dist-Source blobs (Ebf3)
% in distance-assigned area, to dist Target

function [Img_DistSAssign_Cell_Out,ImgCheck_DistSAssign_Cell_Out] = fAssignDistSourceEbf3(Img_gDistMap_Cell_In,Img_DistS_Cell_In,Img_Begdc_Cell_In,UI_In)


%% Prepare Output

% = Img_DistSAssign_Cell_Out

Img_DistSAssign_Cell_Out = cell(4,20);

% Assignment of each pixel and eacn Dist-Source-Blob (Ebf3) (with gDist measurement to) different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Logical Map, all pixels receiving DistT assignment based on final output mask from bwdistgeodesic()
% (Row 3,4; = ~Img_gDistMap_Cell{1,5}, combined result from Row 3, Row 4)
% * Col02 = Assignment Mask by *pixel* (single), to real/hyp dist-Target @ epiphysis-growth plate (Beg), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3 (real), Row 4 (hyp))
% * Col03 = Assignment Mask by *pixel* (single), to real/hyp dist-Target @ diaphysis-cortical bone (Bdc), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3 (real), Row 4 (hyp))
% * Col04 = Assignment Mask by *pixel* (single), to real/hyp dist-Target @ trabecular bone (Btb), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3 (real), Row 4 (hyp))
% * Col05 = Assignment Label Map by *pixel* (uint16), to all real/hyp dist-Target. Same kIdx order as ImgStack_gDist_Temp below (Row 3 (real), Row 4 (hyp))
% * Col06 = Assignment mean-gDist Map by *pixel* (single), to all real/hyp dist-Target (Row 3 (real), Row 4 (hyp))
% * Col07 = Quality of Assignment Map by *pixel* (single, general score range [-1 1], in-code range [0 1]; close to 1 better) (Row 3 (real), Row 4 (hyp))
% * Col08-10 = (empty)

% * Col11 = Logical Map, Dist-Source Blobs receiving assignment based on final output mask from bwdistgeodesic()
% (Row 2; = Img_DistS_Cell{2,5})
% * Col12 = Assignment Mask by *dist source blob* (single), to real/hyp dist-Target @ epiphysis-growth plate (Beg), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3,4)
% * Col13 = Assignment Mask by *dist source blob* (single), to real/hyp dist-Target @ diaphysis-cortical bone (Bdc), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3,4)
% * Col14 = Assignment Mask by *dist source blob* (single), to real/hyp dist-Target @ trabecular bone (Btb), all pixels receiving assignment based on final output mask from bwdistgeodesic() (Row 3,4)
% * Col15 = Assignment Label Map by *dist source blob* (uint16), to all real/hyp dist-Target. Same kIdx order as ImgStack_gDist_Temp below (Row 3 (real), Row 4 (hyp))
% * Col16 = Assignment mean-gDist Map by *dist source blob* (single), to all real/hyp dist-Target (Row 3 (real), Row 4 (hyp))
% * Col17 = Quality of Assignment Map by *dist source blob* (single, general score range [-1 1], in-code range [0 1]; close to 1 better)  (Row 3 (real), Row 4 (hyp))
% * Col18-20 = (empty)


% = ImgCheck_DistSAssign_Cell_Out

ImgCheck_DistSAssign_Cell_Out = cell(2,20);

% 2 Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Logical Map, all * pixels * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col02 = Label Map (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), all * pixels * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col03 = Quality of assignment map (no colorbar; range [-1 1]), all * pixels * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col04 = Quality of assignment map (w/ colorbar; range [-1 1]), all * pixels * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col05-10 = (empty)

% * Col11 = Logical Map, all * dist-source blob * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col12 = Label Map (yellow: DistT for Beg, cyan: Bdc, magenta: Btb), all * dist-source blob * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col13 = Quality of assignment map (no colorbar; range [-1 1]), all * dist-source blob * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col14 = Quality of assignment map (w/ colorbar; range [-1 1]), all * dist-source blob * receiving DistT assignment based on final output mask from bwdistgeodesic()
% * Col15-20 = (empty)


%%

% % % NumDistT = size(Img_gDistMap_Cell_In{3,1},3); % Number of distance target (OCN, TRAP etc)
% % % NumDistTbf = size(Img_gDistMap_Cell_In{4,1},3); % Number of "hypothetical" bone front staining = 1
NumDistT_Mtx = [...
    size(Img_gDistMap_Cell_In{3,1},3); ... % Number of distance target (OCN, TRAP etc); = NumDistT (Row 3)
    size(Img_gDistMap_Cell_In{4,1},3)... % Number of "hypothetical" bone front staining = 1 = NumDistTbf (Row 4)
    ];
NumDistSBlob = height(regionprops(Img_DistS_Cell_In{2,5},'centroid')); % # dist measure source (Ebf3) blobs

% = Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)
Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;


%% === Assignment for pixels

%% Row 3-4, Col 01:  Logical Map, all pixels receiving DistT assignment based on final output mask from bwdistgeodesic()

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    %  = Store as output
    Img_DistSAssign_Cell_Out{RowIdx_Temp,1} = repmat(~Img_gDistMap_Cell_In{RowIdx_Temp,5}(:,:,1),1,1,NumDistT_Temp);

    %  = Store as output, ImgCheck
    ImgCheck_DistSAssign_Cell_Out{dtsCt,1} = ~Img_gDistMap_Cell_In{RowIdx_Temp,5}(:,:,1);
    ImgCheck_DistSAssign_Cell_Out{dtsCt,1} = imresize(ImgCheck_DistSAssign_Cell_Out{dtsCt,1},[800 NaN]); % OPTIONAL: resize img height to 800px

end

clearvars *_Temp *_Disp dtsCt;


%% Row 3-4, Col 02-04 Assignment Masks by pixel, all pixels receiving DistT assignment
% + Col 05 Assignment Label Map by pixel

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Create ImgStack_gDist_Temp: z-stack of all gDistMap
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT
    ImgStack_gDist_Temp = cell2mat(permute(Img_gDistMap_Cell_In(RowIdx_Temp,1:3),[1 3 2]));
    ImgStack_gDist_Temp(repmat(~Img_DistSAssign_Cell_Out{RowIdx_Temp,1},1,1,3)) = NaN; % repeat 3 times for Beg, Bdc. Btb

    % = Assign each pixel to the kIdx with minimum gDist
    % All permitted pixels from bwdistgeodesic()'s output are assigned 1 k value
    [ImgStack_gDistZsort_Temp,ImgStack_gDistZsort_kIdx_Temp] = sort(ImgStack_gDist_Temp,3,'ascend'); % sort to find lowest gDist value and corresponding kIdx
    Img_gDistZsort_mink1_Mask_Temp = ones(height(ImgStack_gDistZsort_Temp),width(ImgStack_gDistZsort_Temp),'logical');

    Img_gDistZsort_mink1_Temp = ImgStack_gDistZsort_Temp(:,:,1); % min gDist value for each pixel
    Img_gDistZsort_mink1_Temp(~Img_DistSAssign_Cell_Out{RowIdx_Temp,1}(:,:,1) | ~Img_gDistZsort_mink1_Mask_Temp) = NaN;

    Img_gDistZsort_mink1_kIdx_Temp = ImgStack_gDistZsort_kIdx_Temp(:,:,1); % Corresponding kIdx of min gDist value for each pixel (=PxAssign)
    Img_gDistZsort_mink1_kIdx_Temp(~Img_DistSAssign_Cell_Out{RowIdx_Temp,1}(:,:,1) | ~Img_gDistZsort_mink1_Mask_Temp) = 0;

    Img_gDistZsort_mink2_Temp = ImgStack_gDistZsort_Temp(:,:,2); % 2nd smallest gDist value for each pixel (for ceval)
    Img_gDistZsort_mink2_Temp(~Img_DistSAssign_Cell_Out{RowIdx_Temp,1}(:,:,1) | ~Img_gDistZsort_mink1_Mask_Temp) = NaN;

    Img_PxAssign_kIdx_Temp = Img_gDistZsort_mink1_kIdx_Temp; % Assignment Labels
    Mtx_PxAssign_Dist_Temp = Img_gDistZsort_mink1_Temp; % Distance values used for assignment (gDistZsort_mink1); Range [0 Inf]

    % = Store Assignment Label Map as output
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT
    % % % Img_DistSAssign_Cell_Out{1,5} = uint16(Img_PxAssign_kIdx_Temp);
    % % % Img_DistSAssign_Cell_Out{2,5} = uint16(Img_PxAssign_kIdx_Temp);
    Img_DistSAssign_Cell_Out{RowIdx_Temp,5} = repmat(uint16(Img_PxAssign_kIdx_Temp),1,1,NumDistT_Temp);
    % % % Img_DistSAssign_Cell_Out{4,5} = repmat(uint16(Img_PxAssign_kIdx_Temp),1,1,NumDistT_Temp);

    % = Store gDist Map used for assignment as output
    % Note: range [0 Inf]
    % % % Img_DistSAssign_Cell_Out{1,6} = single(Mtx_PxAssign_Dist_Temp);
    % % % Img_DistSAssign_Cell_Out{2,6} = single(Mtx_PxAssign_Dist_Temp);
    Img_DistSAssign_Cell_Out{RowIdx_Temp,6} = repmat(single(Mtx_PxAssign_Dist_Temp),1,1,NumDistT_Temp);
    % % % Img_DistSAssign_Cell_Out{4,6} = repmat(single(Mtx_PxAssign_Dist_Temp),1,1,NumDistT_Temp);

    % = Visual Check: Disp image also for "ImgCheck_DistSAssign_Cell_Out"
    Img_PxAssign_kIdx_Disp = Img_gDistZsort_mink1_kIdx_Temp;
    cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
    cmap_Disp_Temp = vertcat(...
        [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
        [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
        [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
        );
    Img_PxAssign_kIdx_Disp = label2rgb(Img_gDistZsort_mink1_kIdx_Temp,cmap_Disp_Temp,[0 0 0]);
    ImgCheck_DistSAssign_Cell_Out{dtsCt,2} = Img_PxAssign_kIdx_Disp; % Store in output
    ImgCheck_DistSAssign_Cell_Out{dtsCt,2} = imresize(ImgCheck_DistSAssign_Cell_Out{dtsCt,2},[800 NaN]);

    % % % figure;
    % % % imshow(Img_PxAssign_kIdx_Disp);

    % = Prepare masks of pixel assignment to dist targets of Beg, Bdc and Btb
    % Create ImgStack_PxAssign_kIdx_Temp (logical: 1 for each pixel assigned k, 0 otherwise
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT
    ImgStack_PxAssign_kIdx_Temp = zeros(size(ImgStack_gDist_Temp),'logical');
    for k = 1:size(ImgStack_PxAssign_kIdx_Temp,3)
        Img_Temp = ImgStack_PxAssign_kIdx_Temp(:,:,k);
        Img_Temp(find(abs(Img_gDistZsort_mink1_kIdx_Temp-k)<eps)) = logical(1);
        ImgStack_PxAssign_kIdx_Temp(:,:,k) = Img_Temp;
    end

    % = Reorganize Assignment Masks; store as output
    ImgStack_PxAssign_kIdx_Temp = mat2cell(ImgStack_PxAssign_kIdx_Temp,height(ImgStack_PxAssign_kIdx_Temp),width(ImgStack_PxAssign_kIdx_Temp),repmat(1,size(ImgStack_PxAssign_kIdx_Temp,3),1));
    ImgStack_PxAssign_kIdx_Temp = reshape(ImgStack_PxAssign_kIdx_Temp,[],3); % 3 Col: Beg, Bdc, Btb
    ImgStack_PxAssign_kIdx_Temp = permute(ImgStack_PxAssign_kIdx_Temp,[3 2 1]); % Distance Target (OCN, TRAP) in 3rd dimension

    Img_DistSAssign_Cell_Out{RowIdx_Temp,2} =  cell2mat(ImgStack_PxAssign_kIdx_Temp(:,1,:)); % Px Assign Mask to Beg DistTarget
    Img_DistSAssign_Cell_Out{RowIdx_Temp,3} =  cell2mat(ImgStack_PxAssign_kIdx_Temp(:,2,:)); % Px Assign Mask to Bdc DistTarget
    Img_DistSAssign_Cell_Out{RowIdx_Temp,4} =  cell2mat(ImgStack_PxAssign_kIdx_Temp(:,3,:)); % Px Assign Mask to Btb DistTarget

    % = Cluster Evaluation: quality of assignment of each dist-source blob
    % 20250305: For now: use silhouette score: compare current assignment to
    % second best (nearest neighbour) assignment.
    % Range [-1 1] (-1 = separation/bad; 1 = cohesion/good) in clustering analysis use;
    % in this code clustering is not auto and min dist assigned, thus actual
    % range [0 1]
    % Known issue: higher score for spherical cluster.
    Mtx_PxAssign_ceval_Temp = ...
        (Img_gDistZsort_mink2_Temp-Img_gDistZsort_mink1_Temp)./max(Img_gDistZsort_mink2_Temp,Img_gDistZsort_mink1_Temp);

    % = Store Quality of Assignment Map as output
    % Note: Quality score in range [-1 1] (ie, carries negative numbers)
    % % % Img_DistSAssign_Cell_Out{1,7} = single(Mtx_PxAssign_ceval_Temp); % NaN value in unassigned pixels
    % % % Img_DistSAssign_Cell_Out{2,7} = single(Mtx_PxAssign_ceval_Temp); % NaN value in unassigned pixels
    Img_DistSAssign_Cell_Out{RowIdx_Temp,7} = repmat(single(Mtx_PxAssign_ceval_Temp),1,1,NumDistT_Temp); % NaN value in unassigned pixels
    % % % Img_DistSAssign_Cell_Out{4,7} = repmat(single(Mtx_PxAssign_ceval_Temp),1,1,NumDistT_Temp); % NaN value in unassigned pixels

    % = Visual Check: Quality of Assignment:
    % Disp image also for "ImgCheck_DistSAssign_Cell_Out"
    Img_PxAssign_ceval_Disp = Mtx_PxAssign_ceval_Temp;
    Img_PxAssign_ceval_Disp(~Img_DistSAssign_Cell_Out{RowIdx_Temp,1}(:,:,1)) = -9.99; % Bin 1 = non gDist assigned pixels
    Img_PxAssign_ceval_Disp(isnan(Img_PxAssign_ceval_Disp)) = 9.99; % Bin (end) = pixel without assignment

    discretize_Edge_Temp = horzcat(-10,[-1.0:0.1:1.0],10);
    [Img_PxAssign_ceval_Disp,Edge_Temp] = discretize(Img_PxAssign_ceval_Disp,discretize_Edge_Temp);
    Img_PxAssign_ceval_Disp = Img_PxAssign_ceval_Disp-1; % shift bin label by -1 so Background (non dist-source blob pixels) = Bin 0

    % Colormap: Black for no-assignment pixels, colormap from
    % FileExchange '200 colormap'
    % (https://www.mathworks.com/matlabcentral/fileexchange/120088-200-colormap)
    % Silhouette score range [-1 1] (ie, -1 = separation, 1 = cohesion), but in
    % this code range [0 1] as min dist picked
    % Color unassigned dist-source blob pixels with dark green [0.0 0.25 0.0]
    cmap_Disp_Temp = vertcat(slanCM('plasma',numel(discretize_Edge_Temp)-3),[0.0 0.25 0.0]);
    Img_PxAssign_ceval_Disp = label2rgb(Img_PxAssign_ceval_Disp,cmap_Disp_Temp,[0 0 0]); % Display: Quality of Assignment Map (no colorbar)

    % Store as output
    ImgCheck_DistSAssign_Cell_Out{dtsCt,3} = Img_PxAssign_ceval_Disp;
    ImgCheck_DistSAssign_Cell_Out{dtsCt,3} = imresize(ImgCheck_DistSAssign_Cell_Out{dtsCt,3},[800 NaN]);

    % Add colorbar while preserving size of display image
    close all;
    iptsetpref("ImshowBorder","loose");
    FigHandle = figure('Visible','off'); % do NOT hold on here
    ax1 = axes(FigHandle);
    imshow(Img_PxAssign_ceval_Disp,'Parent',ax1);
    axis off
    axis equal

    ax2 = axes(FigHandle,'Position',[ax1.Position(1)+ax1.Position(3),ax1.Position(2),0.7,0.7]);
    hold on; axis off;  % hold on here
    set(ax2,'color','none');
    colormap(cmap_Disp_Temp(1:(end-1),:))
    ax2.CLim = [0.0 1.0];
    cb_Temp = colorbar(ax2,'Position',[ax1.Position(1)+ax1.Position(3)+0.005,ax1.Position(2),0.01,0.9],'AxisLocation','in');
    cb_Temp.Limits = [-1.0 1.0];
    cb_Temp.Ticks = discretize_Edge_Temp(2:(end-1));
    cb_Temp.TickDirection = 'out';
    hold off;

    Img_PxAssign_ceval_cb_Disp = print('-RGBImage'); % current FigHandle; Display: Quality of Assignment Map (w/ colorbar)

    % Store as output
    ImgCheck_DistSAssign_Cell_Out{dtsCt,4} = Img_PxAssign_ceval_cb_Disp;
    ImgCheck_DistSAssign_Cell_Out{dtsCt,4} = imresize(ImgCheck_DistSAssign_Cell_Out{dtsCt,4},[800 NaN]);

end

close all;
clearvars *_Temp *_Disp;


%% === Assignment for Dist-Source (Ebf3) Blobs

%% Row 3-4, Col 11:  Logical Map, all Dist-Source blobs receiving DistT assignment based on final output mask from bwdistgeodesic()

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    %  = Store as output
    Img_DistSAssign_Cell_Out{RowIdx_Temp,11} = repmat(Img_DistS_Cell_In{2,5},1,1,NumDistT_Temp);

    %  = Store as output, ImgCheck
    ImgCheck_DistSAssign_Cell_Out{dtsCt,11} = Img_DistS_Cell_In{2,5};
    ImgCheck_DistSAssign_Cell_Out{dtsCt,11} = imresize(ImgCheck_DistSAssign_Cell_Out{dtsCt,11},[800 NaN]);

end

clearvars *_Temp *Disp* dtsCt;


%% Row 3-4, Col 12-14:  Assignment Masks by Dist-Source Blob, all blobs receiving DistT assignment
% + Col 15:  Assignment Label Map by Dist-Source Blob, all blobs receiving DistT assignment
% + Col 17:  Assignment Quality Map by Dist-Source Blob, all blobs receiving DistT assignment

% Assign each Dist-Source blob to Distance Target (@ Beg or Bdc or BTb) with minimum mean gDist.

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Create ImgStack_gDist_Temp: z-stack of all gDistMap
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT
    ImgStack_gDist_Temp = cell2mat(permute(Img_gDistMap_Cell_In(RowIdx_Temp,1:3),[1 3 2]));
    ImgStack_gDist_Temp(repmat(~Img_DistSAssign_Cell_Out{RowIdx_Temp,1},1,1,3)) = NaN; % repeat 3 times for Beg, Bdc. Btb

    % = Get pixel intensity=gDist values and pixel location of each Dist source blob
    % Note: cannot do "MeanIntensity" as a single NaN value within the blob
    % will cause measurement to be NaN
    rp_dS_kCell_Temp = cell(1,1,size(ImgStack_gDist_Temp,3));
    for k=1:size(ImgStack_gDist_Temp,3)
        rp_dS_kCell_Temp{1,1,k} = regionprops(Img_DistS_Cell_In{2,5},ImgStack_gDist_Temp(:,:,k),'PixelValues','PixelIdxList');
    end

    % = Assignment
    % Matrix "dS_MeanDist_Temp" is of size (# k values) x (# distance-source
    % blobs) x 3. Load plane 1 of this matrix with mean distance value, calculated after
    % removing NaN pixels. Record the number of in-blob pixels after and before NaN
    % removal in plane 2 and plane 3; too low plane 2 values or plane2/plane 3 values for each blob
    % will disqualify the blob from assignment
    dS_MeanDist_Temp = zeros(size(ImgStack_gDist_Temp,3),NumDistSBlob,3,'single');
    for dSbCt = 1:NumDistSBlob % Dist-Source Blob Ct
        PixelIdxList_Temp = rp_dS_kCell_Temp{1,1,1}(dSbCt).PixelIdxList; % Same for all k
        FlagID_NaN_Temp = ismember(PixelIdxList_Temp,find(Img_gDistMap_Cell_In{RowIdx_Temp,5}(:,:,1)));
        for k=1:size(ImgStack_gDist_Temp,3)
            PxVal_Temp = rp_dS_kCell_Temp{1,1,k}(dSbCt).PixelValues;
            dS_MeanDist_Temp(k,dSbCt,3) = numel(PxVal_Temp); % # in blob intensity (=gDist) values, NaN or non-NaN
            PxVal_Temp(FlagID_NaN_Temp) = []; % Remove NaN values
            dS_MeanDist_Temp(k,dSbCt,1) = mean(PxVal_Temp,'all'); % mean intensity (=gDist) value after NaN values removal
            dS_MeanDist_Temp(k,dSbCt,2) = numel(PxVal_Temp); % # in blob, Non-NaN Intensity (=gDist) values used for mean calculation
        end
    end

    % Assign to kIdx (each corresponding to a DistTarget @ Meg or Bdc or Btb) by lowest mean intensity for each dist-source blob
    % Note: some dist-source blobs have NaN as mean intensity (=gDist) value,
    % if they colocalize entirely with forbidden pixels in gDist maps. kIdx
    % assignment of these blobs by sort() must be manually removed, by locating
    % NaN values in min gDist value
    [dS_MeanDist_sort_Temp,dS_MeanDist_sort_kIdx_Temp] = sort(dS_MeanDist_Temp,1,'ascend'); % sort to find lowest mean intensity = gDist value and corresponding kIdx

    dS_MeanDist_mink1_Temp = dS_MeanDist_sort_Temp(1,:,1); % min gDist values corresponding to assigned kIdx (with NaN values)

    dS_MeanDist_mink1_kIdx_Temp = dS_MeanDist_sort_kIdx_Temp(1,:,1); % Assignment of each Dist-Source Blob (No NaN values)
    dS_MeanDist_mink1_kIdx_Temp(isnan(dS_MeanDist_mink1_Temp)) = NaN; % Must do

    % = Cluster Evaluation: quality of assignment of each dist-source blob
    % 20250305: For now: use silhouette score: compare current assignment to
    % second best (nearest neighbour) assignment.
    % Range [-1 1] (-1 = separation/bad; 1 = cohesion/good) in clustering analysis use;
    % in this code clustering is not auto and min dist assigned, thus actual
    % range [0 1]
    % Known issue: higher score for spherical cluster.
    dSAssign_ceval_Temp = ...
        (dS_MeanDist_sort_Temp(2,:,1)-dS_MeanDist_mink1_Temp)./max(dS_MeanDist_sort_Temp(2,:,1),dS_MeanDist_mink1_Temp);

    % = Flag for removing assignment of blobs based on # pixels involved in assignment
    % Too small number of pixels, or most of in-blob pixels are forbidden
    % pixels from bwdistgeodesic()
    FlagID_Occ_Temp = (dS_MeanDist_sort_Temp(1,:,2)<4) | (dS_MeanDist_sort_Temp(1,:,2)./dS_MeanDist_sort_Temp(1,:,3)<0.10);
    dS_MeanDist_mink1_Temp(FlagID_Occ_Temp) = NaN;
    dS_MeanDist_mink1_kIdx_Temp(FlagID_Occ_Temp) = NaN; % Assignment of each Dist-Source Blob
    dSAssign_ceval_Temp(FlagID_Occ_Temp) = NaN; % Quality of assignment of each Dist-Source Blob

    % = Build Dist-Source Blobs' Assignment Label Map ("Img_dS_kAssign_Temp"), mean-gDist Map,
    % and Assignment Quality Map
    rp_dS_Temp = regionprops(Img_DistS_Cell_In{2,5},'PixelIdxList');
    Img_dSAssign_kIdx_Temp = zeros(size(Img_DistS_Cell_In{2,5}),'uint16');
    Mtx_dSAssign_Dist_Temp = nan(size(Img_DistS_Cell_In{2,5}),'single'); % Range [0 Inf]
    Mtx_dSAssign_ceval_Temp = nan(size(Img_DistS_Cell_In{2,5}),'single'); % Score range [-1 1]; range in this application: [0 1]
    for dSbCt = 1:NumDistSBlob % Dist-Source Blob Ct
        if ~isnan(dS_MeanDist_mink1_kIdx_Temp(dSbCt))
            Img_dSAssign_kIdx_Temp(rp_dS_Temp(dSbCt).PixelIdxList) = dS_MeanDist_mink1_kIdx_Temp(dSbCt);
            Mtx_dSAssign_Dist_Temp(rp_dS_Temp(dSbCt).PixelIdxList) = dS_MeanDist_mink1_Temp(dSbCt);
            Mtx_dSAssign_ceval_Temp(rp_dS_Temp(dSbCt).PixelIdxList) = dSAssign_ceval_Temp(dSbCt);
        end
    end

    % = Prepare masks of Dist-Source Blobs' Assignment to dist targets of Beg, Bdc and Btb
    % Create ImgStack_dSAssign_kIdx_Temp (logical: 1 for each pixel assigned k, 0 otherwise
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT
    ImgStack_dSAssign_kIdx_Temp = zeros(size(ImgStack_gDist_Temp),'logical');
    for k = 1:size(ImgStack_dSAssign_kIdx_Temp,3)
        Img_Temp = ImgStack_dSAssign_kIdx_Temp(:,:,k);
        Img_Temp(find(abs(single(Img_dSAssign_kIdx_Temp)-k)<eps)) = logical(1);
        ImgStack_dSAssign_kIdx_Temp(:,:,k) = Img_Temp;
    end

    % Reorganize Assignment Masks; store as output
    ImgStack_dSAssign_kIdx_Temp = mat2cell(ImgStack_dSAssign_kIdx_Temp,height(ImgStack_dSAssign_kIdx_Temp),width(ImgStack_dSAssign_kIdx_Temp),repmat(1,size(ImgStack_dSAssign_kIdx_Temp,3),1));
    ImgStack_dSAssign_kIdx_Temp = reshape(ImgStack_dSAssign_kIdx_Temp,[],3); % 3 Col: Beg, Bdc, Btb
    ImgStack_dSAssign_kIdx_Temp = permute(ImgStack_dSAssign_kIdx_Temp,[3 2 1]); % Distance Target (OCN, TRAP) in 3rd dimension

    Img_DistSAssign_Cell_Out{RowIdx_Temp,12} =  cell2mat(ImgStack_dSAssign_kIdx_Temp(:,1,:)); % Dist-source Assign Mask to Beg DistTarget
    Img_DistSAssign_Cell_Out{RowIdx_Temp,13} =  cell2mat(ImgStack_dSAssign_kIdx_Temp(:,2,:)); % Dist-source Assign Mask to Bdc DistTarget
    Img_DistSAssign_Cell_Out{RowIdx_Temp,14} =  cell2mat(ImgStack_dSAssign_kIdx_Temp(:,3,:)); % Dist-source Assign Mask to Btb DistTarget

    % = Store Assignment Label Map as output
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT
    Img_DistSAssign_Cell_Out{RowIdx_Temp,15} = repmat(uint16(Img_dSAssign_kIdx_Temp),1,1,NumDistT_Temp);

    % = Store gDist Map used for assignment as output
    % Note: range [0 Inf]
    Img_DistSAssign_Cell_Out{RowIdx_Temp,16} = repmat(single(Mtx_dSAssign_Dist_Temp),1,1,NumDistT_Temp); % NaN value in unassigned pixels

    % = Store Quality of Assignment Map as output
    % Note: Quality score in range [-1 1] (ie, carries negative numbers)
    Img_DistSAssign_Cell_Out{RowIdx_Temp,17} = repmat(single(Mtx_dSAssign_ceval_Temp),1,1,NumDistT_Temp); % NaN value in unassigned pixels

    % = Visual Check: Assignment Label
    % Disp image also for "ImgCheck_DistSAssign_Cell_Out"
    Img_dSAssign_kIdx_Temp_Disp = Img_dSAssign_kIdx_Temp;
    cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
    cmap_Disp_Temp = vertcat(...
        [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
        [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
        [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
        );
    Img_dSAssign_kIdx_Disp = label2rgb(Img_dSAssign_kIdx_Temp,cmap_Disp_Temp,[0 0 0]);
    ImgCheck_DistSAssign_Cell_Out{dtsCt,12} = Img_dSAssign_kIdx_Disp; % Store in output
    ImgCheck_DistSAssign_Cell_Out{dtsCt,12} = imresize(ImgCheck_DistSAssign_Cell_Out{dtsCt,12},[800 NaN]);

    % = Visual Check: Quality of Assignment:
    % Disp image also for "ImgCheck_DistSAssign_Cell_Out"
    Img_dSAssign_ceval_Disp = Mtx_dSAssign_ceval_Temp;
    Img_dSAssign_ceval_Disp(~Img_DistSAssign_Cell_Out{RowIdx_Temp,11}(:,:,1)) = -9.99; % Bin 1 = non dist-source blob pixels
    Img_dSAssign_ceval_Disp(isnan(Img_dSAssign_ceval_Disp)) = 9.99; % Bin (end) = dist-source blob without assignment

    discretize_Edge_Temp = horzcat(-10,[-1.0:0.1:1.0],10);
    [Img_dSAssign_ceval_Disp,Edge_Temp] = discretize(Img_dSAssign_ceval_Disp,discretize_Edge_Temp);
    Img_dSAssign_ceval_Disp = Img_dSAssign_ceval_Disp-1; % shift bin label by -1 so Background (non dist-source blob pixels) = Bin 0

    % Colormap: Black for no-assignment pixels, colormap from
    % FileExchange '200 colormap'
    % (https://www.mathworks.com/matlabcentral/fileexchange/120088-200-colormap)
    % Silhouette score range [-1 1] (ie, -1 = separation, 1 = cohesion), but in
    % this code range [0 1] as min dist picked
    % Color unassigned dist-source blob pixels with dark green [0.0 0.25 0.0]
    cmap_Disp_Temp = vertcat(slanCM('plasma',numel(discretize_Edge_Temp)-3),[0.0 0.25 0.0]);
    Img_dSAssign_ceval_Disp = label2rgb(Img_dSAssign_ceval_Disp,cmap_Disp_Temp,[0 0 0]); % Display: Quality of Assignment Map (no colorbar)

    % Store as output
    ImgCheck_DistSAssign_Cell_Out{dtsCt,13} = Img_dSAssign_ceval_Disp;
    ImgCheck_DistSAssign_Cell_Out{dtsCt,13} = imresize(ImgCheck_DistSAssign_Cell_Out{dtsCt,13},[800 NaN]);

    % Add colorbar while preserving size of display image
    close all;
    iptsetpref("ImshowBorder","loose");
    FigHandle = figure('Visible','off'); % do NOT hold on here
    ax1 = axes(FigHandle);
    imshow(Img_dSAssign_ceval_Disp,'Parent',ax1);
    axis off
    axis equal

    ax2 = axes(FigHandle,'Position',[ax1.Position(1)+ax1.Position(3),ax1.Position(2),0.7,0.7]);
    hold on; axis off;  % hold on here
    set(ax2,'color','none');
    colormap(cmap_Disp_Temp(1:(end-1),:))
    ax2.CLim = [0.0 1.0];
    cb_Temp = colorbar(ax2,'Position',[ax1.Position(1)+ax1.Position(3)+0.005,ax1.Position(2),0.01,0.9],'AxisLocation','in');
    cb_Temp.Limits = [-1.0 1.0];
    cb_Temp.Ticks = discretize_Edge_Temp(2:(end-1));
    cb_Temp.TickDirection = 'out';
    hold off;

    Img_dSAssign_ceval_cb_Disp = print('-RGBImage'); % current FigHandle; Display: Quality of Assignment Map (w/ colorbar)

    % Store as output
    ImgCheck_DistSAssign_Cell_Out{dtsCt,14} = Img_dSAssign_ceval_cb_Disp;
    ImgCheck_DistSAssign_Cell_Out{dtsCt,14} = imresize(ImgCheck_DistSAssign_Cell_Out{dtsCt,14},[800 NaN]);

end

close all;
clearvars *_Temp *_Disp* FigHandle* ax*;


