function [Img_DistS_Cell_Out,ImgCheck_DistS_Cell_Out] = fDefineDistSourceEbf3(Img_MrwDef_Cell_In,Img_Begdc_Cell_In,Img_Btb_Cell_In,Img_DistT_Cell_In,UI_In)

close all;

%%

% % % NumDistT = size(Img_DistT_Cell_In{3,1},3); % Number of distance target (OCN, TRAP etc)
% % % NumDistTbf = 1; % Number of "hypothetical" bone front staining = 1

% = Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)
Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;


%% Prepare Output Cells

% = Img_DistS_Cell 

Img_DistS_Cell_Out = cell(3,5);

% Img of assignment of distance-target blobs to different bone (eg, dc, tb). Cell of size(3,4):
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Single; Img of Distance-Source, Background corrected (Row 2: Distance Source)
% * Col02 = Logical; Img of Distance-Source, Background corrected (Row 2: Distance Source)
% * Col03 = Logical; Exclusion Mask of Distance-Source based on size and morphlogy (Row 2: Distance Source)
% * Col04 = Single; Img of Distance-Source, Background corrected and size+morphlogy excluded (Row 2: Distance Source)
% * Col05 = Logical; Img of Distance-Source, Background corrected and size+morphlogy excluded (Row 2: Distance Source)
% * Col06 = Logical; Img of Non-trabecular bone marrow holes that are likely tears from biopsy preparation (Row 1)


% = ImgCheck_DistS_Cell 

ImgCheck_DistS_Cell_Out = cell(1,1);

% 1 Row; Columns:
% * Col01 = Colocalized Img (single), Img_Mrw w/ bone + distance-target @ Beg, Bdc and Btb (pre distance source assignment check)
% * Col02 = Colocalized Img, logical mask of Non-trabecular bone marrow holes w/ Img_Btb_Mask, Img_MrwMask (Sm or not)



%% Load previously created images

% Load Img_Mrw for Distance Source (Ebf3) 
Img_m = Img_MrwDef_Cell_In{2,6}; % Img_Mrw; single (not mask)

% Load Bone Edge Region Masks
if ~UI_In.MrwMask_SmOption
    Img_Beg_Mask = Img_Begdc_Cell_In{1,5}; % logical
    Img_Bdc_Mask = Img_Begdc_Cell_In{1,6}; % logical
else
    Img_Beg_Mask = Img_Begdc_Cell_In{1,7}; % logical
    Img_Bdc_Mask = Img_Begdc_Cell_In{1,8}; % logical
end

% Load Trabecular Bone Masks
Img_Btb_Mask = Img_Btb_Cell_In{1,1}; % logical

% Load Distance-Target Mask
% Zmax to Include all distance targets
Img_dtZeg_Mask = max(Img_DistT_Cell_In{3,1},[],3); % logical
Img_dtZdc_Mask = max(Img_DistT_Cell_In{3,2},[],3); % logical
Img_dtZtb_Mask = max(Img_DistT_Cell_In{3,3},[],3); % logical

% Visual Check Preloaded Information, pre-Assignment; store in output
Img_Begdctb_Disp = horzcat(...
    imfuse(0.667*single(Img_Beg_Mask),Img_m,'Scaling','none','ColorChannels',[1 2 0]),...
    imfuse(0.667*single(Img_Bdc_Mask),Img_m,'Scaling','none','ColorChannels',[1 2 0]),...
    imfuse(0.667*single(Img_Btb_Mask),Img_m,'Scaling','none','ColorChannels',[1 2 0]),...
    imfuse(0.667*single((Img_Beg_Mask | Img_Bdc_Mask | Img_Btb_Mask)),Img_m,'Scaling','none','ColorChannels',[1 2 0]),...
    cat(3,255.*single(Img_Btb_Mask),255.*single(Img_Bdc_Mask),255.*single(Img_Beg_Mask)));
Img_dtZegdctb_Disp = horzcat(...
    imfuse(0.667*single(Img_dtZeg_Mask),Img_m,'Scaling','none','ColorChannels',[1 2 0]),...
    imfuse(0.667*single(Img_dtZdc_Mask),Img_m,'Scaling','none','ColorChannels',[1 2 0]),...
    imfuse(0.667*single(Img_dtZtb_Mask),Img_m,'Scaling','none','ColorChannels',[1 2 0]),...
    imfuse(0.667*single((Img_dtZeg_Mask | Img_dtZdc_Mask | Img_dtZtb_Mask)),Img_m,'Scaling','none','ColorChannels',[1 2 0]),...
    cat(3,255.*single(Img_dtZtb_Mask),255.*single(Img_dtZdc_Mask),255.*single(Img_dtZeg_Mask)));
Img_Disp = vertcat(Img_Begdctb_Disp,Img_dtZegdctb_Disp);
imresize(Img_Disp,[800*2 NaN]);

% % % figure;
% % % imshow(Img_Disp);

ImgCheck_DistS_Cell_Out{1,1} = Img_Disp;

close all;
clearvars *Temp *Disp *Ct;


%% Create Morphological-Outlier Mask 
% Dist-Source (Ebf3) Cells outside mask near bone front are excluded from
% morphlogical-outlier calculation 

% "Img_Morph_Mask" keeps Mrw region used for determining limits of
% morphlogical measurements to be kept. 
% NOTE: Rough Mask. Do not use for precise measurement.
Img_m_Mph_Mask = ... 
    (Img_Beg_Mask | Img_Bdc_Mask) | ... % No imdilate needed (Bone Edge Region Mask; already dilated)
    imdilate((Img_dtZeg_Mask | Img_dtZdc_Mask),strel('disk',round(3.0*Ebf3Sz_ulim_px))) | ... % Dilate to make sure all flat distance targets excluded
    imdilate((Img_Btb_Mask | Img_dtZtb_Mask),strel('disk',round(3.0*Ebf3Sz_ulim_px)));

Img_m_Mph_Mask = ~Img_m_Mph_Mask;

clearvars *Temp *Disp *Ct;


%% STEP00: Create Prelim Img: Dist-Source's Img_Mrw with Background Correction

Img_ds_Temp = Img_m; % Input for this section; single

Img_ds_BW_Temp = Img_ds_Temp.*single(Img_m_Mph_Mask); % Single; only consider Mrw regions far away bone fronts and distance targets
Img_ds_Bkgd_Temp = Img_ds_Temp; % Single; will be used to estimate background

% = Mask for removing bright values from background correction
[thresh_Temp,~] = multithresh(Img_ds_Temp(Img_ds_Temp>0),1);
Img_ds_BW_Temp = imbinarize(Img_ds_Temp,thresh_Temp); % logical

% = Calculate Background
Img_Bkgd_Cell_Temp = cell(3,2); % for "for-loop" data loading
for iCt = 1:5 % iterations
    if iCt<2
        Img_Bkgd_Cell{1,1} = zeros(size(Img_ds_Temp),'single');
        Img_Bkgd_Cell{2,1} = Img_ds_Bkgd_Temp.*single(~Img_ds_BW_Temp); % Remove bright values 
    else
        Img_Bkgd_Cell{1,1} = Img_Bkgd_Cell{2,1}; % Shift 1 row up
        Img_Bkgd_Cell{2,1} = Img_Bkgd_Cell{3,1};
    end
    Img_Bkgd_Cell{2,2} = imgaussfilt(Img_Bkgd_Cell{2,1},16); % future background image
    Img_Bkgd_Cell{3,1} = Img_Bkgd_Cell{2,1}; % Prepare for update
    if iCt<2
        Img_Bkgd_Cell{3,1}(Img_Bkgd_Cell{2,1}<eps) = Img_Bkgd_Cell{2,2}(Img_Bkgd_Cell{2,1}<eps);
    else
        Img_Bkgd_Cell{3,1}((Img_Bkgd_Cell{2,1}-Img_Bkgd_Cell{1,1})>0.05) = Img_Bkgd_Cell{2,2}((Img_Bkgd_Cell{2,1}-Img_Bkgd_Cell{1,1})>0.05);
    end
end

% Background correction
Img_ds_Temp = Img_ds_Temp-Img_Bkgd_Cell{2,2}; % update
Img_ds_Temp(Img_ds_Temp<0) = 0;
Img_ds_Prelim = Img_ds_Temp; % Single; includes eg,dc,tb blobs

% Prelim Mask
Img_ds_Temp = Img_ds_Temp.*single(Img_m_Mph_Mask); 
[thresh_Temp,~] = multithresh(Img_ds_Temp(Img_ds_Temp>0),1); 
Img_ds_BW_Temp = imbinarize(Img_ds_Prelim,thresh_Temp); % update
Img_ds_BW_Prelim = Img_ds_BW_Temp; % Logical; includes eg,dc,tb blobs

% = Store output in "Img_DistS_Cell" 
Img_DistS_Cell_Out{2,1} = Img_ds_Prelim;
Img_DistS_Cell_Out{2,2} = Img_ds_BW_Prelim;

% % % figure;
% % % imshowpair(Img_m.*single(Img_m_Mph_Mask),Img_ds_Prelim.*single(Img_m_Mph_Mask),'ColorChannels',[1 2 0]);

clearvars *Temp *Disp *Ct;


%% STEP01: Create Exclusion Mask for Dist-Source's Img_Mrw based on size
% SzExc_Mask is used to exclude very small (non near-whole cell) blobs that affects area and
% FeretDiameterRatio statistics

Img_ds_BW_Temp = Img_ds_BW_Prelim; % Input for this section; logical

rp_ds_Temp = regionprops(Img_ds_BW_Temp,'MinFeretProperties','MaxFeretProperties','PixelIdxList');
FlagID_ds_MinFeretDiameter_Temp = ~(cat(1,rp_ds_Temp.MinFeretDiameter)<0.60*Ebf3Sz_llim_px);
FlagID_ds_MaxFeretDiameter_Temp = ~(cat(1,rp_ds_Temp.MaxFeretDiameter)<0.80*Ebf3Sz_llim_px);
FlagID_ds_Temp = FlagID_ds_MinFeretDiameter_Temp & FlagID_ds_MaxFeretDiameter_Temp;
rp_ds_Temp(FlagID_ds_Temp) = [];

Img_ds_SzExc_Mask = zeros(size(Img_ds_BW_Temp),'logical');
Img_ds_SzExc_Mask(cat(1,rp_ds_Temp.PixelIdxList)) = 1;

% % % figure; 
% % % imshowpair(0.667*Img_ds_SzExc_Mask,Img_m,'Scaling','none','ColorChannels',[1 2 0]);

clearvars *Temp *Disp *Ct;


%% STEP02: Create Exclusion Mask for Dist-Source's Img_Mrw based on Morphological statistics
% Only consider blobs (Ebf3) not too small and not too away from bone front
% to calculate ulim, llim

Img_ds_BW_Temp = Img_ds_BW_Prelim; % Input for this section; logical

% = Calculate morphlogy statistics ulim, llim
% % % Img2_ds_BW_Temp = Img_ds_BW_Temp & Img_m_Mph_Mask & ~Img_ds_SzExc_Mask; % restrict region to consider 
Img2_ds_BW_Temp = Img_ds_BW_Temp & Img_m_Mph_Mask & ~Img_ds_SzExc_Mask; % restrict region to consider

rp2_ds_Temp = regionprops(Img2_ds_BW_Temp,'Area','MinFeretProperties','MaxFeretProperties','PixelIdxList');
rp2_ds_Area_Temp = cat(1,rp2_ds_Temp.Area);
rp2_ds_FeretDiameterRatio_Temp = cat(1,rp2_ds_Temp.MaxFeretDiameter)./cat(1,rp2_ds_Temp.MinFeretDiameter);
rp2_ds_Area_uLim_Temp = ...
    median(rp2_ds_Area_Temp,"all")+3.0*1.4826*mad(rp2_ds_Area_Temp,[],'all');
rp2_ds_FeretDiameterRatio_uLim_Temp = ...
    median(rp2_ds_FeretDiameterRatio_Temp,"all") + 3.0*1.4826*mad(rp2_ds_FeretDiameterRatio_Temp,[],'all');

% = Clean up blobs (Ebf3) in un-restricted image
% % % rp_ds_Temp = regionprops(Img_ds_BW_Temp,'Area','MinFeretProperties','MaxFeretProperties','PixelIdxList');
rp_ds_Temp = regionprops(Img2_ds_BW_Temp,'Area','MinFeretProperties','MaxFeretProperties','PixelIdxList'); % Also use restricted region
rp_ds_Area_Temp = cat(1,rp_ds_Temp.Area);
rp_ds_FeretDiameterRatio_Temp = cat(1,rp_ds_Temp.MaxFeretDiameter)./cat(1,rp_ds_Temp.MinFeretDiameter);
KeepID_ds_Temp = ...
    (rp_ds_Area_Temp>rp2_ds_Area_uLim_Temp) | ...
    (rp_ds_FeretDiameterRatio_Temp>rp2_ds_FeretDiameterRatio_uLim_Temp);
FlagID_ds_Temp = ~KeepID_ds_Temp;
rp_ds_Temp(FlagID_ds_Temp) = [];

Img_ds_MphExc_Mask = zeros(size(Img_ds_BW_Temp),'logical');
Img_ds_MphExc_Mask(cat(1,rp_ds_Temp.PixelIdxList)) = 1;

% = Store output in "Img_DistS_Cell" 
Img_DistS_Cell_Out{2,3} = (Img_ds_SzExc_Mask | Img_ds_MphExc_Mask);

% % % figure; 
% % % Img_ds_Exc_Mask_Disp = (Img_ds_SzExc_Mask | Img_ds_MphExc_Mask);
% % % Img_Disp = imfuse(0.667*single(Img_ds_Exc_Mask_Disp),Img_m,'Scaling','none','ColorChannels',[1 2 0]);
% % % imshow(Img_Disp);

clearvars *Temp *Disp *Ct;


%% STEP03: Finalize Img_ds, background corrected and size+morphology excluded

Img_ds = Img_ds_Prelim.*single(~(Img_ds_SzExc_Mask | Img_ds_MphExc_Mask));
Img_ds_BW = Img_ds_BW_Prelim & ~(Img_ds_SzExc_Mask | Img_ds_MphExc_Mask);

% = Fill holes smaller than average Ebf3 cell size
Img_ds_BW = ~bwareaopen(~Img_ds_BW, round(pi*(0.5*0.5*(Ebf3Sz_ulim_px+Ebf3Sz_llim_px)).^2)); % Update
Img_ds = Img_ds_Prelim.*Img_ds_BW; % Update

% = 20250521: Cut blobs crossing into Beg
if ~UI_In.MrwMask_SmOption % Not smoothed MrwMask
    Img_Beg_Temp = Img_Begdc_Cell_In{1,5}; % Region Mask
else % Smoothed MrwMask
    Img_Beg_Temp = Img_Begdc_Cell_In{1,7}; % Region Mask
end
RC_Beg_Edge_Temp = bwboundaries(Img_Beg_Temp,'noholes');
RC_Beg_Edge_Temp = cell2mat(RC_Beg_Edge_Temp);
LinIdx_Beg_Edge_Temp = sub2ind(size(Img_Beg_Temp),RC_Beg_Edge_Temp(:,1),RC_Beg_Edge_Temp(:,2)); 
Img_Beg_Edge_Temp = zeros(size(Img_Beg_Temp),'logical');
Img_Beg_Edge_Temp(LinIdx_Beg_Edge_Temp) = 1;
Img_Beg_Edge_Temp = imdilate(Img_Beg_Edge_Temp,strel('disk',1));

Img_ds_BW = logical(Img_ds_BW & ~Img_Beg_Edge_Temp); % Update
Img_ds = Img_ds.*Img_ds_BW; % Update

% = 20250521: Cut blobs crossing into Bdc
if ~UI_In.MrwMask_SmOption % Not smoothed MrwMask
    Img_Bdc_Temp = Img_Begdc_Cell_In{1,6}; % Region Mask
else % Smoothed MrwMask
    Img_Bdc_Temp = Img_Begdc_Cell_In{1,8}; % Region Mask
end
RC_Bdc_Edge_Temp = bwboundaries(Img_Bdc_Temp,'noholes');
RC_Bdc_Edge_Temp = cell2mat(RC_Bdc_Edge_Temp);
LinIdx_Bdc_Edge_Temp = sub2ind(size(Img_Bdc_Temp),RC_Bdc_Edge_Temp(:,1),RC_Bdc_Edge_Temp(:,2)); 
Img_Bdc_Edge_Temp = zeros(size(Img_Bdc_Temp),'logical');
Img_Bdc_Edge_Temp(LinIdx_Bdc_Edge_Temp) = 1;
Img_Bdc_Edge_Temp = imdilate(Img_Bdc_Edge_Temp,strel('disk',1));

Img_ds_BW = logical(Img_ds_BW & ~Img_Bdc_Edge_Temp); % Update
Img_ds = Img_ds.*Img_ds_BW; % Update

% = Store output in "Img_DistS_Cell" 
Img_DistS_Cell_Out{2,4} = Img_ds;
Img_DistS_Cell_Out{2,5} = Img_ds_BW;

% % % figure;
% % % imshow(Img_ds_BW)

close all;


%% STEP04: Img of Non-Trabecular Bone Marrow Holes
% Likely holes from biopsy slice preparation
% Will be used for data plotting

Img_PxHistExclude_Mask_Temp = ...
    Img_MrwDef_Cell_In{1,5} & ... % Marrow hole (trabecular bone + non-trabecular bone tears mask)
    ~and(Img_MrwDef_Cell_In{1,5},Img_DistS_Cell_Out{2,5}) & ... % remove intersection, dist-source blobs (Ebf3) and marrow holes
    ~Img_Btb_Cell_In{1,1}; % Remove trabecular bone

% = Store in output
Img_DistS_Cell_Out{1,6} = Img_PxHistExclude_Mask_Temp;

% = Prepare display image; store in ImgCheck output
if UI_In.MrwMask_SmOption==0
    Img_MrwMask_Temp = Img_MrwDef_Cell_In{1,1};
elseif UI.MrwMask_SmOption==1
    Img_MrwMask_Temp = Img_MrwDef_Cell_In{1,3};
end

Img_PxHistExclude_Mask_Disp = cat(3,...
    addborder(single(Img_PxHistExclude_Mask_Temp),2,[1],'inner'), ... % R channel: non-Btb tear holes, no k assigned region
    addborder(single(Img_Btb_Cell_In{1,1}),2,[1],'inner'), ... % G channel: trabecular bone (Btb)
    addborder(single(Img_MrwMask_Temp),2,[1],'inner'));
% % % figure; imshow(Img_PxHistExclude_Mask_Disp);

ImgCheck_DistS_Cell_Out{1,2} = Img_PxHistExclude_Mask_Disp;

clearvars *Temp *Disp;
close all;