% 20250308: Adjusted (Final) Pixel Masks and DistSource Masks for Plotting
% * Dist-source blobs are assigned  a single distance-target. Adjust PxAssign so
% pixels are assigned to same distance-target
% * Create masks for cases of i) ignore quality of assignment (cluster evaluation)
% score and ii) consider quality of assingment (cluster evaulation) score

function [Img_dSAssignAdj_Cell_Out, ImgCheck_dSAssignAdj_Cell_Out] = fAdjustdSAssignEbf3(Img_DistSAssign_Cell_In,UI_In)


%% Prepare Output
% Continuation of fAssignDistSourceEbf3() 

% = "Img_dSAssignAdj_Cell_Out"

Img_dSAssignAdj_Cell_Out = cell(4,40,2);

% Adjusted Assignment of each pixel and each Dist-Source-Blob (Ebf3) (with gDist measurement to) different distance-targets @ different bone fronts (eg, dc, tb). 
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Quality of Assignment KEEP Mask by *pixel* (logical)  (Row 3,4)
% * Col02 = Quality of Assignment REJECT Mask by *pixel* (logical)  (Row 3,4)
% * Col03 = Adjusted (Final) Assignment Mask by *pixel* (single), to dist-Target @ epiphysis-growth plate (Beg) (Row 3,4)
% * Col04 = Adjusted (Final) Assignment Mask by *pixel* (single), to dist-Target @ diaphysis-cortical bone (Bdc) (Row 3,4)
% * Col05 = Adjusted (Final) Assignment Mask by *pixel* (single), to dist-Target @ trabecular bone (Btb) (Row 3,4)
% * Col06-20 (empty)

% * Col21 = Quality of Assignment KEEP Mask by *dist-Source Blob* (logical)  (Row 3,4)
% * Col22 = Quality of Assignment REJECT Mask by *dist-Source Blob* (logical)  (Row 3,4)
% * Col23 = Adjusted (Final) Assignment Mask by *dist-souce blob* (single), to dist-Target @ epiphysis-growth plate (Beg) (Row 3,4)
% * Col24 = Adjusted (Final) Assignment Mask by *dist-souce blob* (single), to dist-Target @ diaphysis-cortical bone (Bdc) (Row 3,4)
% * Col25 = Adjusted (Final) Assignment Mask by *dist-souce blob* (single), to dist-Target @ trabecular bone (Btb) (Row 3,4)
% * Col26-40 (empty)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = "ImgCheck_dSAssignAdj_Cell_Out"

ImgCheck_dSAssignAdj_Cell_Out = cell(2,1,2);

% 2 Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Adjusted (Final) assignment of pixels (left) and dist-source blobs (right) tp dist-Target
% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)



%%

NumDistT_Mtx = [...
    size(Img_DistSAssign_Cell_In{3,2},3); ... % Number of distance target (OCN, TRAP etc); = NumDistT (Row 3)
    size(Img_DistSAssign_Cell_In{4,2},3)... % Number of "hypothetical" bone front staining = 1 = NumDistTbf (Row 4)
    ];

% = Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)
Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;

% = Quality of Assignment: Ignore only vs Ignore+Consider
if UI_In.dSAssignQOption==[1 0]
    Numq = 1;
elseif UI_In.dSAssignQOption==[1 1]
    Numq = 2;
end


%% Prepare Quality Score (cluster evaluation) Masks for pixel and distance-source (Ebf3) assignment 

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Pixel Assignment
    % Create Img_Px_QSMask_Temp (single; same for all k):
    % From Mtx_Px_QS_Temp =  Mtx of quality of dist-Source assignment score; theoretical range [-1 1];
    % actual range [0 1]; NaN for unassigned pixels
    Mtx_Px_QS_Temp = Img_DistSAssign_Cell_In{RowIdx_Temp,7}(:,:,1);
    Img_Px_QHi_Mask_Temp = zeros(size(Mtx_Px_QS_Temp),'logical');
    Img_Px_QHi_Mask_Temp(le(Mtx_Px_QS_Temp,UI_In.dSAssignQScoreRange(2)) & ge(Mtx_Px_QS_Temp,UI_In.dSAssignQScoreRange(1))) = 1; % between user-input quality score limit
    Img_Px_QLo_Mask_Temp = zeros(size(Mtx_Px_QS_Temp),'logical');
    Img_Px_QLo_Mask_Temp(lt(Mtx_Px_QS_Temp,UI_In.dSAssignQScoreRange(1)) | gt(Mtx_Px_QS_Temp,UI_In.dSAssignQScoreRange(2))) = 1; % outside user-input quality score limit

    % = Distance-Source Assignment
    % Create Img_dS_QSMask_Temp (single; same for all k):
    % From Mtx_dS_QS_Temp =  Mtx of quality of dist-Source assignment score; theoretical range [-1 1];
    % actual range [0 1]; NaN for unassigned pixels
    Mtx_dS_QS_Temp = Img_DistSAssign_Cell_In{RowIdx_Temp,17}(:,:,1);
    Img_dS_QHi_Mask_Temp = zeros(size(Mtx_dS_QS_Temp),'logical');
    Img_dS_QHi_Mask_Temp(le(Mtx_dS_QS_Temp,UI_In.dSAssignQScoreRange(2)) & ge(Mtx_dS_QS_Temp,UI_In.dSAssignQScoreRange(1))) = 1; % between user-input quality score limit
    Img_dS_QLo_Mask_Temp = zeros(size(Mtx_dS_QS_Temp),'logical');
    Img_dS_QLo_Mask_Temp(lt(Mtx_dS_QS_Temp,UI_In.dSAssignQScoreRange(1)) | gt(Mtx_dS_QS_Temp,UI_In.dSAssignQScoreRange(2))) = 1; % outside user-input quality score limit

    % % % figure; imshowpair(Img_Px_QLo_Mask_Temp,Img_Px_QHi_Mask_Temp,'Scaling','none','ColorChannels',[1 2 0]);
    % % % figure; imshowpair(Img_dS_QLo_Mask_Temp,Img_dS_QHi_Mask_Temp,'Scaling','none','ColorChannels',[1 2 0]);
    % % % figure; imshowpair(Img_Px_QLo_Mask_Temp,Img_dS_QLo_Mask_Temp,'Scaling','none','ColorChannels',[1 2 0]);

    % = Store as output
    % Pixel assignment quality KEEP and REJECT masks (logical)
    Img_dSAssignAdj_Cell_Out{RowIdx_Temp,1} = repmat(Img_Px_QHi_Mask_Temp,1,1,NumDistT_Temp);
    Img_dSAssignAdj_Cell_Out{RowIdx_Temp,2} = repmat(Img_Px_QLo_Mask_Temp,1,1,NumDistT_Temp);

    % Dist Source assignment quality KEEP and REJECT masks (logical)
    Img_dSAssignAdj_Cell_Out{RowIdx_Temp,21} = repmat(Img_dS_QHi_Mask_Temp,1,1,NumDistT_Temp);
    Img_dSAssignAdj_Cell_Out{RowIdx_Temp,22} = repmat(Img_dS_QLo_Mask_Temp,1,1,NumDistT_Temp);

end

close all;
clearvars *_Temp *_Disp;
clearvars k qCt;


%% Prepare adjusted pixel and dist-source blob masks
% * Dist-source blobs are assigned 1 distance-target. Adjust PxAssign so
% pixels are assigned to same distance-target

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Create :
    % i) ImgStack_PxAssignMask_Temp (logical): z-stack of all assignment-of-pixel
    % ii) ImgStack_dSAssignMask_Temp (logical): z-stack of all ssignment-of-distSblob masks
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT

    ImgStack_PxAssignMask_Temp = cell2mat(permute(Img_DistSAssign_Cell_In(RowIdx_Temp,2:4),[1 3 2])); % i)
    ImgStack_dSAssignMask_Temp = cell2mat(permute(Img_DistSAssign_Cell_In(RowIdx_Temp,12:14),[1 3 2])); % ii)

    for qCt = 1:Numq % 1: do not include quality score masks, 2: include

        ImgStack_Adj_PxAssignMask_Temp = zeros(size(ImgStack_PxAssignMask_Temp),'logical');
        ImgStack_Adj_dSAssignMask_Temp = zeros(size(ImgStack_dSAssignMask_Temp),'logical');
        % % % ImgStack_Adj_gDist_Temp = zeros(size(ImgStack_gDist_Temp),'single');

        for k = 1:size(ImgStack_dSAssignMask_Temp,3)

            Img_k_dSMask_Temp =  ImgStack_dSAssignMask_Temp(:,:,ismember(1:size(ImgStack_dSAssignMask_Temp,3),k)); % all pixels in dist-source blobs assigned to k
            if qCt == 2 % Consider Quality Score
                Img_k_dSMask_Temp(Img_dSAssignAdj_Cell_Out{RowIdx_Temp,2}(:,:,1) | Img_dSAssignAdj_Cell_Out{RowIdx_Temp,22}(:,:,1)) = logical(0); % Px QLo Mask | dS QLo Mask
            end

            Img_notk_dSMask_Temp =  ImgStack_dSAssignMask_Temp(:,:,~ismember(1:size(ImgStack_dSAssignMask_Temp,3),k)); % all pixels in dist-source blobs * not * assigned to k
            Img_notk_dSMask_Temp =  logical(max(single(Img_notk_dSMask_Temp),[],3));
            if qCt == 2
                Img_notk_dSMask_Temp(Img_dSAssignAdj_Cell_Out{RowIdx_Temp,2}(:,:,1) | Img_dSAssignAdj_Cell_Out{RowIdx_Temp,22}(:,:,1)) = logical(0); % Px QLo Mask | dS QLo Mask
            end

            Img_k_PxMask_Temp = ImgStack_PxAssignMask_Temp(:,:,ismember(1:size(ImgStack_PxAssignMask_Temp,3),k));
            if qCt == 2
                Img_k_PxMask_Temp(Img_dSAssignAdj_Cell_Out{RowIdx_Temp,2}(:,:,1) | Img_dSAssignAdj_Cell_Out{RowIdx_Temp,22}(:,:,1)) = logical(0); % Px QLo Mask | dS QLo Mask
            end
            Img_k_PxMask_Temp = Img_k_PxMask_Temp | Img_k_dSMask_Temp; % include all pixels in dist-source blobs assigned to k
            Img_k_PxMask_Temp = Img_k_PxMask_Temp & (~Img_notk_dSMask_Temp); % exclude all pixels in dist-source blobs *not* assigned to k

            % = Store as ImgStack
            ImgStack_Adj_PxAssignMask_Temp(:,:,k) = Img_k_PxMask_Temp;
            ImgStack_Adj_dSAssignMask_Temp(:,:,k) = Img_k_dSMask_Temp;

        end

        % = Store in output
        % "Img_dSAssignAdj_Cell_Out" Column Idx; row for Px vs dS; column for Beg vs Bdc vs Btb, z
        % for ignore vs consider quality score
        ColIdx_Temp = [3 4 5; 23 24 25];

        % PxAssign
        ImgStack_Adj_PxAssignMask_Temp = mat2cell(ImgStack_Adj_PxAssignMask_Temp,height(ImgStack_Adj_PxAssignMask_Temp),width(ImgStack_Adj_PxAssignMask_Temp),repmat(1,size(ImgStack_Adj_PxAssignMask_Temp,3),1));
        ImgStack_Adj_PxAssignMask_Temp = reshape(ImgStack_Adj_PxAssignMask_Temp,[],3); % 3 Col: Beg, Bdc, Btb
        ImgStack_Adj_PxAssignMask_Temp = permute(ImgStack_Adj_PxAssignMask_Temp,[3 2 1]); % Distance Target (OCN, TRAP) in 3rd dimension

        Img_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Temp(1,1),qCt} =  cell2mat(ImgStack_Adj_PxAssignMask_Temp(:,1,:)); % Px Assign Mask to Beg DistTarget
        Img_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Temp(1,2),qCt} =  cell2mat(ImgStack_Adj_PxAssignMask_Temp(:,2,:)); % Px Assign Mask to Bdc DistTarget
        Img_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Temp(1,3),qCt} =  cell2mat(ImgStack_Adj_PxAssignMask_Temp(:,3,:)); % Px Assign Mask to Btb DistTarget

        % dSAssign
        ImgStack_Adj_dSAssignMask_Temp = mat2cell(ImgStack_Adj_dSAssignMask_Temp,height(ImgStack_Adj_dSAssignMask_Temp),width(ImgStack_Adj_dSAssignMask_Temp),repmat(1,size(ImgStack_Adj_dSAssignMask_Temp,3),1));
        ImgStack_Adj_dSAssignMask_Temp = reshape(ImgStack_Adj_dSAssignMask_Temp,[],3); % 3 Col: Beg, Bdc, Btb
        ImgStack_Adj_dSAssignMask_Temp = permute(ImgStack_Adj_dSAssignMask_Temp,[3 2 1]); % Distance Target (OCN, TRAP) in 3rd dimension

        Img_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Temp(2,1),qCt} = cell2mat(ImgStack_Adj_dSAssignMask_Temp(:,1,:)); % Dist-Source Assign Mask to Beg DistTarget
        Img_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Temp(2,2),qCt} = cell2mat(ImgStack_Adj_dSAssignMask_Temp(:,2,:)); % Dist-Source Assign Mask to Bdc DistTarget
        Img_dSAssignAdj_Cell_Out{RowIdx_Temp,ColIdx_Temp(2,3),qCt} = cell2mat(ImgStack_Adj_dSAssignMask_Temp(:,3,:)); % Dist-Source Assign Mask to Btb DistTarget

    end

end

close all;
clearvars *_Temp *_Disp;
clearvars k qCt;


%% Visual Check: Disp image also for "ImgCheck_dSAssignAdj_Cell_Out"

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % = Create :
    % i) ImgStack_Adj_PxAssignMask_Temp (logical): z-stack of all assignment-of-pixel
    % ii) ImgStack_Adj_dSAssignMask_Temp (logical): z-stack of all ssignment-of-distSblob masks
    % Beg: k =  1:NumDistT
    % Bdc: k = (NumDistT+1):2*NumDistT
    % Btb: k = (2*NumDistT+1):3*NumDistT

    % "Img_dSAssignAdj_Cell_Out" Column Idx; row for Px vs dS; column for Beg vs Bdc vs Btb, z
    % for ignore quality score vs consider quality score
    ColIdx_Temp = [3 4 5; 23 24 25];

    for qCt = 1:Numq % ignore vs quality score

        ImgStack_Adj_PxAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_Out(RowIdx_Temp,ColIdx_Temp(1,:),qCt),[1 3 2])); % i)
        ImgStack_Adj_dSAssignMask_Temp = cell2mat(permute(Img_dSAssignAdj_Cell_Out(RowIdx_Temp,ColIdx_Temp(2,:),qCt),[1 3 2])); % ii)

        % = Visual Check: Disp image also for "ImgCheck_dSAssignAdj_Cell_Out"
        cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
        cmap_Disp_Temp = vertcat(...
            [1 1 0].*cmapval_Disp_Temp,... % Beg: yellow
            [0 1 1].*cmapval_Disp_Temp,... % Bdc: teal
            [1 0 1].*cmapval_Disp_Temp... % Btb: magenta
            );
        Img_Adj_PxAssignMask_Disp = ...
            max(uint16(ImgStack_Adj_PxAssignMask_Temp).*uint16(permute(1:1:size(ImgStack_Adj_PxAssignMask_Temp,3),[1 3 2])),[],3);
        Img_Adj_PxAssignMask_Disp = label2rgb(Img_Adj_PxAssignMask_Disp,cmap_Disp_Temp,[0 0 0]);
        Img_Adj_PxAssignMask_Disp = addborder(Img_Adj_PxAssignMask_Disp,2,[intmax(class(Img_Adj_PxAssignMask_Disp)) intmax(class(Img_Adj_PxAssignMask_Disp)) intmax(class(Img_Adj_PxAssignMask_Disp))],'inner');

        Img_Adj_dSAssignMask_Disp = ...
            max(uint16(ImgStack_Adj_dSAssignMask_Temp).*uint16(permute(1:1:size(ImgStack_Adj_dSAssignMask_Temp,3),[1 3 2])),[],3);
        Img_Adj_dSAssignMask_Disp = label2rgb(Img_Adj_dSAssignMask_Disp,cmap_Disp_Temp,[0 0 0]);
        Img_Adj_dSAssignMask_Disp = addborder(Img_Adj_dSAssignMask_Disp,2,[intmax(class(Img_Adj_dSAssignMask_Disp)) intmax(class(Img_Adj_dSAssignMask_Disp)) intmax(class(Img_Adj_dSAssignMask_Disp))],'inner');

        Img_Adj_PxdSAssignMask_Disp = horzcat(Img_Adj_PxAssignMask_Disp,Img_Adj_dSAssignMask_Disp);

        % = Store in ImgCheck output
        ImgCheck_dSAssignAdj_Cell_Out{dtsCt,1,qCt} = Img_Adj_PxdSAssignMask_Disp;
        ImgCheck_dSAssignAdj_Cell_Out{dtsCt,1,qCt} = imresize(ImgCheck_dSAssignAdj_Cell_Out{dtsCt,1},[800 NaN]); % OPTIONAL: Resize to 800px high per image


        % % % figure; imshow(Img_Adj_PxdSAssignMask_Disp);

    end

end

close all;
clearvars *_Temp *_Disp;
clearvars k qCt;

