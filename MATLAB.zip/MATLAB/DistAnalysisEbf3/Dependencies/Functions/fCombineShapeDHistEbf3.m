% 20250405
% Combine Area Histograms, by DistT (TRAP, OCN, "hypothetical" bone front
% stain etc) of all bone fronts (Begdctb) or cortical + trabecular bone fronts only (Bdctb)

function [PlotData_ShapeDHist_BCombo_Cell_Out,Plot_ShapeDHist_BCombo_Cell_Out] = fCombineShapeDHistEbf3(PlotData_ShapeDHist_Cell_In,UI_In)

%% Prepare Output Cells

% 6 Cases of using skeleton branch length to measure aspect ratio of
% dist-source blobs:

% * Case 1.1): "Hist_skbrL_by_brD"
% Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to 1 HistBin_D
% * Case 1.2): "Hist_skbrL_by_brpxD"
% Skeleton branch length as BoxChart Value, Weighted by # Pixels in Skeleton, Distance to Target belongs to multiple HistBin_D
% * Case 1.3): "Hist_skbrLS_by_brD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to 1 HistBin_D
% * Case 1.4): "Hist_skbrLS_by_blobD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to 1 HistBin_D
% * Case 1.5): "Hist_skbrLS_by_brpxD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in all skeleton branches in dSBlob, Distance to Target belongs to multiple HistBin_D
% * Case 1.6): "Hist_skbrLS_by_blobpxD"
% Sum of Skeleton branch length in dSBlob as BoxChart Value, Weighted by # Pixels in dSBlob, Distance to Target belongs to multiple HistBin_D

% Each case may ignore quality of assignment (q0), or consider quality of assignment (q1)

% = PlotData_ShapeDHist_BCombo_Cell

PlotData_ShapeDHist_BCombo_Cell_Out = cell(4,7,2);

% Plot data from adjusted (final) assignment of distance-source blobs to different distance-targets @ different bone fronts (eg, dc, tb).
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell,Img_Begdc_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = <empty>
% * Col02 = class "structure", histogram data, Case 1.1) (Row 3,4)
% * Col03 = class "structure", histogram data, Case 1.2) (Row 3,4)
% * Col04 = class "structure", histogram data, Case 1.3) (Row 3,4)
% * Col05 = class "structure", histogram data, Case 1.4) (Row 3,4)
% * Col06 = class "structure", histogram data, Case 1.5) (Row 3,4)
% * Col07 = class "structure", histogram data, Case 1.6) (Row 3,4)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


% = Plot_ShapeDHist_BCombo_Cell

Plot_ShapeDHist_BCombo_Cell_Out = cell(2,7,2);

% Rows:
% * Row01 = all dist measure targets (OCN, TRAP etc)
% * Row02 = all bone fronts (no staining or original image)

% Column (match PlotData above):
% * Col01 = <empty>
% * Col02 = Histogram, Case 1.1) (Row 1,2)
% * Col03 = Histogram, Case 1.2) (Row 1,2)
% * Col04 = Histogram, Case 1.3) (Row 1,2)
% * Col05 = Histogram, Case 1.4) (Row 1,2)
% * Col06 = Histogram, Case 1.5) (Row 1,2)
% * Col07 = Histogram, Case 1.6) (Row 1,2)

% Z:
% * Z01 = ignore quality of assignment score (q01)
% * Z02 = consider quality of assignment score (q02)


%%

% % % NumDistT = size(Img_gDistMap_Cell_In{3,1},3); % Number of distance target (OCN, TRAP etc)
% % % NumDistTbf = size(Img_gDistMap_Cell_In{4,1},3); % Number of "hypothetical" bone front staining = 1
NumDistT_Mtx = [...
    PlotData_ShapeDHist_Cell_In{3,2,1}.HistData.NumDistT; ... % Number of distance target (OCN, TRAP etc); = NumDistT (Row 3)
    PlotData_ShapeDHist_Cell_In{4,2,1}.HistData.NumDistT; ... % Number of "hypothetical" bone front staining = 1 = NumDistTbf (Row 4)
    ];

% = Quality of Assignment: Ignore only vs Ignore+Consider
if UI_In.dSAssignQOption==[1 0]
    Numq = 1;
elseif UI_In.dSAssignQOption==[1 1]
    Numq = 2;
end


%% All Cases: Prepare Plot Data

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    ColIdx_InOut_Temp = [2:7]; % Columns corresponding to cases to plot

    for csCt = 1:numel(ColIdx_InOut_Temp)

        for qCt = 1:Numq

            HistData_Temp = PlotData_ShapeDHist_Cell_In{RowIdx_Temp,ColIdx_InOut_Temp(csCt),qCt}.HistData;

            [ygrp_Temp,ygrpID_k_Temp,ygrpID_HIstBin_Temp] =findgroups(HistData_Temp.yBox(:,1),HistData_Temp.yBox(:,2)); % k, HistBin_D

            HistData_Temp.yBox_Begdctb_Cell = cell(1,1,NumDistT_Temp); % Each DistT (TRAP, OCN etc) 1 cell layer; each cell element with matrix of 3 columns
            HistData_Temp.yBox_Bdctb_Cell = cell(1,1,NumDistT_Temp); % Each DistT (TRAP, OCN etc) 1 cell layer

            for dtCt = 1:NumDistT_Temp % DistT (not DistTSet) count

                % = Combine Beg, Bdc and Btb bone fronts (Begdctb)
                ygrp_dtCt_Begdctb_Temp = find(ismember(ygrpID_k_Temp,dtCt:NumDistT_Temp:max(ygrpID_k_Temp,[],'all'))); % Which ygrp to keep for dtCt, Begdctb

                yBox_dtCt_Begdctb_Temp = HistData_Temp.yBox;
                yBox_dtCt_Begdctb_Temp(~ismember(ygrp_Temp,ygrp_dtCt_Begdctb_Temp),:) = []; % yBox data restricted to rows for dtCt
                % % % yBox_dtCt_Begdctb_Temp(:,1) = -9.999; % Remove k (Beg vs Bdc vs Btb for dtCt) information;
                yBox_dtCt_Begdctb_Temp(:,1) = dtCt; % Change k to dtCt; Beg vs Bdc vs Btb for info removed

                HistData_Temp.yBox_Begdctb_Cell{1,1,dtCt} = yBox_dtCt_Begdctb_Temp;

                % = Combine Bdc and Btb bone fronts (Bdctb)

                ygrp_dtCt_Bdctb_Temp = find(ismember(ygrpID_k_Temp,(NumDistT_Temp+dtCt):NumDistT_Temp:max(ygrpID_k_Temp,[],'all'))); % Which ygrp to keep for dtCt, Bdctb

                yBox_dtCt_Bdctb_Temp = HistData_Temp.yBox;
                yBox_dtCt_Bdctb_Temp(~ismember(ygrp_Temp,ygrp_dtCt_Bdctb_Temp),:) = []; % yBox data restricted to rows for dtCt
                % % % yBox_dtCt_Bdctb_Temp(:,1) = -9.999; % Remove k (Bdc vs Btb for dtCt) information;
                yBox_dtCt_Bdctb_Temp(:,1) = dtCt; % Change k to dtCt; Beg vs Bdc vs Btb for info removed

                HistData_Temp.yBox_Bdctb_Cell{1,1,dtCt} = yBox_dtCt_Bdctb_Temp;

            end

            % = 20250405: HistCt_Tbl (2D table for export into csv)
            % 3 Columns: [dtCt HistBin Row01Val]
            HistData_Temp.yBox_Begdctb_Tbl = ...
                array2table(cell2mat(permute(HistData_Temp.yBox_Begdctb_Cell,[3 2 1])),'VariableNames',{'dtCt','HistBin','yval'});
            HistData_Temp.yBox_Bdctb_Tbl = ...
                array2table(cell2mat(permute(HistData_Temp.yBox_Bdctb_Cell,[3 2 1])),'VariableNames',{'dtCt','HistBin','yval'});

            PlotData_ShapeDHist_BCombo_Cell_Out{RowIdx_Temp,ColIdx_InOut_Temp(csCt),qCt}.HistData = HistData_Temp;

        end

    end

end

clearvars *Temp qCt csCt dtCt dtsCt;


%% 20250403 All Cases: Boxplots

close all;

for dtsCt = 1:2 % Dist-Target Sets (1: real, 2: hypothetical)

    RowIdx_Temp = dtsCt+2; % Row 3 or Row 4
    NumDistT_Temp = NumDistT_Mtx(dtsCt,1);

    % === Define colormap for plotting all histograms
    cmapval_Disp_Temp = linspace(0.40,1,NumDistT_Temp)'; % created needed number brightness levels (=number of distance-targets)
    cmap_Disp_Temp = vertcat(...
        [0.7 0.7 0.7].*cmapval_Disp_Temp... % Combined Bone Fronts: Grey
        );

    % === Specify HistData to plot
    ColIdx_PlotInOut_Temp = [2:7];

    for csCt = 1:numel(ColIdx_PlotInOut_Temp) % number of histograms

        for qCt = 1:Numq

            HistData_Temp = PlotData_ShapeDHist_BCombo_Cell_Out{RowIdx_Temp,ColIdx_PlotInOut_Temp(csCt),qCt}.HistData;

            for dtCt = 1:NumDistT_Temp

                % == y-axis upper limit
                ymax_wrapper = @(x) prctile(x,75)+1.5*iqr(x);
                [ygrp_Begdctb_Temp,ygrpID_HistBin_Begdct_Temp] = findgroups(HistData_Temp.yBox_Begdctb_Cell{1,1,dtCt}(:,2)); % Group by HistBIn_D
                ymax_Begdctb_Temp = min(splitapply(ymax_wrapper,HistData_Temp.yBox_Begdctb_Cell{1,1,dtCt}(:,3),ygrp_Begdctb_Temp), splitapply(@max,HistData_Temp.yBox_Begdctb_Cell{1,1,dtCt}(:,3),ygrp_Begdctb_Temp)); % ymax of each HistBin
                ymax_Begdctb_Temp = max(ymax_Begdctb_Temp,[],'all');

                [ygrp_Bdctb_Temp,ygrpID_HistBin_Bdct_Temp] = findgroups(HistData_Temp.yBox_Bdctb_Cell{1,1,dtCt}(:,2)); % Group by HistBIn_D
                ymax_Bdctb_Temp = min(splitapply(ymax_wrapper,HistData_Temp.yBox_Bdctb_Cell{1,1,dtCt}(:,3),ygrp_Bdctb_Temp), splitapply(@max,HistData_Temp.yBox_Bdctb_Cell{1,1,dtCt}(:,3),ygrp_Bdctb_Temp)); % ymax of each HistBin
                ymax_Bdctb_Temp = max(ymax_Bdctb_Temp,[],'all');

                % == Figure 01a: 2 columns for HistCt_Begdctb (Col 1), HistCt_Bdctb (Col 2); NumDistT_Temp rows
                FigHandle01a = figure('Position',[25 150 1200 325*NumDistT_Temp],'visible','off','PaperPositionMode','auto'); % [left bottom width height]
                tlo = tiledlayout(NumDistT_Temp,2,'TileSpacing','Compact','Padding','tight','TileIndexing', 'columnmajor'); % tile layout; replace subplot(); 3 Col for Beg, Bdc, Btb
                set(gcf,'color','white');
                
                for cbCt = 1:2 % 2 combo method: Begdctb, Bdctb
                    for dtCt = 1:NumDistT_Temp

                        ax = nexttile(tlo);
                        hold(ax, 'on'); grid off;

                        if cbCt == 1
                            mtx_dtCt_Temp = HistData_Temp.yBox_Begdctb_Cell{1,1,dtCt};
                            ymax_Temp = ymax_Begdctb_Temp;
                            Str_cb_Temp = "_Begdctb";
                        elseif cbCt == 2
                            mtx_dtCt_Temp = HistData_Temp.yBox_Begdctb_Cell{1,1,dtCt};
                            ymax_Temp = ymax_Bdctb_Temp;
                            Str_cb_Temp = "_Bdctb";
                        end

                        xgrp_dtCt_Temp = categorical(HistData_Temp.HistBinLbl_D,HistData_Temp.HistBinLbl_D,'Ordinal',true)';
                        xgrp_dtCt_Temp = xgrp_dtCt_Temp(mtx_dtCt_Temp(:,2));
                        y_dtCt_Temp = mtx_dtCt_Temp(:,3);

                        boxchart(xgrp_dtCt_Temp,y_dtCt_Temp,...
                            'BoxFaceColor',cmap_Disp_Temp(dtCt,:), 'BoxFaceAlpha',0.5,'BoxEdgeColor',[0 0 0],'LineWidth',2,'MarkerColor',cmap_Disp_Temp(dtCt,:));

                        ylim([0 ymax_Temp]);

                        xlabel('Distance to Target (um)','interpreter','none');
                        ylabel(HistData_Temp.HistyLbl,'interpreter','none');
                        title(strcat("dtSet",num2str(dtsCt,'%02d'),"_DistT",num2str(dtCt,'%02d'),Str_cb_Temp,'_q',num2str(qCt,'%02d')),'interpreter','none');

                        fontname('Arial'); fontsize(16,'points'); set(gca,'FontWeight','bold');

                    end
                end

                sgtitle(HistData_Temp.HistName,'interpreter','none','FontName','Arial','FontSize',12,'FontWeight','bold');

                % = Prepare display, also store as plot output
                iptsetpref("ImshowBorder","tight"); % remove borders; do before export_fig

                Img_Fig01a_Temp =  export_fig(FigHandle01a,'-r150');
                Img_Fig01a_Temp = imresize(Img_Fig01a_Temp,[round(1.5*325*NumDistT_Temp) NaN]); % Proportional to height of FigHandle

                % % % figure; imshow(Img_Fig01a_Temp);

                Plot_ShapeDHist_BCombo_Cell_Out{dtsCt,ColIdx_PlotInOut_Temp(csCt),qCt} = Img_Fig01a_Temp;

                close all;
                clearvars FigHandle* ax tlo;

            end

            clearvars y*Temp x*Temp mtx_k_Temp k;

        end

    end

end

clearvars *Temp *Disp *Ct;


