% 20250123: Usage
% UI_In = User input; include UI_In.Img_FoldernameString
% CropOption_In: whether to trim black areas in processed image

function [Img_Org_Cell_Out,ImgCheck_Org_Cell_Out,oEbf3_Out] = fLoadImgEbf3(UI_In,CropOption_In)


%% Prepare Output

% OUTPUT: Img_Org_Cell
% Rows:
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (staining of OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)
% Columns:
% * Col01 = Original Img (None for Row 4)

Img_Org_Cell_Out = cell(4,1);

% OUTPUT: ImgCheck_Org_Cell_Out: 
% 1 Row; Columns:
% * Col01: Img_Disp_AllColorRGB (all labels of all visual colors compressed into 3 slices for R-G-B; for display)
% * Col02: Img_Disp_AllColor (each label given 1 color and 1 slice; 20250123 in order RGBW; for display)
% * Col03: Img_Disp_RGB (labels compressed into 3 colors and 3 slices for RGB; for ImgCheck)

ImgCheck_Org_Cell_Out = cell(1,3);

% OUTPUT: oEbf3_Out
% Contains records of UI, Image input and crop parameters
% No initiation necessary


%% Check Input

% = Read image files in input image folder
Img_FolderFileList = [dir(fullfile(UI_In.Img_FoldernameString,'*.tif')); dir(fullfile(UI_In.Img_FoldernameString,'*.jpg'))];

% = Count number of channel images given in input image folder
% Channel count should match number in color or structure label assignment
NumCHImg = height([dir(fullfile(UI_In.Img_FoldernameString,'*CH*.tif')); dir(fullfile(UI_In.Img_FoldernameString,'*CH*.jpg'))]);
if NumCHImg<1 % No single-channel image
    NumCh = 3; % RGB image
elseif NumCHImg>2 % 1 or more distance targets
    NumCh = NumCHImg;
elseif NumCHImg==2 & UI_In.BoneFrontOnly_Option==1 % No distance targets; will insert fake distance target image
    NumCh = 3; % RGB image
end
% % % if numel(unique([NumCh,numel(UI_In.ChLbl),numel(UI_In.ChColor)]))>1 % 3 values not the same
% % %     error('ERROR: Number of channel (CH) images not equal to number of elements in UI.ChLbl or UI.ChColor.');
% % % end

% = Check have 1 nuclei channel and 1 distance source (Ebf3) channel
if  ~isequal(sum(UI_In.ChLbl(:)==1),1) | ~isequal(sum(UI_In.ChLbl(:)==2),1)
    error('ERROR: Wrong number of channels assigned to nuclei or distance source (Ebf3).');
end


%% OPTIONAL: Prepare crop coordinates xmin,ymin,xmax,ymax to reduce image size

if CropOption_In=='y'
    for fCt = 1:numel(Img_FolderFileList) % filecount
        if ~exist('Img_ZMax_Temp')
            Img_ZMax_Temp = max(single(imread(fullfile(Img_FolderFileList(fCt).folder,Img_FolderFileList(fCt).name))),[],3);
        else
            Img_ZMax_Temp = max(Img_ZMax_Temp,max(single(imread(fullfile(Img_FolderFileList(fCt).folder,Img_FolderFileList(fCt).name))),[],3));
        end
    end
    Img_ZMax_Temp = Img_ZMax_Temp./max(Img_ZMax_Temp,[],'all');
    rp_Temp = regionprops(imbinarize(Img_ZMax_Temp,0.050),'Area','BoundingBox');
    Bbox_Temp = cat(1,rp_Temp.BoundingBox);
    Bbox_Temp = horzcat(Bbox_Temp,floor(Bbox_Temp(:,1))+ceil(Bbox_Temp(:,3)),floor(Bbox_Temp(:,2))+ceil(Bbox_Temp(:,4))); % add xEnd, yEnd columns
    Crop_xmin = max(1,min(floor(Bbox_Temp(:,1)),[],1)-50);
    Crop_ymin = max(1,min(floor(Bbox_Temp(:,2)),[],1)-50);
    Crop_xmax = min(width(Img_ZMax_Temp),max(Bbox_Temp(:,5),[],1)+50);
    Crop_ymax = min(height(Img_ZMax_Temp),max(Bbox_Temp(:,6),[],1)+50);
end

clearvars *Temp fCt;


%% Organize Channel Images into Output Format

for fCt = 1:numel(Img_FolderFileList) % filecount

    % Load image
    Img_Temp = imread(fullfile(Img_FolderFileList(fCt).folder,Img_FolderFileList(fCt).name));
    
    if ~exist('ImgHeight_PreCrop') | ~exist('ImgWidth_PreCrop')
        ImgHeight_PreCrop = height(Img_Temp);
        ImgWidth_PreCrop = width(Img_Temp);
    end

    [StartIdx_Temp,~] = regexp(Img_FolderFileList(fCt).name,'_CH\d','once'); % Find single channel info in image name
    if ~isempty(StartIdx_Temp) % With CH(number) = channel info in filename; ie. single channel image

        Ch_Temp = str2num(Img_FolderFileList(fCt).name(StartIdx_Temp+3)); % Microscope Channel Number
        Img_Temp = max(single(Img_Temp),[],3);  % Microscope saves single channel R/G/B image in RGB;
        Img_Temp = Img_Temp./max(Img_Temp,[],'all');
        if CropOption_In=='y'
            Img_Temp = Img_Temp(Crop_ymin:Crop_ymax,Crop_xmin:Crop_xmax);
            if ~exist('ImgHeight_PostCrop') | ~exist('ImgWidth_PostCrop')
                ImgHeight_PostCrop = height(Img_Temp);
                ImgWidth_PostCrop = width(Img_Temp);
           end
        end

        % Organize Img_Temp by color for display
        if ~exist('Img_Disp_AllColor')
            Img_Disp_AllColor = zeros(height(Img_Temp),width(Img_Temp),NumCHImg,'single'); 
        end
        Img_Disp_AllColor(:,:,UI_In.ChColor(Ch_Temp)) = Img_Temp;

        % Organize Img_Temp by label (nuclei, Ebf3, distance targets)
        if ~exist('Img_Org_Cell_Out') 
            Img_Org_Cell_Out = cell(5,1); 
        end
        Img_Org_Cell_Out{UI_In.ChLbl(Ch_Temp),1} = cat(3,Img_Org_Cell_Out{UI_In.ChLbl(Ch_Temp)},Img_Temp);

    else % Without channel info in filename; 3-channel RGB image
    
        % Prepare display image
        Img_Disp_AllColorRGB = single(Img_Temp); % Overlay; for display
        Img_Disp_AllColorRGB = Img_Disp_AllColorRGB./max(max(Img_Disp_AllColorRGB,[],1),[],'all');
        if CropOption_In=='y'
            Img_Disp_AllColorRGB = Img_Disp_AllColorRGB(Crop_ymin:Crop_ymax,Crop_xmin:Crop_xmax,1:end);
        end
       
        % Assign Img_Temp by label (nuclei, Ebf3, distance targets)
        if NumCHImg<1 % No single-channel images given
            if ~exist('Img_Org_Cell_Out')
                Img_Org_Cell_Out = cell(6,1);
            end
            Img_Org_Cell_Out{1,1} = Img_Disp_AllColorRGB(:,:,UI_In.ChLbl==1); % Nuclei
            Img_Org_Cell_Out{2,1} = Img_Disp_AllColorRGB(:,:,UI_In.ChLbl==2); % Distance measure source (Ebf3)
            Img_Org_Cell_Out{3,1} = Img_Disp_AllColorRGB(:,:,UI_In.ChLbl==3); % Distance measure target (OCN, TRAP etc)
            
            Img_Disp_AllColor = Img_Disp_AllColorRGB;
        end

    end

end

if exist('Img_Disp_AllColorRGB')  % Does not exist if Overlay image not given
    ImgCheck_Org_Cell_Out{1,1} = Img_Disp_AllColorRGB;
end
ImgCheck_Org_Cell_Out{1,2} = Img_Disp_AllColor;

clearvars *Temp fCt;
clearvars Img_Disp_AllColor*;


%% 20250320: Include zero image for Img_Org_Cell{4,1}
% No original image for bone fronts

Img_Org_Cell_Out{4,1} = zeros(size(Img_Org_Cell_Out{1,1}),'single');


%% Prepare Img_Disp_RGB for ImgCheck
% * 20250123: 1 channel for nuclei, 1 channel for Ebf3, 1 channel for combination of all
% distance measure targets (OCN, TRAP etc). Color for each channel
% designated in "UI.ImgCheck_NSTColor"
% * Brightness-Contrast adjusted so that R/G/B has similar perceived
% brightness for overlay of white features

Img_Disp_RGB = zeros(height(Img_Org_Cell_Out{1,1}),width(Img_Org_Cell_Out{1,1}),3,'single'); % 3 slices for RGB
Img_Disp_RGB(:,:,UI_In.ImgCheck_NSTColor(1)) = Img_Org_Cell_Out{1,1}; % nuclei (N)
Img_Disp_RGB(:,:,UI_In.ImgCheck_NSTColor(2)) = Img_Org_Cell_Out{2,1}; % Eb3 (E; dist measure source)
if ~ isempty(Img_Org_Cell_Out{3,1}) % Distance Targets Provided
    Img_Disp_RGB(:,:,UI_In.ImgCheck_NSTColor(3)) = max(Img_Org_Cell_Out{3,1},[],3); % all dist measure Targets (T)
end

ImgCheck_Org_Cell_Out{1,3} = Img_Disp_RGB;

clearvars Img_Disp_RGB;



%% For ImgCheck_Org_Cell, Adjust for perceived brightness
% i) increase B channel intensity so that 5% saturated
% ii) approx ratio of perceived brightness of R:G:B: 299:587:114

if NumCh>3 % More than 3 labels compressed into RGB, do NOT adjust Img_Disp_AllColorRGB as mixed color (for example, white) would be off
    ColChoice = [2,3];
else % 3 labels in RGB; can adjust all rows
    ColChoice = [1,2,3];
end

for cCt = 1:numel(ColChoice)

    if ~isempty(ImgCheck_Org_Cell_Out{1,ColChoice(cCt)})
        sf_B_Temp = stretchlim(ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}(:,:,3),[0 0.95]); % Allow 5% saturation for display; (1/upper intensity limit) = scale factor
        sf_B_Temp = (1/sf_B_Temp(2));
        ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}(:,:,1) = ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}(:,:,1).*sf_B_Temp.*(114/299);
        ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}(:,:,2) = ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}(:,:,2).*sf_B_Temp.*(114/587);
        ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}(:,:,3) = ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}(:,:,3).*sf_B_Temp.*(114/114);
        ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}(ImgCheck_Org_Cell_Out{1,ColChoice(cCt)}>1) = 1;
    end

end

clearvars sf_B* ColChoice cCt;


%% 20250609: If No Distance Target, fill ImgCheck_Org_Cell{1,3} with zero
% Do not do earlier

if UI_In.BoneFrontOnly_Option==1
    Img_Org_Cell_Out{3,1} = zeros(size(Img_Org_Cell_Out{1,1}),'single');
end


%% Create output oEbf3

oEbf3_Out.UI = UI_In;

oEbf3_Out.UI.NumCh = NumCh;

if UI_In.BoneFrontOnly_Option==1
    oEbf3_Out.UI.NumDistT = 0;
else
    oEbf3_Out.UI.NumDistT = size(Img_Org_Cell_Out{3,1},3); % Number of distance measure targets (OCN, TRAP etc)
end

oEbf3_Out.UI.Img_Disp_RGB = ImgCheck_Org_Cell_Out{1,1};
oEbf3_Out.UI.Img_Disp_AllColor = ImgCheck_Org_Cell_Out{1,2};

% Save image size information
oEbf3_Out.ImgSz.ImgHeight_PreCrop = ImgHeight_PreCrop;
oEbf3_Out.ImgSz.ImgWidth_PreCrop = ImgWidth_PreCrop;
oEbf3_Out.ImgSz.ImgHeight_PostCrop = ImgHeight_PostCrop;
oEbf3_Out.ImgSz.ImgWidth_PostCrop = ImgWidth_PostCrop;

if CropOption_In == 'y'
    oEbf3_Out.ImgSz.Crop_xmin = Crop_xmin;
    oEbf3_Out.ImgSz.Crop_xmax = Crop_xmax;
    oEbf3_Out.ImgSz.Crop_ymin = Crop_ymin;
    oEbf3_Out.ImgSz.Crop_ymax = Crop_ymax;
else
    oEbf3_Out.ImgSz.Crop_xmin = 1;
    oEbf3_Out.ImgSz.Crop_xmax = ImgWidth_PreCrop;
    oEbf3_Out.ImgSz.Crop_ymin = 1;
    oEbf3_Out.ImgSz.Crop_ymax = ImgHeight_PreCrop;
end

