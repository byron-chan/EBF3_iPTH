% 20250206: Define Bone Edge of epiphysis/growth-plate (eg) and diaphysis
% cortical bone (dc) 

% First part same as fDefineBoneEdgeEbf3

function [Img_Begdc_Cell_Out] = fDefineBegdcEbf3(Img_MrwDef_Cell_In,UI_In)

close all;

%% Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)

Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;


%% === Use MrwMask to find eg and dc edge

% Strategy: create convex hull on Img_MrwMask (Img_MrwDef_Cell{1,1}) and 
% Img_MrwMask_SmEdgeFill (Img_MrwDef_Cell{1,3}) and find the difference 
% between the convex hull and the MrwMasks, ie, the extra pixels of the convex
% hull not occupied by the MrwMasks. 
% This Convex-Hull-Difference (chd) is made of
% multiple blobs disconnected by where the outmost MrwMasks pixels touch
% the hull. Each blob is analyzed by location to determine its relative
% location to the MrwMasks; those above are nearer to the epiphysis and
% growth plate (eg).

% OUTPUT Img_Begdc_Cell: cell of size(3,8):
% Rows (same as Img_Org_Cell,Img_MrwDef_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = (From MrwMask_Edge) Bone edge *line* mask, epiphysis-growth plate (Beg) (logical, Row1)
% * Col02 = (From MrwMask_Edge)  Bone edge *line* mask, diaphysis-cortical bone (Bdc) (logical, Row1)
% * Col03 = (From MrwMask_SmEdge) Bone edge *line* mask, epiphysis-growth plate (Beg) (logical, Row1)
% * Col04 = (From MrwMask_SmEdge) Bone edge *line* mask, diaphysis-cortical plate (Bdc) (logical, Row1)

% * Col05 = (From MrwMask_Edge) Bone edge *region* mask, epiphysis-growth plate (Beg) (logical, Row1)
% * Col06 = (From MrwMask_Edge)  Bone edge *region* mask, diaphysis-cortical bone (Bdc) (logical, Row1)
% * Col07 = (From MrwMask_SmEdge) Bone edge *region* mask, epiphysis-growth plate (BegMask) (logical, Row1)
% * Col08 = (From MrwMask_SmEdge) Bone edge *region* mask, diaphysis-cortical plate (BdcMask) (logical, Row1)

Img_Begdc_Cell_Out = cell(4,8);

%% ====== Col01-04 Bone Edge *Line* Masks, epiphysis-growth plate (eg) & diaphysis-cortical bone (dc)

%% Define Bone edge, epiphysis-growth plate mask (BegMask) and Bone edge, diaphysis-cortical bone mask (BdcMask)

% = Create convex hull (ch), find difference wrt marrow masks (mm) 
% Use both MrwMask and MrwMask_Sm (=MrwMask_SmEdgeFill)

Img_MrwMask_EdgeFill_Temp = imfill(Img_MrwDef_Cell_In{1,2},'holes');
Img_MrwMask_SmEdgeFill_Temp = imfill(Img_MrwDef_Cell_In{1,4},'holes');

Img_chd = ... % convex hull from (MrwMask OR MrwMask_Sm)
    bwconvhull(Img_MrwMask_EdgeFill_Temp) | bwconvhull(Img_MrwMask_SmEdgeFill_Temp); 
% % % Img_chd = ... % difference between convex hull and (MrwMask OR MrwMask_Sm)
% % %     logical(single(Img_chd)-max(single(Img_MrwDef_Cell_In{1,1}),single(Img_MrwDef_Cell_In{1,3})));
Img_chd = ... % difference between convex hull and (MrwMask OR MrwMask_Sm)
    xor(Img_chd,(Img_MrwMask_EdgeFill_Temp | Img_MrwMask_SmEdgeFill_Temp));

rp_chd = regionprops(Img_chd,'Centroid','PixelList','PixelIdxList');
rp_mm = regionprops((Img_MrwMask_EdgeFill_Temp | Img_MrwMask_SmEdgeFill_Temp), 'Centroid','PixelList','PixelIdxList'); % MrwMasks

% = Define needed wrapper functions
prctile10_wrapper = @(x) prctile(x,10,'all');
prctile90_wrapper = @(x) prctile(x,90,'all');
min_wrapper = @(x) min(x,[],'all');
max_wrapper = @(x) max(x,[],'all');

% = For marrow masks (mm) pixels, organize the y and x values by groups
[grp_x_mm_Temp,x_mm_Temp] = findgroups(rp_mm.PixelList(:,1)); % MrwMasks
y_prc10_by_x_mm_Temp = splitapply(prctile10_wrapper,rp_mm.PixelList(:,2),grp_x_mm_Temp);

[grp_y_mm_Temp,y_mm_Temp] = findgroups(rp_mm.PixelList(:,2)); % MrwMasks
x_min_by_y_mm_Temp = splitapply(min_wrapper,rp_mm.PixelList(:,1),grp_y_mm_Temp);
x_max_by_y_mm_Temp = splitapply(max_wrapper,rp_mm.PixelList(:,1),grp_y_mm_Temp);

% = Compare chd blob xy locations and mm xy locations
rp_eg_Temp = rp_chd; % blobs for defining MrwMask edge closer to growth plate / epiphysis (eg)
rp_dc_Temp = rp_chd; % blobs for defining MrwMask edge closer to cortical bone in diaphsis (dc)
rp_bm_Temp = rp_chd; % blobs touching the bottom of image (bm)

FlagID_ed_Temp = zeros(height(rp_chd),1,'logical'); % Will flag blobs positioned lower (larger y values) than MrwMask; ie keep blobs connecting to MrwMask's top / epiphysis / growth plate edge
FlagID_bm_Temp = zeros(height(rp_chd),1,'logical'); % Will flag blobs at bottom of image and within marrow, from marrow holes

for bCt = 1:height(rp_chd) % # blobs from difference between cvx hull and marrow masks
    
    % Determine if blob is above MrwMask
    [grp_x_chd_Temp,x_chd_Temp] = findgroups(rp_chd(bCt).PixelList(:,1));
    y_prc90_by_x_chd_Temp = splitapply(prctile90_wrapper,rp_chd(bCt).PixelList(:,2),grp_x_chd_Temp);

    [~,Idx_x_mm_Temp,Idx_x_chd_Temp] = intersect(x_mm_Temp,x_chd_Temp); % Identify overlapping x between blob and MrwMask
    
    Frac_Temp = ... % Fraction of blob's x values with 90-prctile-y > MrwMasks' 10-prctile-y (ie, blob "higher" than mask)
        numel(find((y_prc90_by_x_chd_Temp(Idx_x_chd_Temp)>y_prc10_by_x_mm_Temp(Idx_x_mm_Temp))))/numel(Idx_x_mm_Temp);

    if Frac_Temp>0.5 
        FlagID_ed_Temp(bCt,1) = 1;
    end

    % Determine if blob is at bottom of image and MrwMask, and embedded
    % without marrow
    [grp_y_chd_Temp,y_chd_Temp] = findgroups(rp_chd(bCt).PixelList(:,2));
    x_min_by_y_chd_Temp = splitapply(min_wrapper,rp_chd(bCt).PixelList(:,1),grp_y_chd_Temp);
    x_max_by_y_chd_Temp = splitapply(max_wrapper,rp_chd(bCt).PixelList(:,1),grp_y_chd_Temp);

    if ismember(height(Img_MrwDef_Cell_In{1,1}),y_chd_Temp) % blob touches bottom of image (largest y value) only
        [~,Idx_y_mm_Temp,Idx_y_chd_Temp] = intersect(y_mm_Temp,y_chd_Temp); % Identify overlapping y between blob and MrwMask
        if all((x_min_by_y_mm_Temp(Idx_y_mm_Temp)<x_min_by_y_chd_Temp(Idx_y_chd_Temp)) & ...
                (x_max_by_y_mm_Temp(Idx_y_mm_Temp)>x_max_by_y_chd_Temp(Idx_y_chd_Temp)))
            FlagID_bm_Temp(bCt,1) = 1;
        end
    end

end

rp_eg_Temp(FlagID_ed_Temp|FlagID_bm_Temp) = [];
rp_dc_Temp(~FlagID_ed_Temp|FlagID_bm_Temp) = [];
rp_bm_Temp(~FlagID_bm_Temp) = [];

Img_chd_eg_Mask = zeros(size(Img_MrwDef_Cell_In{1,1}),'logical');
Img_chd_eg_Mask(cat(1,rp_eg_Temp.PixelIdxList)) = 1;

Img_chd_dc_Mask = zeros(size(Img_MrwDef_Cell_In{1,1}),'logical');
Img_chd_dc_Mask(cat(1,rp_dc_Temp.PixelIdxList)) = 1;

Img_chd_bm_Mask = zeros(size(Img_MrwDef_Cell_In{1,1}),'logical');
Img_chd_bm_Mask(cat(1,rp_bm_Temp.PixelIdxList)) = 1;

% % figure;
% % Img_Fuse =  cat(3,single(Img_chd_eg_Mask),single(Img_chd_dc_Mask),single(Img_MrwDef_Cell_In{1,1}|Img_MrwDef_Cell_In{1,3}));
% % imshow(Img_Fuse);

% % figure;
% % Img_Fuse =  cat(3,single(Img_chd_eg_Mask),single(Img_chd_dc_Mask),single(Img_chd_bm_Mask));
% % imshow(Img_Fuse);

close all;

clearvars *Temp *wrapper bCt Img_Fuse;
clearvars *chd* -except Img_chd_eg_Mask Img_chd_dc_Mask Img_chd_bm_Mask;


%% Assign MrwMask edge pixels to epiphysial-growth plate edge (eg) or diaphysis-cortical bone (dc) edge  

% = Positions of edge pixels of Img_chd_egMask, Img_dcEdge_Mask Img_bttm_Mask
LinIdx_eg = find(edge(Img_chd_eg_Mask)); 
[Row_eg,Col_eg] = ind2sub(size(Img_chd_eg_Mask),LinIdx_eg);

LinIdx_dc = find(edge(Img_chd_dc_Mask)); 
[Row_dc,Col_dc] = ind2sub(size(Img_chd_dc_Mask),LinIdx_dc);

LinIdx_bm = find(edge(Img_chd_bm_Mask));
[Row_bm,Col_bm] = ind2sub(size(Img_chd_bm_Mask),LinIdx_bm);

for mCt = 1:2 % MrwMask_Edge, MrwMask_SmEdge 

    if mCt==1 % MrwMask_Edge
        Img_mm_Temp = Img_MrwDef_Cell_In{1,2};
    elseif mCt==2 % MrwMask_SmEdge
        Img_mm_Temp = Img_MrwDef_Cell_In{1,4};
    end

    % = Clear bottom edge of MrwMask_Edge along y-max of image
    % i) Remove stretches of straight marrow edge running on the bottom row pixels of image
    % MrwMask_eg_Edge and MrwMask_dc_Edge exclude bottom edge of Mrw_Mask,
    % which is made of straight stretches (artefact from bwboundary()) and
    % edges of MrwHole connected to the bottom of the image. 
    Img_BttmLn3_Temp = single(Img_mm_Temp(end-2:end,:)); % consider most bottom 3 rows
    Img_BttmLn3_Temp = movmean(Img_BttmLn3_Temp,5,2); % consider each stretch = 5 pixels long

    ColID_BttmLn3_Temp = zeros(1,width(Img_BttmLn3_Temp),'logical'); % Flag columns to remove
    for colCt = 1:width(Img_BttmLn3_Temp)
        if isequal(Img_BttmLn3_Temp(:,colCt),single([0;0;1])) % flag column if bottom-3-row stretch has values of [0;0;1] 
            ColID_BttmLn3_Temp(1,colCt) = 1;
        end
    end
    ColID_BttmLn3_Temp = ...
        imdilate(ColID_BttmLn3_Temp,strel('line',5,0)); % Convert Column ID to the 5-px stretch position it represents
    Img_mm_Temp(end,:) = Img_mm_Temp(end,:)-single(ColID_BttmLn3_Temp); % Replace last row to "break" MrwMask_Edge
    
    clearvars *BttmLn3* colCt;

    % ii) Remove MrwHole connected to the bottom of image. 
    % This should clear the bottom edge of MrwMask_Edge
    Img_BttmLn_Temp = Img_mm_Temp(end,:); % bottom line only
    rp_BttmLn_Temp = regionprops(Img_BttmLn_Temp,'PixelIdxList');
    BttmLn_x_min_Temp = min(cat(1,rp_BttmLn_Temp.PixelIdxList),[],'all');
    BttmLn_x_max_Temp = max(cat(1,rp_BttmLn_Temp.PixelIdxList),[],'all');

    FlagID_BttmLn_Temp = zeros(height(rp_BttmLn_Temp),1,'logical');
    for bCt = 1:height(rp_BttmLn_Temp)
        if (ismember(BttmLn_x_min_Temp,rp_BttmLn_Temp(bCt).PixelIdxList)) | ...
                (ismember(BttmLn_x_max_Temp,rp_BttmLn_Temp(bCt).PixelIdxList))
            FlagID_BttmLn_Temp(bCt,1) = 1;
        end
    end
    rp_BttmLn_Temp(FlagID_BttmLn_Temp) = [];

    Img_BttmLn_Temp = zeros(size(Img_BttmLn_Temp),'logical'); % update
    Img_BttmLn_Temp(cat(1,rp_BttmLn_Temp.PixelIdxList)) = 1;
    Img_BttmLn_Temp = ...
        vertcat(zeros((height(Img_mm_Temp)-1),width(Img_mm_Temp),'logical'),Img_BttmLn_Temp);    
    rp_BttmLn_Temp = regionprops(Img_BttmLn_Temp,'PixelIdxList'); % update

    rp_mm_Temp = regionprops(Img_mm_Temp,'BoundingBox','PixelIdxList'); % update
    FlagID_mm_Temp = zeros(height(rp_mm_Temp),1,'logical');
    for bCt = 1:height(rp_mm_Temp)
        if any(ismember(rp_mm_Temp(bCt).PixelIdxList,cat(1,rp_BttmLn_Temp.PixelIdxList))) | ...
                (rp_mm_Temp(bCt).BoundingBox(:,4)<4) % Method may leave small bits within mrw of up to 3 pixels high
            FlagID_mm_Temp(bCt,1) = 1;
        end
    end
    rp_mm_Temp(FlagID_mm_Temp) = [];

    Img_mm_Temp = zeros(size(Img_mm_Temp),'logical'); % update
    Img_mm_Temp(cat(1,rp_mm_Temp.PixelIdxList)) = 1;
    % % % figure; 
    % % % imshow(Img_mm_Temp);

    clearvars bCt *BttmLn*;
    
    % = Extract MrwMask edge pixel locations
    LinIdx_mm_Temp = find(Img_mm_Temp);
    [Row_mm_Temp,Col_mm_Temp] = ind2sub(size(Img_mm_Temp),LinIdx_mm_Temp);

    % = Distance from each MrwMask Edge pixel to egEdge vs dcEdge pixels
    % Each pixel is assigned to the Edge with smaller distance
    [pD_D_eg_Temp,~] = ...
        pdist2([Row_eg,Col_eg],[Row_mm_Temp,Col_mm_Temp],'euclidean','Smallest',1);
    [pD_D_dc_Temp,~] = ...
        pdist2([Row_dc,Col_dc],[Row_mm_Temp,Col_mm_Temp],'euclidean','Smallest',1);
    [pD_D_bm_Temp,pD_I_bm_Temp] = ...
        pdist2([Row_bm,Col_bm],[Row_mm_Temp,Col_mm_Temp],'euclidean','Smallest',1);
    
    if ~isempty(pD_D_bm_Temp)
        egID_Temp = (pD_D_eg_Temp<=pD_D_dc_Temp) & (pD_D_bm_Temp>2); % 1 if MrwMask pixel closer to egEdge than dcEdge
    else
        egID_Temp = (pD_D_eg_Temp<=pD_D_dc_Temp);
    end
    LinIdx_mm_eg_Temp = LinIdx_mm_Temp(egID_Temp);
    Img_mm_eg_Temp = zeros(size(Img_mm_Temp),'logical');
    Img_mm_eg_Temp(LinIdx_mm_eg_Temp) = 1;
    Img_mm_eg_Temp(LinIdx_bm) = 0;

    if ~isempty(pD_D_bm_Temp)
        dcID_Temp = (pD_D_dc_Temp<pD_D_eg_Temp) & (pD_D_bm_Temp>2); 
    else
        dcID_Temp = (pD_D_dc_Temp<pD_D_eg_Temp); 
    end
    LinIdx_mm_dc_Temp = LinIdx_mm_Temp(dcID_Temp);
    Img_mm_dc_Temp = zeros(size(Img_mm_Temp),'logical');
    Img_mm_dc_Temp(LinIdx_mm_dc_Temp) = 1;
    Img_mm_eg_Temp(LinIdx_bm) = 0; 

    % % % figure; 
    % % % imshowpair(Img_mm_eg_Temp,Img_mm_dc_Temp);

    % = Store in output cell
    Img_Begdc_Cell_Out{1,(mCt*2-1)} = Img_mm_eg_Temp;
    % % % Img_Begdc_Cell_Out{2,(mCt*2-1)} = Img_mm_eg_Temp;
    % % % Img_Begdc_Cell_Out{3,(mCt*2-1)} = repmat(Img_mm_eg_Temp,1,1,size(Img_MrwDef_Cell_In{3,1},3));

    Img_Begdc_Cell_Out{1,(mCt*2)} = Img_mm_dc_Temp;
    % % % Img_Begdc_Cell_Out{2,(mCt*2)} = Img_mm_dc_Temp;
    % % % Img_Begdc_Cell_Out{3,(mCt*2)} = repmat(Img_mm_dc_Temp,1,1,size(Img_MrwDef_Cell_In{3,1},3));

end

clearvars *Temp mCt;


%% ====== Col05-08 Bone Edge *Region* Masks, epiphysis-growth plate (eg) & diaphysis-cortical bone (dc)

%% Create Bone Edge Bone Edge Region Masks
% Thicken Bone Edge Line Masks (Col01-04) and for overlapping pixels,
% assign to epiphysis-growth plate (eg)

for mCt = 1:2 % MrwMask_Edge, MrwMask_SmEdge 

    Img_mm_eg_Temp = Img_Begdc_Cell_Out{1,(mCt*2-1)};
    Img_mm_dc_Temp = Img_Begdc_Cell_Out{1,(mCt*2)};
    
    if UI_In.TearEst_Option
        Img_mm_eg_Temp = imdilate(Img_mm_eg_Temp,...
            strel('disk',max(round(3.0*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)),round(0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)+0.5*UI_In.TearEst_Width_um./UI_In.XY_PxLength_umpx))));  % thicken line (>= strel size used for collect & connect) 
    else
        Img_mm_eg_Temp = imdilate(Img_mm_eg_Temp,strel('disk',round(3.0*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)))); % thicken line (>= strel size used for collect & connect) 
    end
    Img_mm_dc_Temp = imdilate(Img_mm_dc_Temp,strel('disk',round(3.0*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)))); % thicken line
    % Img_mm_dc_Temp = logical(single(Img_mm_dc_Temp)-single(Img_mm_dc_Temp & Img_mm_eg_Temp)); % give eg priority
    Img_mm_dc_Temp = xor(Img_mm_dc_Temp,(Img_mm_dc_Temp & Img_mm_eg_Temp)); % give eg priority

    % = Store in output cell
    Img_Begdc_Cell_Out{1,((mCt+2)*2-1)} = Img_mm_eg_Temp;
    Img_Begdc_Cell_Out{2,((mCt+2)*2-1)} = Img_mm_eg_Temp;
    Img_Begdc_Cell_Out{3,((mCt+2)*2-1)} = repmat(Img_mm_eg_Temp,1,1,size(Img_MrwDef_Cell_In{3,1},3));

    Img_Begdc_Cell_Out{1,((mCt+2)*2)} = Img_mm_dc_Temp;
    Img_Begdc_Cell_Out{2,((mCt+2)*2)} = Img_mm_dc_Temp;
    Img_Begdc_Cell_Out{3,((mCt+2)*2)} = repmat(Img_mm_dc_Temp,1,1,size(Img_MrwDef_Cell_In{3,1},3));

end

