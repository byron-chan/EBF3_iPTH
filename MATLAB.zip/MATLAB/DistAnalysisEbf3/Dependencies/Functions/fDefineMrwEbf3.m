% 20250123: Usage
% i) Img_Lbl_Cell_In: 'Img_Lbl_Cell' contains nuclei image in {1,1}, Ebf3 image in {2,1} and all
% bone distance measure target (OCN, TRAP etc) image in {3,1} 
% Nuclei Image (ie, Img_Lbl_Cell_In{1,1}) used to create marrow and marrow hole mask
% ii) Default adapthisteq_NumTiles_In = 64
% iii) 'y' if create colocalization check image

function [Img_MrwDef_Cell_Out,ImgCheck_MrwDef_Cell_Out] = fDefineMrwEbf3(Img_Org_Cell_In,ImgCheck_Org_Cell_In,UI_In,ImgCheckOption_In)

close all;

%% Estimate Cell Size
% Ebf3 diameter ~7-10 um (Byron Email, 20241124)

Ebf3Sz_llim_px = 7.0/UI_In.XY_PxLength_umpx;
Ebf3Sz_ulim_px = 10.0/UI_In.XY_PxLength_umpx;


%% Prepare Output Cells

% OUTPUT: Img_MrwDef_Cell: cell of size(3,6)

% Rows (same as Img_Org_Cell):
% * Row01 = nuclei
% * Row02 = distance measure source (Ebf3)
% * Row03 = all dist measure targets (OCN, TRAP etc)
% * Row04 = all bone fronts (no staining or original image)

% Columns:
% * Col01 = MrwMask (logical, Row 1; choice of Col07 or Col09)
% * Col02 = MrwMask_Edge (logical, Row 1; choice of Col08 or Col10)
% * Col03 = MrwMask_Sm (= MrwMask_SmEdgeFill in previous versions; logical, Row 1)
% * Col04 = MrwMask_SmEdge (logical, Row1)
% * Col05 = MrwHoleMask (logical, tears in biopsy slice + appoximate trabecular bone locations; Row 1)
% * Col06 = Mrw image (greyscale; different for Row 1-3, zero image for Row 4)
% * Col07 = MrwMask, no collect & connect broken pieces (logical, Row 1)
% * Col08 = MrwMask_Edge, no collect & connect broken pieces (logical, Row 1)
% * Col09 = MrwMask, w/ collect & connect broken pieces (logical, Row 1)
% * Col10 = MrwMask_Edge, w/ collect & connect broken pieces (logical, Row 1)

Img_MrwDef_Cell_Out = cell(4,6);

% ImgCheck_MrwDef_Cell: 1 row, same columns as Img_MrwDef_Cell:
% Columns:
% * Col01 = <empty, can be filled with Colocalized Image of MrwMask with 'ImgCheck_MaskChoice' in code>
% * Col02 = Colocazed image, MrwMask_Edge, with Img_Mrw and Img of Mrw (B)+ Ebf3 (R) + DistanceTargets (G)
% * Col03 =  <empty, can be filled with Colocalized Image of MrwMask_Sm with 'ImgCheck_MaskChoice' in code>
% * Col04 = Colocazed image, MrwMask_SmEdge, with Img_Mrw and Img of Mrw (B)+ Ebf3 (R) + DistanceTargets (G)
% * Col05 = Colocazed image, MrwHoleMask, with Img_Mrw and Img of Mrw (B)+ Ebf3 (R) + DistanceTargets (G)
% * Col06 = <empty>

ImgCheck_MrwDef_Cell_Out = cell(1,6);


%% Create Marrow Mask from Nuclei Img: No Collect & Connect
% Assume marrow space not broken
% Same as "Img_B_MrwMask" in previous scripts

% = Define Marrow Mask from nuclei signal
Img_Nuc_In = Img_Org_Cell_In{1,1}; % Nuclei Image

adapthisteq_NumTiles = 64; % default: 64
Img_Nuc_BW = adapthisteq(Img_Nuc_In,... % 20250315: Test Distribution 'rayleigh', clip limit 0.015 for more uniform contrast
    'NumTiles',[adapthisteq_NumTiles round(adapthisteq_NumTiles.*width(Img_Nuc_In)/height(Img_Nuc_In))],...
    'ClipLimit',1.50E-2,...
    'Distribution','rayleigh');

[thresh,threshmetric] = multithresh(Img_Nuc_BW(Img_Nuc_BW>0),1);
Img_Nuc_BW = imbinarize(Img_Nuc_BW,thresh(1)); % NumTiles: [Row Col]

% % % figure; imshow(Img_Nuc_BW);

rp_Tbl = regionprops(Img_Nuc_BW,'Area','PixelIdxList');
FlagID = cat(1,rp_Tbl.Area)<0.1*max(cat(1,rp_Tbl.Area),[],'all'); % No Connect and Collect
% FlagID = cat(1,rp_Tbl.Area)<36*(pi*(0.5*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)).^2); % 20250506: 36 mean cell area (w Connect and Collect)
rp_Tbl(FlagID) = [];
Img_Nuc_MrwMask = zeros(size(Img_Nuc_BW),'logical');
Img_Nuc_MrwMask(cat(1,rp_Tbl.PixelIdxList)) = 1;

% = Store MrwMask in output cell
% (No Collect & Connect)
% MrwMask in Img_Nuc_MrwMask may be broken or unbroken 
% (ie, marrow space may be broken into multiple pieces, due to biopsy tears)
Img_MrwDef_Cell_Out{1,7} = Img_Nuc_MrwMask; % Mask for nuclei 

% = Create Marrow Mask w/ Outer Edge Only, Store as Output
% No Collect & Connect: assume marrow space not broken
% fConvertMasktoEdge() is in-script function
Img_MrwDef_Cell_Out{1,8} = ...
    fConvertMasktoEdge(Img_MrwDef_Cell_Out{1,7}, Ebf3Sz_llim_px, Ebf3Sz_ulim_px,1);

clearvars rp_* FlagID thresh* Img_Nuc_BW;
clearvars adapthisteq_NumTiles;


%% 20250506: Collect & Connect Broken Pieces of Marrow Space
% Marrow Space may be broken up due to biopsy tears
% i) Collection: Locate pieces of segmented nuc signal likely part of marrow space 
% ii) Connection: Assemble pieces of marrow space into 1 large marrow space 

for iCt = 1:2

    % = Define Marrow Mask from nuclei signal
    % Similar to No Collect & Collect; w/ more forgiving FlagID
    if iCt == 1
        Img_Nuc_In = Img_Org_Cell_In{1,1}; % Nuclei Image
    elseif iCt == 2
        Img_Nuc_In = Img_Org_Cell_In{1,1}.*single(Img_mm2_Temp);
    end

    adapthisteq_NumTiles = 64; % default: 64
    Img_Nuc_BW = adapthisteq(Img_Nuc_In,... % 20250315: Test Distribution 'rayleigh', clip limit 0.015 for more uniform contrast
        'NumTiles',[adapthisteq_NumTiles round(adapthisteq_NumTiles.*width(Img_Nuc_In)/height(Img_Nuc_In))],...
        'ClipLimit',1.50E-2,...
        'Distribution','rayleigh');
    [thresh,threshmetric] = multithresh(Img_Nuc_BW(Img_Nuc_BW>0),1);
    Img_Nuc_BW = imbinarize(Img_Nuc_BW,thresh(1)); % NumTiles: [Row Col]

    % % % figure; imshow(Img_Nuc_BW);
    
    rp_Tbl = regionprops(Img_Nuc_BW,'Area','PixelList','PixelIdxList'); % Flag blob touching "ceiling" of image
    FlagID_Temp = zeros(height(rp_Tbl),1,'logical');
    for bCt = 1:height(rp_Tbl)
        if any(rp_Tbl(bCt).PixelList(:,2)<2) & all(rp_Tbl(bCt).PixelList(:,2)<0.20*height(Img_Nuc_BW))
            FlagID_Temp(bCt,1) = 1;
        end
    end
    rp_Tbl(FlagID_Temp) = [];
    Img_Nuc_BW = zeros(size(Img_Nuc_BW),'logical'); % update
    Img_Nuc_BW(cat(1,rp_Tbl.PixelIdxList)) = 1;

    rp_Tbl = regionprops(Img_Nuc_BW,'Area','MinFeretProperties','MaxFeretProperties','PixelIdxList'); % update
    % FlagID_Temp = cat(1,rp_Tbl.Area)<0.1*max(cat(1,rp_Tbl.Area),[],'all'); % No Connect and Collect
    % FlagID_Temp = cat(1,rp_Tbl.Area)<36*(pi*(0.5*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)).^2); % 20250506: 36 mean cell area (w Connect and Collect)
    FlagID_Temp = cat(1,rp_Tbl.Area)<9*(pi*(0.5*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)).^2) | ...
        cat(1,rp_Tbl.MaxFeretDiameter)<(3*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)) | ...
        cat(1,rp_Tbl.MinFeretDiameter)<(1*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)); % 20250514
    rp_Tbl(FlagID_Temp) = [];
    Img_Nuc_MrwMask = zeros(size(Img_Nuc_BW),'logical');
    Img_Nuc_MrwMask(cat(1,rp_Tbl.PixelIdxList)) = 1;

    % === i) Collection
    % = 1st Iteration
    % If broken NucMask pieces < x mean cell diameter apart, fuse into larger
    % piece. Keep pieces colocalized to larger piece(s) that extend into lower half of image
    % 20250514: x should not exceed 10

    Img_mm_Temp = Img_Nuc_MrwMask; % mm = Marrow Mask;
    
    Img_mmc_Temp = imclose(Img_mm_Temp,strel('line',round(0.5*UI_In.TearEst_Width_um./UI_In.XY_PxLength_umpx),0)); % linear (horizontal) strel: 4.0 mean cell width each side of center
    % Img_mmc_Temp = imclose(Img_mm_Temp,strel('disk',round(0.5*UI_In.TearEst_Width_um./UI_In.XY_PxLength_umpx))); % circular strel: radius of 4.0 mean cell width
    
    rp_mmc_Temp = regionprops(Img_mmc_Temp,'Area','PixelList','PixelIdxList');
    FlagID_y_Temp = zeros(height(rp_mmc_Temp),1,'logical');
    for bCt2 = 1:height(rp_mmc_Temp)
        if all(~ismember(rp_mmc_Temp(bCt2).PixelList(:,2),(round(0.5*height(Img_mm_Temp)):1:height(Img_mm_Temp))'))
            FlagID_y_Temp(bCt2) = 1; % If none of blob's y values in lower half of image; flag blob for removal
        end
    end
    rp_mmc_Temp(FlagID_y_Temp) = [];

    rp_mm_Temp = regionprops(Img_mm_Temp,'Area','PixelList','PixelIdxList');
    FlagID_Temp = zeros(height(rp_mm_Temp),1,'logical');
    for bCt = 1:height(rp_mm_Temp)
        if all(~ismember(rp_mm_Temp(bCt).PixelIdxList,cat(1,rp_mmc_Temp.PixelIdxList)))
            FlagID_Temp(bCt) = 1;
        end
    end
    rp_mm_Temp(FlagID_Temp) = [];
    Img_mm_Temp = zeros(size(Img_mm_Temp),'logical');
    Img_mm_Temp(cat(1,rp_mm_Temp.PixelIdxList)) = 1;

    % = 2nd Iteration
    % If broken kept pieces from 1st it < x mean cell diameter apart, fuse into larger
    % piece. Keep pieces colocalized to larger piece
    % Note: shape and area of kept pieces is same as in NucMask at end of this step
    % 20250514: x should not exceed 10

    % Img_mmc_Temp = imclose(Img_mm_Temp,strel('line',round(0.5*UI_In.TearEst_Width_um./UI_In.XY_PxLength_umpx),0)); % linear (horizontal) strel: 4 mean cell width each side of center
    Img_mmc_Temp = imclose(Img_mm_Temp,strel('disk',round(0.5*UI_In.TearEst_Width_um./UI_In.XY_PxLength_umpx))); % circular strel: radius of 4 mean cell width (better than line strel here)
    
    Img_mmc_Temp = bwareafilt(Img_mmc_Temp,1); % isolate largest area only
    rp_mmc_Temp = regionprops(Img_mmc_Temp,'Area','PixelList','PixelIdxList'); % update

    rp_mm_Temp = regionprops(Img_mm_Temp,'Area','PixelList','PixelIdxList');
    FlagID_Temp = zeros(height(rp_mm_Temp),1,'logical');
    for bCt = 1:height(rp_mm_Temp)
        if all(~ismember(rp_mm_Temp(bCt).PixelIdxList,cat(1,rp_mmc_Temp.PixelIdxList)))
            FlagID_Temp(bCt) = 1;
        end
    end
    rp_mm_Temp(FlagID_Temp) = [];
    Img_mm_Temp = zeros(size(Img_mm_Temp),'logical');
    Img_mm_Temp(cat(1,rp_mm_Temp.PixelIdxList)) = 1;

    % = Close very small holes in kept marrow pieces
    % Marrow space, if broken, remains in multiple pieces
    Img_mm_Temp = imclose(Img_mm_Temp,strel('disk',round(0.5*0.5*Ebf3Sz_llim_px)));
    Img_mm_Temp = imfill(Img_mm_Temp,'holes');
    % % % figure; imshow(Img_mm_Temp);

    % = Remove holes touching bottom of mask
    % Marrow space, if broken, remains in multiple pieces
    Img_mmi_Temp = ~Img_mm_Temp;
    rp_mmi_Temp = regionprops(Img_mmi_Temp,'PixelList','PixelIdxList');
    FlagID_mmi_Temp = zeros(height(rp_mmi_Temp),1,'logical');
    for bCt = 1:height(rp_mmi_Temp)
        if any(rp_mmi_Temp(bCt).PixelList(:,2)>(height(Img_mm_Temp)-2)) & all(rp_mmi_Temp(bCt).PixelList(:,2)>2)
            FlagID_mmi_Temp(bCt,1) = 1;
        end
    end
    rp_mmi_Temp(FlagID_mmi_Temp) = [];
    Img_mmi_Temp = zeros(size(Img_mmi_Temp),'logical'); % update
    Img_mmi_Temp(cat(1,rp_mmi_Temp.PixelIdxList)) = 1;
    Img_mm_Temp = ~Img_mmi_Temp;

    % === ii) Connect collected pieces of (broken) marrow space
    % Estimate marrow space by connecting boundary pixels of all collected marrow pieces

    % = Create polyshape mask enclosing all collected marrow pieces
    % Polyshape mask roughly = collected marrow pieces + tear spaces +
    % trabecular bones
    rp_mm_Temp = regionprops(Img_mm_Temp,'PixelList');
    xy_mm_Temp = cat(1,rp_mm_Temp.PixelList);
    kxy_mm_Temp = boundary(xy_mm_Temp(:,1),xy_mm_Temp(:,2),0.5); % Shrink factor default = 0.5 (some smoothing here)
    kxy_mm_Temp = xy_mm_Temp(kxy_mm_Temp,:); % boundary x,y
    Img_mm2_Temp = poly2mask(kxy_mm_Temp(:,1),kxy_mm_Temp(:,2),height(Img_mm_Temp),width(Img_mm_Temp));
    % % % figure; imshowpair(Img_mm_Temp,Img_mm2_Temp);

    % = Remove holes touching bottom of mask
    % Marrow space, if broken, remains in multiple pieces
    Img_mm2i_Temp = ~Img_mm2_Temp;
    rp_mm2i_Temp = regionprops(Img_mm2i_Temp,'PixelList','PixelIdxList');
    FlagID_mm2i_Temp = zeros(height(rp_mm2i_Temp),1,'logical');
    for bCt = 1:height(rp_mm2i_Temp)
        if any(rp_mm2i_Temp(bCt).PixelList(:,2)>(height(Img_mm2_Temp)-2)) & all(rp_mm2i_Temp(bCt).PixelList(:,2)>2) % Remove all holes touching "floor" and not touching "ceiling" of image
            FlagID_mm2i_Temp(bCt,1) = 1;
        end
    end
    rp_mm2i_Temp(FlagID_mm2i_Temp) = [];
    Img_mm2i_Temp = zeros(size(Img_mm2i_Temp),'logical'); % update
    Img_mm2i_Temp(cat(1,rp_mm2i_Temp.PixelIdxList)) = 1;
    Img_mm2_Temp = ~Img_mm2i_Temp;

    % = Remove small additions to polyshape mask (especially along marrow space edge) due to mask approximation
    % Remove some effect of smoothing from boundary()
    Img_mm2e_Temp = imerode(Img_mm2_Temp,strel('disk',round(10*0.5*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)))); % erode image
    rp_mm2e_Temp = regionprops(Img_mm2e_Temp,'PixelIdxList');

    Img_mmd_Temp = xor(Img_mm_Temp,Img_mm2_Temp); % difference
    rp_mmd_Temp = regionprops(Img_mmd_Temp,'Area','MinFeretProperties','MaxFeretProperties','PixelIdxList');

    FlagID_mmd_Temp = zeros(height(rp_mmd_Temp),1,'logical');
    for bCt = 1:height(rp_mmd_Temp)
        if all(~ismember(rp_mmd_Temp(bCt).PixelIdxList,cat(1,rp_mm2e_Temp.PixelIdxList))) | ...
                rp_mmd_Temp(bCt).Area < 9*pi*(0.5*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px)).^2 | ... % by mean cell area
                rp_mmd_Temp(bCt).MinFeretDiameter < 3*0.5*(Ebf3Sz_llim_px+Ebf3Sz_ulim_px) % by mean cell diameter
            FlagID_mmd_Temp(bCt,1) = 1;
        end
    end
    rp_mmd_Temp(FlagID_mmd_Temp) = [];
    Img_mmd_Temp = zeros(size(Img_mmd_Temp),'logical'); % update
    Img_mmd_Temp(cat(1,rp_mmd_Temp.PixelIdxList)) = 1;
    Img_mm2_Temp = Img_mmd_Temp | Img_mm_Temp; % update
    Img_mm2_Temp = imfill(Img_mm2_Temp,'holes'); % holes filled
    Img_mm2_Temp = bwareafilt(Img_mm2_Temp,1,'largest');
    % % % figure; imshowpair(Img_mm_Temp,Img_mm2_Temp);

    % === Create Marrow Mask w/ Outer Edge Only
    % With Collect & Connect: marrow space broken
    % fConvertMasktoEdge() is in-script function
    Img_mm2_Edge_Temp = ...
        fConvertMasktoEdge(Img_mm2_Temp, Ebf3Sz_llim_px, Ebf3Sz_ulim_px,2);

end

% === Store Nuc_MrwMask, Nuc_MrwMask_Edge in output cell
% (w/ Collect & Connect)
Img_MrwDef_Cell_Out{1,9} = (Img_mm2_Temp & Img_Nuc_MrwMask); 
Img_MrwDef_Cell_Out{1,10} = Img_mm2_Edge_Temp;

clearvars *Temp rp* FlagIID* bCt*;


%% 20250509: Compare Marrow Mask w/ and w/out Collect & Connect Step
% If perimeter similar, use No Collect & Connect

rp_mm_nCC_Temp = regionprops(Img_MrwDef_Cell_Out{1,8},'Area','Perimeter','PixelIdxList');
Perim_nCC_Temp = cat(1,rp_mm_nCC_Temp.Perimeter);

Perim_wCC_Temp = numel(find(Img_MrwDef_Cell_Out{1,10}));

IoU_Temp = numel(find(Img_MrwDef_Cell_Out{1,7} & Img_MrwDef_Cell_Out{1,9})) / ...
    numel(find(Img_MrwDef_Cell_Out{1,7} | Img_MrwDef_Cell_Out{1,9}));

if UI_In.TearEst_Option
    if (abs(Perim_nCC_Temp-Perim_wCC_Temp)/Perim_nCC_Temp)<0.10 & IoU_Temp>0.95
        Img_MrwDef_Cell_Out{1,1} = Img_MrwDef_Cell_Out{1,7};
        Img_MrwDef_Cell_Out{1,2} = Img_MrwDef_Cell_Out{1,8};
        Option_CC = logical(0); % No Collect & Connect
    else
        Img_MrwDef_Cell_Out{1,1} = Img_MrwDef_Cell_Out{1,9};
        Img_MrwDef_Cell_Out{1,2} = Img_MrwDef_Cell_Out{1,10};
        Option_CC = logical(1); % With Collect & Connect
    end
else
    Img_MrwDef_Cell_Out{1,1} = Img_MrwDef_Cell_Out{1,7};
    Img_MrwDef_Cell_Out{1,2} = Img_MrwDef_Cell_Out{1,8};
    Option_CC = logical(0); % No Collect & Connect
end

clearvars *Temp rp* FlagIID* bCt*;


%% Create Smooth-Edged Marrow Mask (unfilled and filled) from Nuclei Image
% To be used for getting bonefront-marrow boundary signal for distance measure targets
% (OCN, TRAP etc)
% * Eliminates jaggedness at edge, small holes within marrow area
% Same as "Img_R(orGorB)_MrwMask_SmEdge" (unfilled; ie, only edge pixels of mask = 1) and 
% "Img_R(orGorB)_MrwMask_SmEdgeFill" (filled; all mask pixels = 1) in previous scripts

Img_Nuc_MrwMask = Img_MrwDef_Cell_Out{1,1};

% = Create smoothed boundary of nuclei-designated Marrow Space
se_radius_Temp = round(1.0*Ebf3Sz_ulim_px); % pre 20250125 default: 10
RC_Img_Nuc_Mask_SmEdge_Temp = ...
    bwboundaries(imclose(Img_Nuc_MrwMask,strel('disk',se_radius_Temp)),'noholes'); % [Row,Col coordinates of edge]
RC_Img_Nuc_Mask_SmEdge_Temp = cell2mat(RC_Img_Nuc_Mask_SmEdge_Temp);
LinIdx_Img_Nuc_Mask_SmEdge_Temp = ...
    sub2ind(size(Img_Nuc_In),round(RC_Img_Nuc_Mask_SmEdge_Temp(:,1)-0.5),round(RC_Img_Nuc_Mask_SmEdge_Temp(:,2)-0.5));
Img_Nuc_MrwMask_SmEdge_Temp = zeros(size(Img_Nuc_In),'logical');
Img_Nuc_MrwMask_SmEdge_Temp(LinIdx_Img_Nuc_Mask_SmEdge_Temp) = 1;

clearvars rc_Img_Nuc_Mask_SmEdge LinIdx_Img_Nuc_Mask_SmEdge;
clearvars strel_disk_radius;

% = Also create a filled mask from smoothed edge, to be used for cleaning up Ebf3 Channel
imfill_Loc_Temp = Img_Nuc_In.*imerode(Img_Nuc_MrwMask,strel('disk',3)); % Flood fill seeds; restrict to pixels in mask
imfill_Loc_Temp = find(imfill_Loc_Temp>prctile(imfill_Loc_Temp,75,'all'));
Img_Nuc_MrwMask_Sm_Temp = imfill(Img_Nuc_MrwMask_SmEdge_Temp,imfill_Loc_Temp);

if ~(Option_CC) % No Collect & Connect

    % = Store Smooth-Edged (filled) Marrow Mask in output cell
    Img_MrwDef_Cell_Out{1,3} = Img_Nuc_MrwMask_Sm_Temp; % Mask for nuclei channel

    % = Store Smooth-Edged (unfilled) Marrow Mask in output cell
    Img_MrwDef_Cell_Out{1,4} = Img_Nuc_MrwMask_SmEdge_Temp; % Mask for nuclei channel

else % With Collect & Connect; do not further clean edge

    % = Store Smooth-Edged (filled) Marrow Mask in output cell
    Img_MrwDef_Cell_Out{1,3} = Img_Nuc_MrwMask_Sm_Temp; % Mask for nuclei channel

    % = Create smoothed boundary of nuclei-designated Marrow Space
    se_radius_Temp = round(1.0*Ebf3Sz_ulim_px);
    Img_SmEdge_Temp = imclose(Img_MrwDef_Cell_Out{1,2},strel('disk',se_radius_Temp));
    Img_SmEdge_Temp = bwskel(Img_SmEdge_Temp);

    % = Store Smooth-Edged (unfilled) Marrow Mask in output cell
    Img_MrwDef_Cell_Out{1,4} = Img_SmEdge_Temp; % Mask for nuclei channel

end

clearvars *Temp;


%% Create Marrow Hole Mask from Nuclei Image
% To be used for definining trabecular bone (with Osteocalcin and TRAP co-location) 
% * Marrow holes can be tears in biopsy slice or appoximate trabecular bone locations
% * Define marrow holes as having size > 1 Ebf3 cell size

se_radius_Temp = 1; % for thickening line separating marrow region and background; pre-20250131 default: 3 

Img_mh_Temp = ~Img_MrwDef_Cell_Out{1,1}; % Marrow holes white, outside bone also white
Img_mh_Temp(find(imdilate(Img_MrwDef_Cell_Out{1,1},strel('disk',se_radius_Temp)))) = 0; % Darken MrwMask_Edge to isolate marrow region from background; pre 20250131: used MrwMask_SmEdge 
Img_mh_Temp = imopen(Img_mh_Temp,strel('disk',se_radius_Temp)); % recover pixels near MrwMask_Edge lost to thickening

Img_mh2_Temp = imerode(~imfill(Img_MrwDef_Cell_Out{1,2},'holes'),strel('disk',se_radius_Temp));
Img_mh_Temp = Img_mh_Temp & ~(Img_mh_Temp & Img_mh2_Temp);

rp_mh_Temp = regionprops(Img_mh_Temp,...
    'Area','BoundingBox','MinFeretProperties','MaxFeretProperties','PixelIdxList'); % Feret Properties is slow. Do a quick clean first

% % % rp_Bbox_Temp = cat(1,rp_mh_Temp.BoundingBox);
% % % FlagID_Temp = (rp_Bbox_Temp(:,3)<eps & rp_Bbox_Temp(:,4)<eps) | ... % Do not consider very tiny spaces (should be mostly taken care of by strel)
% % %     (rp_Bbox_Temp(:,3)>0.8*width(Img_Nuc_MrwMask) & rp_Bbox_Temp(:,4)>0.8*height(Img_Nuc_MrwMask));  % Also Flag outside-bone blob
% % % rp_mh_Temp(FlagID_Temp) = [];

if ~isempty(rp_mh_Temp)
    rp_mh_MinFD_Temp = cat(1,rp_mh_Temp.MinFeretDiameter);
    rp_mh_MaxFD_Temp = cat(1,rp_mh_Temp.MaxFeretDiameter);
    % % % FlagID_Temp = (rp_mh_MinFD_Temp<(1.0*Ebf3Sz_llim_px) | ... % Do not consider very tiny spaces (should be mostly taken care of by strel)
    % % %     (rp_mh_MaxFD_Temp>0.50*min(size(Img_mh_Temp))));  % Also Flag outside-bone blob
    FlagID_Temp = rp_mh_MinFD_Temp<(1.0*Ebf3Sz_llim_px);  % Do not consider very tiny spaces (should be mostly taken care of by strel)
    rp_mh_Temp(FlagID_Temp) = [];
end

Img_Nuc_MrwHoleMask = zeros(size(Img_mh_Temp),'logical');
Img_Nuc_MrwHoleMask(cat(1,rp_mh_Temp.PixelIdxList)) = 1;

clearvars *Temp;

% = Store Marrow Hole Mask in output cell
Img_MrwDef_Cell_Out{1,5} = Img_Nuc_MrwHoleMask; % Mask for nuclei channel


%% Create Marrow Image 
% Marrow image = original channel image in Img_Lbl_Cell, with MrwMask
% (unsmoothed) applied. Same as Img_R(orGorB)_Mrw in previous scripts.

Img_mm_Temp = (Img_MrwDef_Cell_Out{1,1} | Img_MrwDef_Cell_Out{1,3}); % MrwMask |  MrwMask_Sm; Row1
se_radius_Temp = round(1.0*Ebf3Sz_ulim_px); % pre-20250131 default: 10
Img_MrwDef_Cell_Out{1,6} = Img_Org_Cell_In{1,1}.*imdilate(Img_mm_Temp,strel('disk',se_radius_Temp)); % Nuclei, Marrow Img
Img_MrwDef_Cell_Out{2,6} = Img_Org_Cell_In{2,1}.*imdilate(Img_mm_Temp,strel('disk',se_radius_Temp)); % Ebf3, Marrow Img
Img_MrwDef_Cell_Out{3,6} = zeros(size(Img_Org_Cell_In{3,1}),'single');
for dtCt = 1:size(Img_Org_Cell_In{3,1},3) % distance target (OCN, TRAP etc) count
    Img_MrwDef_Cell_Out{3,6}(:,:,dtCt) = Img_Org_Cell_In{3,1}(:,:,dtCt).*imdilate(Img_mm_Temp,strel('disk',se_radius_Temp));
end
Img_MrwDef_Cell_Out{4,6} = zeros(size(Img_MrwDef_Cell_Out{1,6}),'single'); % 20250320

clearvars dCt *Temp;


%% OPTIONAL: ImgCheck
% addborder() from FileExchange: 
% https://www.mathworks.com/matlabcentral/fileexchange/21005-draw-a-border-around-an-image;

if ImgCheckOption_In == 'y'
    
    % = Prepare ImgCheck for Mask

    ImgCheck_MaskChoice = [2 4 5]; % Which mask to include (MrwMask_Edge, MrwMask_SmEdge, MrwHoleMask)

    for mCt = 1:numel(ImgCheck_MaskChoice)

        % Check MrwMask (same for all Rows)
        MrwMask_Edge_Temp = Img_MrwDef_Cell_Out{1,ImgCheck_MaskChoice(mCt)}; % class 'logical', 3-channel
        MrwMask_Edge_Temp = imdilate(MrwMask_Edge_Temp,strel('disk',1)); % thicken
        MrwMask_Edge_Temp = repmat(MrwMask_Edge_Temp,1,1,3);
        
        ColorMask_Temp = zeros(1,1,3,'logical'); % 3-element vector; designate which slice (R/G/B) to keep for nucleus (N)
        ColorMask_Temp(UI_In.ImgCheck_NSTColor(1)) = 1;
        ImgCheck_N_Temp = ImgCheck_Org_Cell_In{1,3}.*ColorMask_Temp;
        ImgCheck_N_Temp = addborder(ImgCheck_N_Temp,2,[1 1 1],'inner');

        ImgCheck_N_ol_Temp = ImgCheck_N_Temp; % nuclei w/ mask overlay in W
        ImgCheck_N_ol_Temp(MrwMask_Edge_Temp) = 1;

        ImgCheck_NST_Temp = ImgCheck_Org_Cell_In{1,3};
        ImgCheck_NST_Temp = addborder(ImgCheck_NST_Temp,2,[1 1 1],'inner');

        ImgCheck_NST_ol_Temp = ImgCheck_NST_Temp; % nuclei, source (Ebf3), targets w/ mask overlay in W
        ImgCheck_NST_ol_Temp(MrwMask_Edge_Temp) = 1;

        ImgCheck_MrwDef_Cell_Out{1,ImgCheck_MaskChoice(mCt)} = ...
            horzcat(ImgCheck_N_Temp,ImgCheck_N_ol_Temp,ImgCheck_NST_Temp,ImgCheck_NST_ol_Temp);

        % OPTIONAL: Resize to 800px high per image
        ImgCheck_MrwDef_Cell_Out{1,ImgCheck_MaskChoice(mCt)} = ...
            imresize(ImgCheck_MrwDef_Cell_Out{1,ImgCheck_MaskChoice(mCt)},[800 NaN]);

    end

    clearvars *Temp mCt ImgCheck_MaskChoice;

    % = Prepare ImgCheck for Marrow (Col 06; greyscale)
    % MrwMask (Img_MrwDef_Cell_Out{1,1}) same for all rows

    ImgCheck_Org_Temp = cat(3,Img_Org_Cell_In{1:3,1});
    ImgCheck_Org_Temp = ...
        cell2mat(permute(mat2cell(ImgCheck_Org_Temp,height(ImgCheck_Org_Temp),width(ImgCheck_Org_Temp),repelem(1,size(ImgCheck_Org_Temp,3))),[1 3 2]));
    ImgCheck_Mrw_Temp = cat(3,Img_MrwDef_Cell_Out{1:3,6});
    ImgCheck_Mrw_Temp = ...
        cell2mat(permute(mat2cell(ImgCheck_Mrw_Temp,height(ImgCheck_Mrw_Temp),width(ImgCheck_Mrw_Temp),repelem(1,size(ImgCheck_Mrw_Temp,3))),[1 3 2]));

    ImgCheck_MrwDef_Cell_Out{1,6} = zeros(height(ImgCheck_Org_Temp),width(ImgCheck_Org_Temp),3,'single');
    ImgCheck_MrwDef_Cell_Out{1,6}(:,:,1) = ImgCheck_Org_Temp;
    ImgCheck_MrwDef_Cell_Out{1,6}(:,:,2) = ImgCheck_Mrw_Temp;

    % Add border between channel images: 3 pixels thick
    ImgCheck_MrwDef_Cell_Out{1,6}(:,width(Img_Org_Cell_In{1,1}):width(Img_Org_Cell_In{1,1}):end,:) = 1; 
 
    % OPTIONAL: Resize to 800px high per image
    ImgCheck_MrwDef_Cell_Out{1,6} = imresize(ImgCheck_MrwDef_Cell_Out{1,6},[800 NaN]);

    clearvars *Temp cCt ImgCheck_Mrw;

else

    ImgCheck_MrwDef_Cell_Out = {}; % empty cell

end

clearvars thresh* Img_Nuc_BW Img_Nuc_Temp;
clearvars rp* FlagID;
clearvars Img_Check;


%% ======= In-Script Function

function [Img_Edge_Out] = fConvertMasktoEdge(Img_Mask_In,Ebf3Sz_llim_px_In,Ebf3Sz_ulim_px_In,Clean_Option_In)

Img_Mask_Temp = Img_Mask_In;

% = Keep outer edge pixels locations
RC_Edge_Temp = bwboundaries(Img_Mask_Temp,'noholes'); % boundary pixels in (Row,Column)
RC_Edge_Temp = cell2mat(RC_Edge_Temp);
LinIdx_Edge_Temp = sub2ind(size(Img_Mask_Temp),RC_Edge_Temp(:,1),RC_Edge_Temp(:,2));
Img_Edge_Temp = zeros(size(Img_Mask_Temp),'logical');
Img_Edge_Temp(LinIdx_Edge_Temp) = 1;

% = Locate pockets along outer edge accidentally included due to single-cell-size missing pixel
se_radius_Temp = max(1,round(0.5*0.5*(Ebf3Sz_llim_px_In+Ebf3Sz_ulim_px_In)));
Img_Edge2_Temp = imclose(Img_Edge_Temp,strel('disk',se_radius_Temp));
Boundary_Edge2_Temp = bwboundaries(Img_Edge2_Temp,'noholes'); % boundary pixels in (y,x)
LinIdx_Edge2_Temp = sub2ind(size(Img_Edge2_Temp),Boundary_Edge2_Temp{1,1}(:,1),Boundary_Edge2_Temp{1,1}(:,2));
Img_Edge2_Temp = zeros(size(Img_Edge2_Temp),'logical');
Img_Edge2_Temp(LinIdx_Edge2_Temp) = 1;

if Clean_Option_In == 1 % For No Collect & Connect

    Img_EdgeDiff_Temp = xor(Img_Edge_Temp,Img_Edge2_Temp); % difference
    rp_EdgeDiff_Temp = regionprops(Img_EdgeDiff_Temp,'Area','MaxFeretProperties','PixelIdxList');
    rp_EdgeDiff_MFD_Temp = cat(1,rp_EdgeDiff_Temp.MaxFeretDiameter);
    FlagID_Temp = rp_EdgeDiff_MFD_Temp<(10*0.5*(Ebf3Sz_llim_px_In+Ebf3Sz_ulim_px_In)); % 10 cell distance as limit; cell diameter ~ 8.5um (Byron email 20241124)
    rp_EdgeDiff_Temp(FlagID_Temp) = [];
    Img_EdgeDiff_Temp = zeros(size(Img_EdgeDiff_Temp),'logical');
    Img_EdgeDiff_Temp(cat(1,rp_EdgeDiff_Temp.PixelIdxList)) = 1;

    Img_Edge_Out = logical(single(Img_Edge_Temp)-single(Img_EdgeDiff_Temp));

elseif Clean_Option_In == 2 % w Collect & Connect (skip EdgeDiff clean as connect would have added extra pixels to shape)

    Img_Edge_Out = Img_Edge2_Temp;

end
